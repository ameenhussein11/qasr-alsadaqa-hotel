import {StrictMode} from 'react';
import {createRoot} from 'react-dom/client';
import App from './App.tsx';
import './index.css';
import { initTheme } from './utils/theme';

initTheme(); // before first paint: no light/dark flash

// Offline support for the web / iPad version (the Android APK already bundles everything)
const isNative = !!(window as unknown as { Capacitor?: { isNativePlatform?: () => boolean } }).Capacitor?.isNativePlatform?.();
if (!isNative && 'serviceWorker' in navigator && window.location.protocol.startsWith('http')) {
  window.addEventListener('load', () => {
    navigator.serviceWorker.register('./sw.js').catch(() => {
      /* offline caching unavailable */
    });
  });
}

// One-time migration of data saved under the old key prefix
try {
  Object.keys(localStorage)
    .filter((k) => k.startsWith('azhotel_'))
    .forEach((k) => {
      const nk = 'qasr_' + k.slice('azhotel_'.length);
      if (localStorage.getItem(nk) === null) localStorage.setItem(nk, localStorage.getItem(k) as string);
      localStorage.removeItem(k);
    });
} catch {
  /* storage unavailable */
}


createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <App />
  </StrictMode>,
);
