import type { DaySnapshot } from '../types/archive';

// Daily archive lives in IndexedDB (a year of days would not fit in localStorage).
const DB_NAME = 'qasr_archive_v1';
const STORE = 'days';
let dbPromise: Promise<IDBDatabase> | null = null;

const openDb = (): Promise<IDBDatabase> => {
  if (!dbPromise) {
    dbPromise = new Promise((resolve, reject) => {
      const req = indexedDB.open(DB_NAME, 1);
      req.onupgradeneeded = () => req.result.createObjectStore(STORE, { keyPath: 'date' });
      req.onsuccess = () => resolve(req.result);
      req.onerror = () => reject(req.error);
    });
  }
  return dbPromise;
};

async function run<T>(mode: IDBTransactionMode, fn: (s: IDBObjectStore) => IDBRequest<T>): Promise<T> {
  const db = await openDb();
  return new Promise<T>((resolve, reject) => {
    const rq = fn(db.transaction(STORE, mode).objectStore(STORE));
    rq.onsuccess = () => resolve(rq.result);
    rq.onerror = () => reject(rq.error);
  });
}

export const putDay = async (snap: DaySnapshot): Promise<void> => {
  await run('readwrite', (s) => s.put(snap));
};
export const getDay = async (date: string): Promise<DaySnapshot | null> => {
  try {
    return ((await run<DaySnapshot | undefined>('readonly', (s) => s.get(date))) as DaySnapshot | undefined) ?? null;
  } catch {
    return null;
  }
};
/** All archived dates, newest first. */
export const listDays = async (): Promise<string[]> => {
  try {
    const keys = (await run<IDBValidKey[]>('readonly', (s) => s.getAllKeys())) as string[];
    return keys.sort().reverse();
  } catch {
    return [];
  }
};
export const getAllDays = async (): Promise<DaySnapshot[]> => {
  try {
    return (await run<DaySnapshot[]>('readonly', (s) => s.getAll())) as DaySnapshot[];
  } catch {
    return [];
  }
};
export const clearDays = async (): Promise<void> => {
  await run('readwrite', (s) => s.clear());
};
