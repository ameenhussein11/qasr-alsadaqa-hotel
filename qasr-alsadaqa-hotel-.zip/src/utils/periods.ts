import type { ClosingType } from '../types/archive';
import { addDaysToDateStr } from './dates';

const MONTHS = ['يناير', 'فبراير', 'مارس', 'أبريل', 'مايو', 'يونيو', 'يوليو', 'أغسطس', 'سبتمبر', 'أكتوبر', 'نوفمبر', 'ديسمبر'];
export const CLOSING_TYPE_AR: Record<ClosingType, string> = { daily: 'يومي', weekly: 'أسبوعي', monthly: 'شهري', yearly: 'سنوي' };

export interface Period {
  type: ClosingType;
  key: string;
  from: string;
  to: string;
  label: string;
}

const parts = (d: string) => {
  const [y, m, day] = d.substring(0, 10).split('-').map(Number);
  return { y, m, day };
};
const pad = (n: number) => String(n).padStart(2, '0');

/** The period (day / week / month / year) that contains `dateStr`. Weeks run Saturday → Friday. */
export function periodFor(type: ClosingType, dateStr: string): Period {
  const { y, m, day } = parts(dateStr);
  if (type === 'daily') {
    const d = `${y}-${pad(m)}-${pad(day)}`;
    return { type, key: d, from: d, to: d, label: `يوم ${d}` };
  }
  if (type === 'weekly') {
    const dow = new Date(y, m - 1, day).getDay(); // 0 = Sunday … 6 = Saturday
    const sinceSat = (dow + 1) % 7;
    const from = addDaysToDateStr(`${y}-${pad(m)}-${pad(day)}`, -sinceSat);
    const to = addDaysToDateStr(from, 6);
    return { type, key: from, from, to, label: `أسبوع ${from} ← ${to}` };
  }
  if (type === 'monthly') {
    const last = new Date(y, m, 0).getDate();
    return { type, key: `${y}-${pad(m)}`, from: `${y}-${pad(m)}-01`, to: `${y}-${pad(m)}-${pad(last)}`, label: `شهر ${MONTHS[m - 1]} ${y}` };
  }
  return { type, key: String(y), from: `${y}-01-01`, to: `${y}-12-31`, label: `سنة ${y}` };
}

/** Move to the previous (-1) or next (+1) period; returns a date inside the new period. */
export function shiftPeriod(type: ClosingType, dateStr: string, delta: number): string {
  const { y, m, day } = parts(dateStr);
  if (type === 'daily') return addDaysToDateStr(dateStr, delta);
  if (type === 'weekly') return addDaysToDateStr(dateStr, 7 * delta);
  if (type === 'monthly') {
    const d = new Date(y, m - 1 + delta, 1);
    return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-01`;
  }
  return `${y + delta}-${pad(m)}-${pad(Math.min(day, 28))}`;
}
