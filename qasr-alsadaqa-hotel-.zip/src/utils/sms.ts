// SMS helpers. The app opens the phone's own SMS app with the message ready (the SIM sends it).
export interface SmsTemplate {
  id: string;
  label: string;
  text: string;
}

export const SMS_TEMPLATES: SmsTemplate[] = [
  { id: 'payment_reminder', label: 'تذكير بالسداد', text: 'عزيزنا {الاسم}، نذكّركم بسداد المبلغ المتبقي {المبلغ} {العملة} لإقامتكم في {الفندق}. شاكرين تعاونكم.' },
  { id: 'thanks', label: 'شكر', text: 'شكراً لاختياركم {الفندق} يا {الاسم}. يسعدنا استضافتكم دائماً ونتمنى لكم يوماً سعيداً.' },
  { id: 'welcome', label: 'ترحيب', text: 'أهلاً بكم يا {الاسم} في {الفندق}. غرفتكم رقم {الغرفة}. نتمنى لكم إقامة مريحة.' },
  { id: 'checkout', label: 'تذكير بالمغادرة', text: 'عزيزنا {الاسم}، نذكّركم بموعد المغادرة. شاكرين لكم إقامتكم في {الفندق}.' },
  { id: 'custody', label: 'إشعار أمانة', text: 'عزيزنا {الاسم}، تم استلام أمانتكم في {الفندق}: {الأمانة}. رقم الإيصال {الإيصال}.' },
  { id: 'custody_return', label: 'تسليم أمانة', text: 'عزيزنا {الاسم}، تم تسليمكم أمانتكم ({الأمانة}) من {الفندق}. شكراً لكم.' },
  { id: 'lost_found', label: 'مفقودات منسية', text: 'عزيزنا {الاسم}، وجدنا في {الفندق} غرضاً يخصكم: {الأمانة}. نرجو التواصل لاستلامه.' },
  { id: 'general', label: 'رسالة حرة', text: '' },
];

export const fillTemplate = (text: string, vars: Record<string, string>): string =>
  text.replace(/\{([^}]+)\}/g, (m, k: string) => (vars[k] !== undefined ? vars[k] : m));

export const cleanPhone = (p: string): string => (p || '').replace(/[^\d+]/g, '');

export const smsHref = (phone: string, text: string): string => `sms:${cleanPhone(phone)}?body=${encodeURIComponent(text)}`;

/** Opens the SMS app with the number and text filled in. */
export const openSms = (phone: string, text: string) => {
  window.location.href = smsHref(phone, text);
};
