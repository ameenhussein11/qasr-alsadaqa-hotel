// Screen-lock PIN. Only a salted SHA-256 hash is stored (never the PIN itself).
// NOTE: this protects against casual access to the reception screen only —
// the app has no server, so it is not real authentication.
const PIN_KEY = 'qasr_pin_v1';
const SALT = 'qasr-alsadaqa-lock::';

async function sha256Hex(text: string): Promise<string> {
  if (typeof crypto !== 'undefined' && crypto.subtle) {
    const buf = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(text));
    return Array.from(new Uint8Array(buf)).map((b) => b.toString(16).padStart(2, '0')).join('');
  }
  // Fallback for non-secure contexts (plain http): simple 32-bit FNV-1a hash
  let h = 0x811c9dc5;
  for (let i = 0; i < text.length; i++) {
    h ^= text.charCodeAt(i);
    h = Math.imul(h, 0x01000193) >>> 0;
  }
  return 'fnv-' + h.toString(16);
}

export const isValidPin = (pin: string) => /^\d{4}$/.test(pin);
export const hasPin = (): boolean => {
  try { return !!localStorage.getItem(PIN_KEY); } catch { return false; }
};
export async function savePin(pin: string): Promise<void> {
  localStorage.setItem(PIN_KEY, await sha256Hex(SALT + pin));
}
export function clearPin(): void {
  try { localStorage.removeItem(PIN_KEY); } catch { /* ignore */ }
}
/** Returns true when no PIN is set, or when the PIN matches. */
export async function verifyPin(pin: string): Promise<boolean> {
  let stored: string | null = null;
  try { stored = localStorage.getItem(PIN_KEY); } catch { /* ignore */ }
  if (!stored) return true;
  return stored === (await sha256Hex(SALT + pin));
}
