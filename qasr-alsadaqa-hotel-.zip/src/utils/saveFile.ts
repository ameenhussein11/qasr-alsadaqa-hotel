import { Capacitor } from '@capacitor/core';
import type { jsPDF } from 'jspdf';

export const isNativeApp = (): boolean => {
  try {
    return Capacitor.isNativePlatform();
  } catch {
    return false;
  }
};

const blobToBase64 = (blob: Blob): Promise<string> =>
  new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onerror = () => reject(reader.error);
    reader.onload = () => resolve(String(reader.result).split(',')[1] || '');
    reader.readAsDataURL(blob);
  });

/**
 * Save/export a file.
 * - Browser: normal download.
 * - Android app (Capacitor): WebView ignores <a download>, so write the file to the
 *   app cache and open the system share sheet ("Save to Files", WhatsApp, Drive...).
 */
export async function saveBlob(filename: string, blob: Blob): Promise<void> {
  if (isNativeApp()) {
    try {
      const [{ Filesystem, Directory }, { Share }] = await Promise.all([
        import('@capacitor/filesystem'),
        import('@capacitor/share'),
      ]);
      const written = await Filesystem.writeFile({
        path: filename,
        data: await blobToBase64(blob),
        directory: Directory.Cache,
      });
      await Share.share({ title: filename, url: written.uri, dialogTitle: 'حفظ أو مشاركة الملف' });
    } catch (err) {
      // Share sheet dismissed by the user is not an error worth surfacing
      if (!String(err).toLowerCase().includes('cancel')) {
        console.error('saveBlob failed', err);
        alert('تعذّر حفظ الملف.');
      }
    }
    return;
  }
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}

export const saveText = (filename: string, text: string, mime = 'text/plain;charset=utf-8') =>
  saveBlob(filename, new Blob([text], { type: mime }));

export const savePdf = (doc: jsPDF, filename: string) => saveBlob(filename, doc.output('blob'));
