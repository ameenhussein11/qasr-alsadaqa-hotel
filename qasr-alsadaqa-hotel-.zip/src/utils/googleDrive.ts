// Real Google Drive sync (no SDK, no server).
// Sign-in uses Google's "device" flow: the app shows a short code, the owner types it once at
// google.com/device, and the app receives a refresh token it keeps on the device.
// Scope is drive.file only: the app can see ONLY the files/folders it created itself.
import { getAllDays } from './archiveStore';
import { localDate } from './dates';

const KEY = 'qasr_gdrive_v1';
const SCOPE = 'https://www.googleapis.com/auth/drive.file email';
const FOLDER_NAME = 'قصر الصداقة - الأرشيف';

export interface DriveConfig {
  clientId: string;
  clientSecret: string;
  refreshToken?: string;
  accessToken?: string;
  expiresAt?: number;
  email?: string;
  notifyEmail?: string;
  autoSync: boolean;
  folderId?: string;
  latestFileId?: string;
  logsFileId?: string;
  archiveDate?: string;
  archiveFileId?: string;
  daysFolderId?: string;
  dayFiles?: Record<string, { id: string; savedAt: string }>;
  lastSyncAt?: string;
  lastError?: string;
}

const EMPTY: DriveConfig = { clientId: '', clientSecret: '', autoSync: true };

export const loadDriveConfig = (): DriveConfig => {
  try {
    const raw = localStorage.getItem(KEY);
    if (raw) return { ...EMPTY, ...JSON.parse(raw) };
  } catch {
    /* ignore */
  }
  return { ...EMPTY };
};

export const saveDriveConfig = (patch: Partial<DriveConfig>): DriveConfig => {
  const next = { ...loadDriveConfig(), ...patch };
  try {
    localStorage.setItem(KEY, JSON.stringify(next));
  } catch {
    /* ignore */
  }
  window.dispatchEvent(new CustomEvent('qasr-drive-status'));
  return next;
};

export const isDriveLinked = (c: DriveConfig = loadDriveConfig()) => !!c.refreshToken;

async function postForm(url: string, params: Record<string, string>) {
  const res = await fetch(url, {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: new URLSearchParams(params).toString(),
  });
  let json: any = {};
  try {
    json = await res.json();
  } catch {
    /* empty body */
  }
  return { ok: res.ok, status: res.status, json };
}

// ---------- device-flow linking ----------
export interface DeviceCode {
  device_code: string;
  user_code: string;
  verification_url: string;
  expires_in: number;
  interval: number;
}

export async function startDeviceLink(clientId: string): Promise<DeviceCode> {
  const r = await postForm('https://oauth2.googleapis.com/device/code', { client_id: clientId.trim(), scope: SCOPE });
  if (!r.ok || !r.json.device_code) {
    throw new Error(r.json.error_description || r.json.error || 'تعذّر بدء الربط. تأكد من معرّف العميل (Client ID) ومن الاتصال بالإنترنت.');
  }
  return r.json as DeviceCode;
}

export type PollResult = 'pending' | 'slow' | 'ok' | 'denied' | 'expired';

const emailFromIdToken = (idToken?: string): string | undefined => {
  try {
    if (!idToken) return undefined;
    const payload = idToken.split('.')[1].replace(/-/g, '+').replace(/_/g, '/');
    const json = decodeURIComponent(
      atob(payload)
        .split('')
        .map((c) => '%' + c.charCodeAt(0).toString(16).padStart(2, '0'))
        .join('')
    );
    return JSON.parse(json).email;
  } catch {
    return undefined;
  }
};

export async function pollDeviceLink(deviceCode: string): Promise<PollResult> {
  const cfg = loadDriveConfig();
  const r = await postForm('https://oauth2.googleapis.com/token', {
    client_id: cfg.clientId.trim(),
    client_secret: cfg.clientSecret.trim(),
    device_code: deviceCode,
    grant_type: 'urn:ietf:params:oauth:grant-type:device_code',
  });
  if (r.ok && r.json.access_token) {
    saveDriveConfig({
      accessToken: r.json.access_token,
      refreshToken: r.json.refresh_token,
      expiresAt: Date.now() + (Number(r.json.expires_in) || 3600) * 1000,
      email: emailFromIdToken(r.json.id_token),
      lastError: undefined,
    });
    return 'ok';
  }
  switch (r.json.error) {
    case 'authorization_pending':
      return 'pending';
    case 'slow_down':
      return 'slow';
    case 'access_denied':
      return 'denied';
    case 'expired_token':
      return 'expired';
    default:
      throw new Error(r.json.error_description || r.json.error || 'فشل الربط.');
  }
}

export function unlinkDrive() {
  saveDriveConfig({
    refreshToken: undefined,
    accessToken: undefined,
    expiresAt: undefined,
    email: undefined,
    folderId: undefined,
    latestFileId: undefined,
    logsFileId: undefined,
    archiveDate: undefined,
    archiveFileId: undefined,
    lastError: undefined,
  });
}

// ---------- tokens ----------
async function getAccessToken(force = false): Promise<string> {
  const cfg = loadDriveConfig();
  if (!cfg.refreshToken) throw new Error('الحساب غير مربوط.');
  if (!force && cfg.accessToken && cfg.expiresAt && cfg.expiresAt > Date.now() + 60_000) return cfg.accessToken;
  const r = await postForm('https://oauth2.googleapis.com/token', {
    client_id: cfg.clientId.trim(),
    client_secret: cfg.clientSecret.trim(),
    refresh_token: cfg.refreshToken,
    grant_type: 'refresh_token',
  });
  if (!r.ok || !r.json.access_token) {
    if (r.json.error === 'invalid_grant') {
      saveDriveConfig({ refreshToken: undefined, accessToken: undefined });
      throw new Error('انتهت صلاحية الربط، أعد ربط الحساب.');
    }
    throw new Error(r.json.error_description || r.json.error || 'تعذّر تجديد الجلسة.');
  }
  saveDriveConfig({ accessToken: r.json.access_token, expiresAt: Date.now() + (Number(r.json.expires_in) || 3600) * 1000 });
  return r.json.access_token as string;
}

async function driveFetch(url: string, init: RequestInit = {}): Promise<Response> {
  const call = async (token: string) =>
    fetch(url, { ...init, headers: { ...(init.headers as Record<string, string>), Authorization: `Bearer ${token}` } });
  let res = await call(await getAccessToken());
  if (res.status === 401) res = await call(await getAccessToken(true));
  return res;
}

// ---------- Drive operations ----------
async function ensureFolder(): Promise<string> {
  const cfg = loadDriveConfig();
  if (cfg.folderId) return cfg.folderId;
  const q = encodeURIComponent(`mimeType='application/vnd.google-apps.folder' and name='${FOLDER_NAME}' and trashed=false`);
  const found = await driveFetch(`https://www.googleapis.com/drive/v3/files?q=${q}&fields=files(id)&spaces=drive`);
  if (found.ok) {
    const j = await found.json();
    if (j.files?.[0]?.id) {
      saveDriveConfig({ folderId: j.files[0].id });
      return j.files[0].id;
    }
  }
  const created = await driveFetch('https://www.googleapis.com/drive/v3/files', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json; charset=UTF-8' },
    body: JSON.stringify({ name: FOLDER_NAME, mimeType: 'application/vnd.google-apps.folder' }),
  });
  if (!created.ok) throw new Error(`تعذّر إنشاء مجلد الأرشيف (${created.status}).`);
  const id = (await created.json()).id as string;
  saveDriveConfig({ folderId: id });
  return id;
}

async function createFile(name: string, mime: string, content: string, folderId: string): Promise<string> {
  const boundary = `qasr${Date.now()}`;
  const meta = JSON.stringify({ name, mimeType: mime, parents: [folderId] });
  const body =
    `--${boundary}\r\nContent-Type: application/json; charset=UTF-8\r\n\r\n${meta}\r\n` +
    `--${boundary}\r\nContent-Type: ${mime}; charset=UTF-8\r\n\r\n${content}\r\n--${boundary}--`;
  const res = await driveFetch('https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart&fields=id', {
    method: 'POST',
    headers: { 'Content-Type': `multipart/related; boundary=${boundary}` },
    body,
  });
  if (!res.ok) throw new Error(`فشل رفع الملف ${name} (${res.status}).`);
  return (await res.json()).id as string;
}

async function upsertFile(existingId: string | undefined, name: string, mime: string, content: string, folderId: string) {
  if (existingId) {
    const res = await driveFetch(`https://www.googleapis.com/upload/drive/v3/files/${existingId}?uploadType=media`, {
      method: 'PATCH',
      headers: { 'Content-Type': `${mime}; charset=UTF-8` },
      body: content,
    });
    if (res.ok) return { id: existingId, created: false };
    if (res.status !== 404) throw new Error(`فشل تحديث الملف ${name} (${res.status}).`);
  }
  return { id: await createFile(name, mime, content, folderId), created: true };
}

async function notifyByEmail(fileId: string, email: string) {
  try {
    await driveFetch(
      `https://www.googleapis.com/drive/v3/files/${fileId}/permissions?sendNotificationEmail=true&emailMessage=${encodeURIComponent('أرشيف يومي لنظام فندق قصر الصداقة')}`,
      {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ role: 'reader', type: 'user', emailAddress: email }),
      }
    );
  } catch {
    /* notification is best-effort */
  }
}

/** Sub-folder holding one JSON file per archived day (system + guest register). */
async function ensureDaysFolder(parentId: string): Promise<string> {
  const cfg = loadDriveConfig();
  if (cfg.daysFolderId) return cfg.daysFolderId;
  const name = 'أرشيف الأيام';
  const q = encodeURIComponent(`mimeType='application/vnd.google-apps.folder' and name='${name}' and '${parentId}' in parents and trashed=false`);
  const found = await driveFetch(`https://www.googleapis.com/drive/v3/files?q=${q}&fields=files(id)&spaces=drive`);
  if (found.ok) {
    const j = await found.json();
    if (j.files?.[0]?.id) {
      saveDriveConfig({ daysFolderId: j.files[0].id });
      return j.files[0].id;
    }
  }
  const created = await driveFetch('https://www.googleapis.com/drive/v3/files', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json; charset=UTF-8' },
    body: JSON.stringify({ name, mimeType: 'application/vnd.google-apps.folder', parents: [parentId] }),
  });
  if (!created.ok) throw new Error(`تعذّر إنشاء مجلد أرشيف الأيام (${created.status}).`);
  const id = (await created.json()).id as string;
  saveDriveConfig({ daysFolderId: id });
  return id;
}

/** Uploads the daily archive (day-YYYY-MM-DD.json) — only days that are new or changed, a few per sync. */
async function syncArchiveDays(parentId: string): Promise<void> {
  try {
    const days = (await getAllDays()).sort((a, b) => b.date.localeCompare(a.date)); // newest first
    let cfg = loadDriveConfig();
    const known = { ...(cfg.dayFiles || {}) };
    const pending = days.filter((d) => known[d.date]?.savedAt !== d.savedAt).slice(0, 10);
    if (pending.length === 0) return;
    const folder = await ensureDaysFolder(parentId);
    for (const d of pending) {
      const res = await upsertFile(known[d.date]?.id, `day-${d.date}.json`, 'application/json', JSON.stringify(d), folder);
      known[d.date] = { id: res.id, savedAt: d.savedAt };
      cfg = saveDriveConfig({ dayFiles: known });
    }
  } catch (err) {
    console.error('Archive days upload failed', err); // never fail the main backup because of this
  }
}

/** Upload latest backup + full system log, keep one dated archive file per day, and the daily archive. */
export async function syncToDrive(backupJson: string, logsCsv: string): Promise<string> {
  const folderId = await ensureFolder();
  let cfg = loadDriveConfig();

  const latest = await upsertFile(cfg.latestFileId, 'latest-backup.json', 'application/json', backupJson, folderId);
  const logs = await upsertFile(cfg.logsFileId, 'system-log.csv', 'text/csv', logsCsv, folderId);

  const today = localDate();
  const sameDay = cfg.archiveDate === today && !!cfg.archiveFileId;
  const archive = await upsertFile(sameDay ? cfg.archiveFileId : undefined, `archive-${today}.json`, 'application/json', backupJson, folderId);

  cfg = saveDriveConfig({
    latestFileId: latest.id,
    logsFileId: logs.id,
    archiveDate: today,
    archiveFileId: archive.id,
    lastSyncAt: new Date().toLocaleString('en-GB'),
    lastError: undefined,
  });

  await syncArchiveDays(folderId);

  if (archive.created && cfg.notifyEmail && cfg.notifyEmail.toLowerCase() !== (cfg.email || '').toLowerCase()) {
    await notifyByEmail(archive.id, cfg.notifyEmail.trim());
  }
  return cfg.lastSyncAt || '';
}
