import type { Booking, Guest, Room, Payment, ExpenseRecord, OtherRevenueRecord, StaffSalaryRecord, ActivityLog } from '../types/hotel';
import type { ClosingFigures, DaySnapshot, SnapshotBookingRow } from '../types/archive';
import { addDaysToDateStr, localDate, localDateTime } from './dates';
import { guestHosting, isCancelledBooking } from './hosting';

export interface FinanceData {
  rooms: Room[];
  bookings: Booking[];
  guests: Guest[];
  payments: Payment[];
  expenses: ExpenseRecord[];
  otherRevenues: OtherRevenueRecord[];
  staffSalaries: StaffSalaryRecord[];
}

const d10 = (s: string) => (s || '').substring(0, 10);
const inRange = (s: string, from: string, to: string) => {
  const d = d10(s);
  return d >= from && d <= to;
};
const diffDays = (a: string, b: string) => {
  const [ay, am, ad] = a.split('-').map(Number);
  const [by, bm, bd] = b.split('-').map(Number);
  return Math.round((Date.UTC(by, bm - 1, bd) - Date.UTC(ay, am - 1, ad)) / 86400000);
};
const sum = (arr: number[]) => arr.reduce((a, b) => a + b, 0);

/** Nights of a booking that fall inside [from, to]. */
function nightsOverlap(b: Booking, from: string, to: string, today: string): number {
  const start = d10(b.checkInDate);
  let end = d10(b.actualCheckOutDate || b.expectedCheckOutDate);
  if (b.isActive) {
    const tomorrow = addDaysToDateStr(today, 1);
    if (end > tomorrow) end = tomorrow;
  }
  if (end <= start) end = addDaysToDateStr(start, 1); // same-day stay counts as one night
  const s = start > from ? start : from;
  const toEx = addDaysToDateStr(to, 1);
  const e = end < toEx ? end : toEx;
  return Math.max(0, diffDays(s, e));
}

export function computeFigures(data: FinanceData, from: string, to: string): ClosingFigures {
  const today = localDate();
  const pays = data.payments.filter((p) => inRange(p.date, from, to));
  const roomRevenue = sum(pays.map((p) => p.amount));
  const roomRevenueByMethod: Record<string, number> = {};
  pays.forEach((p) => (roomRevenueByMethod[p.method] = (roomRevenueByMethod[p.method] || 0) + p.amount));

  const otherRevenue = sum(data.otherRevenues.filter((r) => inRange(r.date, from, to)).map((r) => r.amount));
  const exps = data.expenses.filter((e) => inRange(e.date, from, to));
  const expenses = sum(exps.map((e) => e.amount));
  const expensesByCategory: Record<string, number> = {};
  exps.forEach((e) => (expensesByCategory[e.category] = (expensesByCategory[e.category] || 0) + e.amount));

  const sal = data.staffSalaries.filter((s) => s.status === 'paid' && inRange(s.paymentDate, from, to));
  const real = data.bookings.filter((b) => !isCancelledBooking(b));
  const nightsSold = sum(real.map((b) => nightsOverlap(b, from, to, today)));
  const effTo = to > today ? today : to;
  const days = Math.max(1, diffDays(from, effTo) + 1);
  const capacity = Math.max(1, data.rooms.length) * days;

  return {
    days,
    roomRevenue,
    roomRevenueByMethod,
    otherRevenue,
    totalRevenue: roomRevenue + otherRevenue,
    expenses,
    expensesByCategory,
    salariesPaid: sum(sal.map((s) => s.netSalary)),
    salariesCount: sal.length,
    net: roomRevenue + otherRevenue - expenses,
    checkIns: real.filter((b) => inRange(b.checkInDate, from, to)).length,
    checkOuts: real.filter((b) => b.actualCheckOutDate && inRange(b.actualCheckOutDate, from, to)).length,
    newGuests: data.guests.filter((g) => inRange(g.createdAt, from, to)).length,
    nightsSold,
    occupancyPercent: Math.min(100, Math.round((nightsSold / capacity) * 100)),
    adr: nightsSold > 0 ? Math.round(roomRevenue / nightsSold) : 0,
  };
}

const bookingRow = (b: Booking): SnapshotBookingRow => ({
  bookingCode: b.bookingCode,
  roomNumber: b.roomNumber,
  guestName: b.guestName,
  checkInDate: b.checkInDate,
  expectedCheckOutDate: b.expectedCheckOutDate,
  actualCheckOutDate: b.actualCheckOutDate,
  totalAmount: b.totalAmount,
  paidAmount: b.paidAmount,
  isActive: b.isActive,
});

/** Full picture of the hotel for one day (no photos). */
export function buildDaySnapshot(date: string, data: FinanceData & { logs: ActivityLog[]; hotelName: string }): DaySnapshot {
  const total = data.rooms.length;
  const count = (st: string) => data.rooms.filter((r) => r.status === st).length;
  const occupied = count('occupied');
  const real = data.bookings.filter((b) => !isCancelledBooking(b));
  return {
    date,
    savedAt: localDateTime(),
    hotelName: data.hotelName,
    stats: {
      totalRooms: total,
      occupied,
      available: count('available'),
      cleaning: count('cleaning'),
      maintenance: count('maintenance'),
      occupancyPercent: total ? Math.round((occupied / total) * 100) : 0,
    },
    figures: computeFigures(data, date, date),
    rooms: data.rooms.map((r) => ({
      roomNumber: r.roomNumber,
      type: r.type,
      status: r.status,
      guestName: r.currentGuestName,
      checkOutDate: r.checkOutDate,
      pricePerNight: r.pricePerNight,
    })),
    guests: data.guests.map((g) => {
      const h = guestHosting(g.id, data.bookings);
      return {
        id: g.id,
        name: g.name,
        phone: g.phone,
        nationalId: g.nationalId,
        nationality: g.nationality,
        visitCount: g.visitCount,
        isVip: !!g.isVip,
        isBlacklisted: !!g.isBlacklisted,
        roomNumber: h.current?.roomNumber,
        checkIn: h.current?.checkInDate,
        hostedNights: h.totalNights,
        lastStayFrom: h.lastStay?.from,
        lastStayTo: h.lastStay?.to,
        lastStayRoom: h.lastStay?.room,
      };
    }),
    activeBookings: real.filter((b) => b.isActive).map(bookingRow),
    dayBookings: real.filter((b) => d10(b.checkInDate) === date || (b.actualCheckOutDate && d10(b.actualCheckOutDate) === date)).map(bookingRow),
    payments: data.payments.filter((p) => d10(p.date) === date),
    expenses: data.expenses.filter((e) => d10(e.date) === date),
    otherRevenues: data.otherRevenues.filter((r) => d10(r.date) === date),
    salaries: data.staffSalaries.filter((s) => d10(s.paymentDate) === date),
    logs: data.logs.filter((l) => d10(l.timestamp) === date),
  };
}
