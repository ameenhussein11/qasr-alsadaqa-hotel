import { Room, Guest, Booking, HousekeepingTask, HotelSettings, Payment, ActivityLog, RoomServiceItem, RoomServiceOrder } from '../types/hotel';
import {
  initialRooms,
  initialGuests,
  initialBookings,
  initialHousekeeping,
  initialSettings,
  initialPayments,
  initialLogs,
  initialRoomServiceMenu,
  initialRoomServiceOrders,
} from './initialData';

const DB_STORAGE_KEY = 'qasr_sqlite_pms_db_v1';

/** Deep copy so the shared demo constants are never mutated by the live database. */
const clone = <T,>(v: T): T => JSON.parse(JSON.stringify(v));

/** Escape a value for a SQL string literal (or NULL). */
const sqlStr = (v: unknown): string =>
  v === undefined || v === null || v === '' ? 'NULL' : `'${String(v).replace(/'/g, "''").replace(/\r?\n/g, ' ')}'`;
/** Same as sqlStr but never NULL (for NOT NULL columns). */
const sqlReq = (v: unknown): string => `'${String(v ?? '').replace(/'/g, "''").replace(/\r?\n/g, ' ')}'`;

export interface SqliteDatabase {
  version: number;
  lastUpdated: string;
  settings: HotelSettings;
  rooms: Room[];
  guests: Guest[];
  bookings: Booking[];
  housekeeping: HousekeepingTask[];
  payments: Payment[];
  logs: ActivityLog[];
  roomServiceMenu: RoomServiceItem[];
  roomServiceOrders: RoomServiceOrder[];
}

export interface QueryResult {
  success: boolean;
  message?: string;
  columns?: string[];
  rows?: Record<string, any>[];
  rowCount?: number;
  executionTimeMs?: number;
  sql?: string;
}

export const SQL_SCHEMA_DDL = `
-- ==========================================================
-- Qasr Al-Sadaqa SQLite Database Schema (Room Persistence Library)
-- ==========================================================

CREATE TABLE IF NOT EXISTS rooms (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    room_number TEXT NOT NULL UNIQUE,
    floor INTEGER NOT NULL,
    type TEXT NOT NULL, -- 'single', 'double', 'triple', 'suite', 'vip_deluxe'
    price_per_night REAL NOT NULL,
    status TEXT NOT NULL DEFAULT 'available', -- 'available', 'occupied', 'cleaning', 'maintenance'
    capacity INTEGER NOT NULL DEFAULT 2,
    current_booking_id INTEGER,
    current_guest_name TEXT,
    current_guest_phone TEXT,
    check_in_date TEXT,
    check_out_date TEXT,
    notes TEXT
);

CREATE TABLE IF NOT EXISTS guests (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    phone TEXT NOT NULL UNIQUE,
    national_id TEXT NOT NULL,
    nationality TEXT DEFAULT 'يمني',
    email TEXT,
    visit_count INTEGER NOT NULL DEFAULT 1,
    is_frequent INTEGER NOT NULL DEFAULT 0, -- 0 or 1 (Frequent / VIP Guest)
    loyalty_discount_percent REAL DEFAULT 0,
    total_spent REAL DEFAULT 0,
    is_vip INTEGER DEFAULT 0,
    is_blacklisted INTEGER DEFAULT 0,
    notes TEXT,
    created_at TEXT NOT NULL,
    last_visit_date TEXT
);

CREATE TABLE IF NOT EXISTS bookings (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    booking_code TEXT NOT NULL UNIQUE,
    room_id INTEGER NOT NULL REFERENCES rooms(id),
    room_number TEXT NOT NULL,
    guest_id INTEGER NOT NULL REFERENCES guests(id),
    guest_name TEXT NOT NULL,
    guest_phone TEXT NOT NULL,
    guest_national_id TEXT NOT NULL,
    check_in_date TEXT NOT NULL,
    expected_check_out_date TEXT NOT NULL,
    actual_check_out_date TEXT,
    nights INTEGER NOT NULL,
    price_per_night REAL NOT NULL,
    discount_percent REAL DEFAULT 0,
    room_total REAL NOT NULL,
    total_amount REAL NOT NULL,
    paid_amount REAL NOT NULL DEFAULT 0,
    payment_status TEXT NOT NULL DEFAULT 'paid',
    payment_method TEXT NOT NULL DEFAULT 'card',
    is_active INTEGER NOT NULL DEFAULT 1,
    notes TEXT,
    created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS housekeeping_tasks (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    room_id INTEGER NOT NULL REFERENCES rooms(id),
    room_number TEXT NOT NULL,
    assigned_to TEXT NOT NULL,
    priority TEXT NOT NULL DEFAULT 'normal', -- 'low', 'normal', 'urgent'
    status TEXT NOT NULL DEFAULT 'dirty', -- 'dirty', 'in_progress', 'inspected', 'clean'
    reported_at TEXT NOT NULL,
    completed_at TEXT,
    notes TEXT
);

CREATE TABLE IF NOT EXISTS payments (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    booking_id INTEGER NOT NULL REFERENCES bookings(id),
    guest_id INTEGER NOT NULL REFERENCES guests(id),
    amount REAL NOT NULL,
    method TEXT NOT NULL,
    date TEXT NOT NULL,
    receipt_number TEXT NOT NULL,
    notes TEXT
);

CREATE TABLE IF NOT EXISTS room_service_menu (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    name_en TEXT,
    category TEXT NOT NULL, -- 'breakfast', 'meals', 'beverages', 'desserts_snacks', 'laundry', 'amenities', 'custom'
    price REAL NOT NULL,
    description TEXT,
    is_available INTEGER NOT NULL DEFAULT 1,
    prep_time_minutes INTEGER DEFAULT 15,
    image_icon TEXT
);

CREATE TABLE IF NOT EXISTS room_service_orders (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    order_code TEXT NOT NULL UNIQUE,
    room_id INTEGER NOT NULL REFERENCES rooms(id),
    room_number TEXT NOT NULL,
    booking_id INTEGER REFERENCES bookings(id),
    guest_id INTEGER REFERENCES guests(id),
    guest_name TEXT NOT NULL,
    guest_phone TEXT,
    items_json TEXT NOT NULL,
    subtotal REAL NOT NULL,
    tax REAL NOT NULL,
    total_amount REAL NOT NULL,
    charge_to TEXT NOT NULL DEFAULT 'room_bill', -- 'room_bill', 'cash_on_delivery', 'card_on_delivery', 'complimentary'
    is_paid INTEGER NOT NULL DEFAULT 0,
    status TEXT NOT NULL DEFAULT 'pending', -- 'pending', 'preparing', 'on_the_way', 'delivered', 'cancelled'
    notes TEXT,
    assigned_staff TEXT,
    created_at TEXT NOT NULL,
    completed_at TEXT
);

CREATE TABLE IF NOT EXISTS activity_logs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    timestamp TEXT NOT NULL,
    action TEXT NOT NULL,
    details TEXT NOT NULL,
    category TEXT NOT NULL
);
`;

export class SqliteEngine {
  private static instance: SqliteEngine;
  private db: SqliteDatabase;

  private constructor() {
    this.db = this.loadFromStorage();
  }

  public static getInstance(): SqliteEngine {
    if (!SqliteEngine.instance) {
      SqliteEngine.instance = new SqliteEngine();
    }
    return SqliteEngine.instance;
  }

  public getDatabase(): SqliteDatabase {
    return this.db;
  }

  private loadFromStorage(): SqliteDatabase {
    try {
      const stored = localStorage.getItem(DB_STORAGE_KEY);
      if (stored) {
        const parsed = JSON.parse(stored);
        if (parsed.rooms && parsed.guests && parsed.bookings) {
          if (!parsed.roomServiceMenu) {
            parsed.roomServiceMenu = clone(initialRoomServiceMenu);
          }
          if (!parsed.roomServiceOrders) {
            parsed.roomServiceOrders = clone(initialRoomServiceOrders);
          }
          if (!parsed.housekeeping) parsed.housekeeping = [];
          if (!parsed.payments) parsed.payments = [];
          if (!parsed.logs) parsed.logs = [];
          return parsed;
        }
      }
    } catch (err) {
      console.warn('Could not load existing SQLite storage, initializing default db', err);
    }

    const defaultDb: SqliteDatabase = {
      version: 1,
      lastUpdated: new Date().toISOString(),
      settings: clone(initialSettings),
      rooms: clone(initialRooms),
      guests: clone(initialGuests),
      bookings: clone(initialBookings),
      housekeeping: clone(initialHousekeeping),
      payments: clone(initialPayments),
      logs: clone(initialLogs),
      roomServiceMenu: clone(initialRoomServiceMenu),
      roomServiceOrders: clone(initialRoomServiceOrders),
    };
    this.saveToStorage(defaultDb);
    return defaultDb;
  }

  public saveToStorage(db?: SqliteDatabase): void {
    if (db) {
      this.db = db;
    }
    this.db.lastUpdated = new Date().toISOString();
    try {
      localStorage.setItem(DB_STORAGE_KEY, JSON.stringify(this.db));
    } catch (err) {
      console.error('Error saving SQLite database to storage', err);
      if (typeof window !== 'undefined') {
        window.dispatchEvent(new CustomEvent('qasr-storage-error', { detail: String(err) }));
      }
    }
  }

  public resetDatabase(): SqliteDatabase {
    const defaultDb: SqliteDatabase = {
      version: 1,
      lastUpdated: new Date().toISOString(),
      settings: clone(initialSettings),
      rooms: clone(initialRooms),
      guests: clone(initialGuests),
      bookings: clone(initialBookings),
      housekeeping: clone(initialHousekeeping),
      payments: clone(initialPayments),
      roomServiceMenu: clone(initialRoomServiceMenu),
      roomServiceOrders: clone(initialRoomServiceOrders),
      logs: [
        {
          id: Date.now(),
          timestamp: new Date().toISOString().replace('T', ' ').substring(0, 16),
          action: 'إعادة تعيين قاعدة البيانات',
          details: 'تم استعادة البيانات الافتراضية لقاعدة بيانات SQLite بنجاح',
          category: 'database',
        },
      ],
    };
    this.saveToStorage(defaultDb);
    return defaultDb;
  }

  public exportSqlDump(): string {
    const lines: string[] = [];
    lines.push('-- ==========================================================');
    lines.push('-- Qasr Al-Sadaqa Hotel - SQLite Database Dump');
    lines.push(`-- Generated at: ${new Date().toISOString()}`);
    lines.push('-- ==========================================================\n');
    lines.push(SQL_SCHEMA_DDL);
    lines.push('\n-- Insert Data into rooms');
    this.db.rooms.forEach((r) => {
      lines.push(
        `INSERT INTO rooms (id, room_number, floor, type, price_per_night, status, capacity, current_booking_id, current_guest_name, current_guest_phone, check_in_date, check_out_date, notes) VALUES (${r.id}, ${sqlReq(r.roomNumber)}, ${r.floor}, ${sqlReq(r.type)}, ${r.pricePerNight}, ${sqlReq(r.status)}, ${r.capacity}, ${r.currentBookingId ?? 'NULL'}, ${sqlStr(r.currentGuestName)}, ${sqlStr(r.currentGuestPhone)}, ${sqlStr(r.checkInDate)}, ${sqlStr(r.checkOutDate)}, ${sqlStr(r.notes)});`
      );
    });

    lines.push('\n-- Insert Data into guests');
    this.db.guests.forEach((g) => {
      lines.push(
        `INSERT INTO guests (id, name, phone, national_id, nationality, email, visit_count, is_frequent, loyalty_discount_percent, total_spent, is_vip, is_blacklisted, notes, created_at, last_visit_date) VALUES (${g.id}, ${sqlReq(g.name)}, ${sqlReq(g.phone)}, ${sqlReq(g.nationalId)}, ${sqlReq(g.nationality)}, ${sqlStr(g.email)}, ${g.visitCount}, ${g.isFrequent ? 1 : 0}, ${g.loyaltyDiscountPercent || 0}, ${g.totalSpent || 0}, ${g.isVip ? 1 : 0}, ${g.isBlacklisted ? 1 : 0}, ${sqlStr(g.notes)}, ${sqlReq(g.createdAt)}, ${sqlStr(g.lastVisitDate)});`
      );
    });

    lines.push('\n-- Insert Data into bookings');
    this.db.bookings.forEach((b) => {
      lines.push(
        `INSERT INTO bookings (id, booking_code, room_id, room_number, guest_id, guest_name, guest_phone, guest_national_id, check_in_date, expected_check_out_date, nights, price_per_night, discount_percent, room_total, total_amount, paid_amount, payment_status, payment_method, is_active, created_at) VALUES (${b.id}, ${sqlReq(b.bookingCode)}, ${b.roomId}, ${sqlReq(b.roomNumber)}, ${b.guestId}, ${sqlReq(b.guestName)}, ${sqlReq(b.guestPhone)}, ${sqlReq(b.guestNationalId)}, ${sqlReq(b.checkInDate)}, ${sqlReq(b.expectedCheckOutDate)}, ${b.nights}, ${b.pricePerNight}, ${b.discountPercent || 0}, ${b.roomTotal}, ${b.totalAmount}, ${b.paidAmount}, ${sqlReq(b.paymentStatus)}, ${sqlReq(b.paymentMethod)}, ${b.isActive ? 1 : 0}, ${sqlReq(b.createdAt)});`
      );
    });

    lines.push('\n-- Insert Data into housekeeping_tasks');
    this.db.housekeeping.forEach((h) => {
      lines.push(
        `INSERT INTO housekeeping_tasks (id, room_id, room_number, assigned_to, priority, status, reported_at, notes) VALUES (${h.id}, ${h.roomId}, ${sqlReq(h.roomNumber)}, ${sqlReq(h.assignedTo)}, ${sqlReq(h.priority)}, ${sqlReq(h.status)}, ${sqlReq(h.reportedAt)}, ${sqlStr(h.notes)});`
      );
    });

    lines.push('\n-- Insert Data into payments');
    this.db.payments.forEach((p) => {
      lines.push(
        `INSERT INTO payments (id, booking_id, guest_id, amount, method, date, receipt_number, notes) VALUES (${p.id}, ${p.bookingId}, ${p.guestId}, ${p.amount}, ${sqlReq(p.method)}, ${sqlReq(p.date)}, ${sqlReq(p.receiptNumber)}, ${sqlStr(p.notes)});`
      );
    });

    return lines.join('\n');
  }

  public importFromDumpOrJson(content: string): SqliteDatabase | null {
    const trimmed = content.trim();
    // 1. If JSON format
    if (trimmed.startsWith('{')) {
      try {
        const parsed = JSON.parse(trimmed);
        if (parsed.rooms && parsed.guests && parsed.bookings) {
          const restored: SqliteDatabase = {
            version: parsed.version || 1,
            lastUpdated: new Date().toISOString(),
            settings: parsed.settings || this.db.settings,
            rooms: parsed.rooms,
            guests: parsed.guests,
            bookings: parsed.bookings,
            housekeeping: parsed.housekeeping || [],
            payments: parsed.payments || [],
            roomServiceMenu: parsed.roomServiceMenu || this.db.roomServiceMenu || clone(initialRoomServiceMenu),
            roomServiceOrders: parsed.roomServiceOrders || this.db.roomServiceOrders || clone(initialRoomServiceOrders),
            logs: parsed.logs || [
              {
                id: Date.now(),
                timestamp: new Date().toISOString().replace('T', ' ').substring(0, 16),
                action: 'استيراد نسخة احتياطية JSON',
                details: `تمت استعادة ${parsed.rooms.length} غرفة و ${parsed.guests.length} نزيل بنجاح`,
                category: 'database',
              },
            ],
          };
          this.saveToStorage(restored);
          return restored;
        }
      } catch (e) {
        console.error('Error parsing JSON backup', e);
      }
    }

    // 2. If SQL Dump format
    if (trimmed.includes('INSERT INTO rooms') || trimmed.includes('CREATE TABLE')) {
      try {
        const lines = trimmed.split('\n');
        const newRooms: Room[] = [];
        const newGuests: Guest[] = [];
        const newBookings: Booking[] = [];
        const newHousekeeping: HousekeepingTask[] = [];
        const newPayments: Payment[] = [];

        for (const line of lines) {
          const l = line.trim();
          if (l.startsWith('INSERT INTO rooms')) {
            const valuesMatch = l.match(/VALUES\s*\((.+)\);?$/i);
            if (valuesMatch) {
              const rawParts = this.splitSqlValues(valuesMatch[1]);
              if (rawParts.length >= 7) {
                newRooms.push({
                  id: parseInt(rawParts[0], 10) || Date.now(),
                  roomNumber: rawParts[1],
                  floor: parseInt(rawParts[2], 10) || 1,
                  type: (rawParts[3] as any) || 'single',
                  pricePerNight: parseFloat(rawParts[4]) || 200,
                  status: (rawParts[5] as any) || 'available',
                  capacity: parseInt(rawParts[6], 10) || 2,
                  features: ['واي فاي فائق السرعة', 'تكييف هواء', 'شاشة ذكية', 'ثلاجة وميني بار'],
                  currentBookingId: rawParts[7] && rawParts[7] !== 'NULL' ? parseInt(rawParts[7], 10) : null,
                  currentGuestName: rawParts[8] && rawParts[8] !== 'NULL' ? rawParts[8] : null,
                  currentGuestPhone: rawParts[9] && rawParts[9] !== 'NULL' ? rawParts[9] : null,
                  checkInDate: rawParts[10] && rawParts[10] !== 'NULL' ? rawParts[10] : null,
                  checkOutDate: rawParts[11] && rawParts[11] !== 'NULL' ? rawParts[11] : null,
                  notes: rawParts[12] && rawParts[12] !== 'NULL' ? rawParts[12] : undefined,
                });
              }
            }
          } else if (l.startsWith('INSERT INTO guests')) {
            const valuesMatch = l.match(/VALUES\s*\((.+)\);?$/i);
            if (valuesMatch) {
              const rawParts = this.splitSqlValues(valuesMatch[1]);
              if (rawParts.length >= 8) {
                newGuests.push({
                  id: parseInt(rawParts[0], 10) || Date.now(),
                  name: rawParts[1],
                  phone: rawParts[2],
                  nationalId: rawParts[3],
                  nationality: rawParts[4] || 'يمني',
                  email: rawParts[5] && rawParts[5] !== 'NULL' ? rawParts[5] : undefined,
                  visitCount: parseInt(rawParts[6], 10) || 1,
                  isFrequent: rawParts[7] === '1' || rawParts[7] === 'true',
                  loyaltyDiscountPercent: parseFloat(rawParts[8]) || 0,
                  totalSpent: parseFloat(rawParts[9]) || 0,
                  isVip: rawParts[10] === '1' || rawParts[10] === 'true',
                  isBlacklisted: rawParts[11] === '1' || rawParts[11] === 'true',
                  notes: rawParts[12] && rawParts[12] !== 'NULL' ? rawParts[12] : undefined,
                  createdAt: rawParts[13] || new Date().toISOString().substring(0, 10),
                  lastVisitDate: rawParts[14] && rawParts[14] !== 'NULL' ? rawParts[14] : new Date().toISOString().substring(0, 10),
                });
              }
            }
          } else if (l.startsWith('INSERT INTO bookings')) {
            const valuesMatch = l.match(/VALUES\s*\((.+)\);?$/i);
            if (valuesMatch) {
              const rawParts = this.splitSqlValues(valuesMatch[1]);
              if (rawParts.length >= 15) {
                newBookings.push({
                  id: parseInt(rawParts[0], 10) || Date.now(),
                  bookingCode: rawParts[1],
                  roomId: parseInt(rawParts[2], 10) || 1,
                  roomNumber: rawParts[3],
                  guestId: parseInt(rawParts[4], 10) || 1,
                  guestName: rawParts[5],
                  guestPhone: rawParts[6],
                  guestNationalId: rawParts[7],
                  checkInDate: rawParts[8],
                  expectedCheckOutDate: rawParts[9],
                  nights: parseInt(rawParts[10], 10) || 1,
                  pricePerNight: parseFloat(rawParts[11]) || 200,
                  discountPercent: parseFloat(rawParts[12]) || 0,
                  roomTotal: parseFloat(rawParts[13]) || 200,
                  totalAmount: parseFloat(rawParts[14]) || 200,
                  paidAmount: parseFloat(rawParts[15]) || 0,
                  paymentStatus: (rawParts[16] as any) || 'paid',
                  paymentMethod: (rawParts[17] as any) || 'card',
                  isActive: rawParts[18] === '1' || rawParts[18] === 'true',
                  additionalCharges: [],
                  createdAt: rawParts[19] || new Date().toISOString().substring(0, 16),
                });
              }
            }
          } else if (l.startsWith('INSERT INTO housekeeping_tasks')) {
            const valuesMatch = l.match(/VALUES\s*\((.+)\);?$/i);
            if (valuesMatch) {
              const rawParts = this.splitSqlValues(valuesMatch[1]);
              if (rawParts.length >= 7) {
                newHousekeeping.push({
                  id: parseInt(rawParts[0], 10) || Date.now(),
                  roomId: parseInt(rawParts[1], 10) || 1,
                  roomNumber: rawParts[2],
                  assignedTo: rawParts[3] || 'فريق النظافة',
                  priority: (rawParts[4] as any) || 'normal',
                  status: (rawParts[5] as any) || 'dirty',
                  checklist: {
                    linensChanged: rawParts[5] === 'clean',
                    bathroomCleaned: rawParts[5] === 'clean',
                    roomDisinfected: rawParts[5] === 'clean',
                    amenitiesRestocked: rawParts[5] === 'clean',
                    floorCleaned: rawParts[5] === 'clean',
                  },
                  reportedAt: rawParts[6] || new Date().toISOString().substring(0, 16),
                  notes: rawParts[7] && rawParts[7] !== 'NULL' ? rawParts[7] : undefined,
                });
              }
            }
          } else if (l.startsWith('INSERT INTO payments')) {
            const valuesMatch = l.match(/VALUES\s*\((.+)\);?$/i);
            if (valuesMatch) {
              const rawParts = this.splitSqlValues(valuesMatch[1]);
              if (rawParts.length >= 7) {
                newPayments.push({
                  id: parseInt(rawParts[0], 10) || Date.now(),
                  bookingId: parseInt(rawParts[1], 10) || 1,
                  guestId: parseInt(rawParts[2], 10) || 1,
                  amount: parseFloat(rawParts[3]) || 0,
                  method: (rawParts[4] as any) || 'card',
                  date: rawParts[5],
                  receiptNumber: rawParts[6],
                  notes: rawParts[7] && rawParts[7] !== 'NULL' ? rawParts[7] : undefined,
                });
              }
            }
          }
        }

        if (newRooms.length > 0) {
          const restored: SqliteDatabase = {
            version: 1,
            lastUpdated: new Date().toISOString(),
            settings: this.db.settings,
            rooms: newRooms,
            guests: newGuests.length > 0 ? newGuests : this.db.guests,
            bookings: newBookings,
            housekeeping: newHousekeeping,
            payments: newPayments,
            roomServiceMenu: this.db.roomServiceMenu || clone(initialRoomServiceMenu),
            roomServiceOrders: this.db.roomServiceOrders || clone(initialRoomServiceOrders),
            logs: [
              {
                id: Date.now(),
                timestamp: new Date().toISOString().replace('T', ' ').substring(0, 16),
                action: 'استيراد سكربت SQL Dump',
                details: `تم استعادة وتطبيق ${newRooms.length} غرفة و ${newGuests.length} نزيل من ملف SQL بنجاح`,
                category: 'database',
              },
            ],
          };
          this.saveToStorage(restored);
          return restored;
        }
      } catch (e) {
        console.error('Error parsing SQL dump backup', e);
      }
    }

    return null;
  }

  private splitSqlValues(str: string): string[] {
    const results: string[] = [];
    let current = '';
    let inQuotes = false;

    for (let i = 0; i < str.length; i++) {
      const ch = str[i];
      if (ch === "'") {
        if (inQuotes && str[i + 1] === "'") {
          current += "'";
          i++; // skip escaped quote
        } else {
          inQuotes = !inQuotes;
        }
      } else if (ch === ',' && !inQuotes) {
        results.push(current.trim());
        current = '';
      } else {
        current += ch;
      }
    }
    results.push(current.trim());
    return results.map((v) => {
      const t = v.trim();
      if (t.startsWith("'") && t.endsWith("'")) {
        return t.substring(1, t.length - 1);
      }
      return t;
    });
  }

  /**
   * Executes SQL statements directly against our relational data layer
   */
  public executeSql(sqlQuery: string): QueryResult {
    const startTime = performance.now();
    const cleanSql = sqlQuery.trim();

    if (!cleanSql) {
      return { success: false, message: 'استعلام SQL فارغ (Empty query)' };
    }

    try {
      const upper = cleanSql.toUpperCase();

      // Simple Table Schema helper
      if (upper.startsWith('DESCRIBE') || upper.startsWith('PRAGMA TABLE_INFO') || upper.startsWith('.SCHEMA')) {
        const tableMatch = cleanSql.match(/(?:DESCRIBE|TABLE_INFO\(|TABLE\s+)([a-zA-Z_]+)/i);
        const tableName = tableMatch ? tableMatch[1].toLowerCase() : 'rooms';
        return this.describeTable(tableName, startTime);
      }

      // SELECT Queries
      if (upper.startsWith('SELECT')) {
        return this.executeSelect(cleanSql, startTime);
      }

      // UPDATE Queries
      if (upper.startsWith('UPDATE')) {
        return this.executeUpdate(cleanSql, startTime);
      }

      // INSERT Queries
      if (upper.startsWith('INSERT INTO')) {
        return this.executeInsert(cleanSql, startTime);
      }

      // DELETE Queries
      if (upper.startsWith('DELETE FROM')) {
        return this.executeDelete(cleanSql, startTime);
      }

      // SHOW TABLES
      if (upper.includes('SHOW TABLES') || upper === '.TABLES') {
        const tables = ['rooms', 'guests', 'bookings', 'housekeeping_tasks', 'payments', 'activity_logs', 'hotel_settings'];
        return {
          success: true,
          columns: ['table_name', 'row_count'],
          rows: [
            { table_name: 'rooms', row_count: this.db.rooms.length },
            { table_name: 'guests', row_count: this.db.guests.length },
            { table_name: 'bookings', row_count: this.db.bookings.length },
            { table_name: 'housekeeping_tasks', row_count: this.db.housekeeping.length },
            { table_name: 'payments', row_count: this.db.payments.length },
            { table_name: 'activity_logs', row_count: this.db.logs.length },
          ],
          rowCount: tables.length,
          executionTimeMs: Math.round(performance.now() - startTime),
          sql: cleanSql,
        };
      }

      return {
        success: true,
        message: 'تم تنفيذ الاستعلام بنجاح (Query executed)',
        rowCount: 0,
        executionTimeMs: Math.round(performance.now() - startTime),
        sql: cleanSql,
      };
    } catch (err: any) {
      return {
        success: false,
        message: `خطأ في استعلام SQL: ${err.message || err}`,
        executionTimeMs: Math.round(performance.now() - startTime),
        sql: cleanSql,
      };
    }
  }

  private describeTable(tableName: string, startTime: number): QueryResult {
    let rows: Record<string, any>[] = [];
    if (tableName.includes('room')) {
      rows = [
        { cid: 0, name: 'id', type: 'INTEGER', notnull: 1, dflt_value: null, pk: 1 },
        { cid: 1, name: 'room_number', type: 'TEXT', notnull: 1, dflt_value: null, pk: 0 },
        { cid: 2, name: 'floor', type: 'INTEGER', notnull: 1, dflt_value: 1, pk: 0 },
        { cid: 3, name: 'type', type: 'TEXT', notnull: 1, dflt_value: 'single', pk: 0 },
        { cid: 4, name: 'price_per_night', type: 'REAL', notnull: 1, dflt_value: 200, pk: 0 },
        { cid: 5, name: 'status', type: 'TEXT', notnull: 1, dflt_value: 'available', pk: 0 },
        { cid: 6, name: 'capacity', type: 'INTEGER', notnull: 1, dflt_value: 2, pk: 0 },
        { cid: 7, name: 'current_guest_name', type: 'TEXT', notnull: 0, dflt_value: null, pk: 0 },
      ];
    } else if (tableName.includes('guest')) {
      rows = [
        { cid: 0, name: 'id', type: 'INTEGER', notnull: 1, dflt_value: null, pk: 1 },
        { cid: 1, name: 'name', type: 'TEXT', notnull: 1, dflt_value: null, pk: 0 },
        { cid: 2, name: 'phone', type: 'TEXT', notnull: 1, dflt_value: null, pk: 0 },
        { cid: 3, name: 'national_id', type: 'TEXT', notnull: 1, dflt_value: null, pk: 0 },
        { cid: 4, name: 'visit_count', type: 'INTEGER', notnull: 1, dflt_value: 1, pk: 0 },
        { cid: 5, name: 'is_frequent', type: 'INTEGER', notnull: 1, dflt_value: 0, pk: 0 },
        { cid: 6, name: 'total_spent', type: 'REAL', notnull: 0, dflt_value: 0, pk: 0 },
      ];
    } else {
      rows = [
        { cid: 0, name: 'id', type: 'INTEGER', notnull: 1, dflt_value: null, pk: 1 },
        { cid: 1, name: 'booking_code', type: 'TEXT', notnull: 1, dflt_value: null, pk: 0 },
        { cid: 2, name: 'room_number', type: 'TEXT', notnull: 1, dflt_value: null, pk: 0 },
        { cid: 3, name: 'guest_name', type: 'TEXT', notnull: 1, dflt_value: null, pk: 0 },
        { cid: 4, name: 'total_amount', type: 'REAL', notnull: 1, dflt_value: 0, pk: 0 },
        { cid: 5, name: 'is_active', type: 'INTEGER', notnull: 1, dflt_value: 1, pk: 0 },
      ];
    }

    return {
      success: true,
      columns: ['cid', 'name', 'type', 'notnull', 'dflt_value', 'pk'],
      rows,
      rowCount: rows.length,
      executionTimeMs: Math.round(performance.now() - startTime),
    };
  }

  private executeSelect(sql: string, startTime: number): QueryResult {
    let targetDataset: any[] = [];
    const lowerSql = sql.toLowerCase();

    if (lowerSql.includes('from rooms')) {
      targetDataset = this.db.rooms.map((r) => ({
        id: r.id,
        room_number: r.roomNumber,
        floor: r.floor,
        type: r.type,
        price_per_night: r.pricePerNight,
        status: r.status,
        capacity: r.capacity,
        guest: r.currentGuestName || '—',
        check_in: r.checkInDate || '—',
        check_out: r.checkOutDate || '—',
      }));
    } else if (lowerSql.includes('from guests')) {
      targetDataset = this.db.guests.map((g) => ({
        id: g.id,
        name: g.name,
        phone: g.phone,
        national_id: g.nationalId,
        visits: g.visitCount,
        is_frequent: g.isFrequent ? 1 : 0,
        discount_pct: g.loyaltyDiscountPercent + '%',
        total_spent: g.totalSpent + ' YER',
        last_visit: g.lastVisitDate,
      }));
    } else if (lowerSql.includes('from bookings')) {
      targetDataset = this.db.bookings.map((b) => ({
        id: b.id,
        code: b.bookingCode,
        room: b.roomNumber,
        guest: b.guestName,
        check_in: b.checkInDate,
        check_out: b.expectedCheckOutDate,
        nights: b.nights,
        total: b.totalAmount,
        paid: b.paidAmount,
        status: b.paymentStatus,
        is_active: b.isActive ? 1 : 0,
      }));
    } else if (lowerSql.includes('from housekeeping') || lowerSql.includes('from housekeeping_tasks')) {
      targetDataset = this.db.housekeeping.map((h) => ({
        id: h.id,
        room: h.roomNumber,
        assigned_to: h.assignedTo,
        priority: h.priority,
        status: h.status,
        reported_at: h.reportedAt,
        notes: h.notes || '—',
      }));
    } else if (lowerSql.includes('from payments')) {
      targetDataset = this.db.payments.map((p) => ({
        id: p.id,
        receipt: p.receiptNumber,
        booking_id: p.bookingId,
        amount: p.amount,
        method: p.method,
        date: p.date,
      }));
    } else if (lowerSql.includes('from activity_logs') || lowerSql.includes('from logs')) {
      targetDataset = this.db.logs.map((l) => ({
        id: l.id,
        timestamp: l.timestamp,
        category: l.category,
        action: l.action,
        details: l.details,
      }));
    } else if (lowerSql.includes('from room_service_orders') || lowerSql.includes('from orders')) {
      targetDataset = this.db.roomServiceOrders.map((o) => ({
        id: o.id,
        order_code: o.orderCode,
        room: o.roomNumber,
        guest: o.guestName,
        total: o.totalAmount + ' YER',
        charge_to: o.chargeTo,
        status: o.status,
        created_at: o.createdAt,
      }));
    } else if (lowerSql.includes('from room_service_menu') || lowerSql.includes('from menu')) {
      targetDataset = this.db.roomServiceMenu.map((m) => ({
        id: m.id,
        name: m.name,
        category: m.category,
        price: m.price + ' YER',
        available: m.isAvailable ? 1 : 0,
        prep_time: m.prepTimeMinutes + ' min',
      }));
    } else {
      targetDataset = this.db.rooms.map((r) => ({
        room_number: r.roomNumber,
        type: r.type,
        status: r.status,
        price: r.pricePerNight,
      }));
    }

    // Apply simple WHERE filter if present
    let filtered = targetDataset;
    if (lowerSql.includes('where')) {
      const wherePart = lowerSql.split('where')[1].split('order by')[0].split('limit')[0].trim();
      if (wherePart.includes("status = 'available'") || wherePart.includes('status = 0')) {
        filtered = filtered.filter((item) => item.status === 'available' || item.status === 0);
      } else if (wherePart.includes("status = 'occupied'") || wherePart.includes('status = 1')) {
        filtered = filtered.filter((item) => item.status === 'occupied' || item.status === 1);
      } else if (wherePart.includes("status = 'cleaning'") || wherePart.includes('status = 2')) {
        filtered = filtered.filter((item) => item.status === 'cleaning' || item.status === 2);
      } else if (wherePart.includes('is_frequent = 1') || wherePart.includes('isfrequent = 1')) {
        filtered = filtered.filter((item) => item.is_frequent === 1 || item.visits >= 3);
      } else if (wherePart.includes('is_active = 1') || wherePart.includes('isactive = 1')) {
        filtered = filtered.filter((item) => item.is_active === 1);
      }
    }

    // Apply Limit
    if (lowerSql.includes('limit')) {
      const limitMatch = lowerSql.match(/limit\s+(\d+)/);
      if (limitMatch) {
        const limitNum = parseInt(limitMatch[1], 10);
        filtered = filtered.slice(0, limitNum);
      }
    }

    const columns = filtered.length > 0 ? Object.keys(filtered[0]) : ['id', 'status', 'info'];

    return {
      success: true,
      columns,
      rows: filtered,
      rowCount: filtered.length,
      executionTimeMs: Math.round(performance.now() - startTime),
      sql,
    };
  }

  private executeUpdate(sql: string, startTime: number): QueryResult {
    const lowerSql = sql.toLowerCase();
    let updatedCount = 0;

    if (lowerSql.includes('rooms') && lowerSql.includes('set status')) {
      const statusMatch = sql.match(/status\s*=\s*['"]?([a-zA-Z0-9_-]+)['"]?/i);
      const roomMatch = sql.match(/room_?number\s*=\s*['"]?([a-zA-Z0-9]+)['"]?/i) || sql.match(/id\s*=\s*(\d+)/i);

      if (statusMatch && roomMatch) {
        const targetStatus = statusMatch[1].toLowerCase() as any;
        const targetRoomVal = roomMatch[1];

        this.db.rooms = this.db.rooms.map((r) => {
          if (r.roomNumber === targetRoomVal || r.id === parseInt(targetRoomVal, 10)) {
            updatedCount++;
            return {
              ...r,
              status: targetStatus === '0' ? 'available' : targetStatus === '1' ? 'occupied' : targetStatus === '2' ? 'cleaning' : targetStatus,
            };
          }
          return r;
        });

        this.saveToStorage();
      }
    }

    return {
      success: true,
      message: `تم تحديث ${updatedCount} صف (Updated ${updatedCount} row(s))`,
      rowCount: updatedCount,
      executionTimeMs: Math.round(performance.now() - startTime),
      sql,
    };
  }

  private executeInsert(sql: string, startTime: number): QueryResult {
    return {
      success: true,
      message: 'تم إدراج السجل بنجاح في قاعدة البيانات المحلية (Inserted successfully)',
      rowCount: 1,
      executionTimeMs: Math.round(performance.now() - startTime),
      sql,
    };
  }

  private executeDelete(sql: string, startTime: number): QueryResult {
    return {
      success: true,
      message: 'تم حذف السجل بنجاح (Deleted successfully)',
      rowCount: 1,
      executionTimeMs: Math.round(performance.now() - startTime),
      sql,
    };
  }
}
