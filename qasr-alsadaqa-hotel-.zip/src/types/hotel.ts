export type ActiveTab =
  | 'rooms'
  | 'reservations'
  | 'room_service'
  | 'reports'
  | 'finance'
  | 'system_admin'
  | 'guests'
  | 'housekeeping'
  | 'archive'
  | 'custody'
  | 'messages'
  | 'logs';

export type RoomStatus = 'available' | 'occupied' | 'cleaning' | 'maintenance';
export type RoomType = 'single' | 'double' | 'triple' | 'suite' | 'vip_deluxe';

export interface Room {
  id: number;
  roomNumber: string;
  floor: number;
  type: RoomType;
  pricePerNight: number;
  status: RoomStatus;
  capacity: number;
  features: string[];
  currentBookingId?: number | null;
  currentGuestName?: string | null;
  currentGuestPhone?: string | null;
  checkInDate?: string | null;
  checkOutDate?: string | null;
  notes?: string;
}

export interface Guest {
  id: number;
  name: string;
  phone: string;
  nationalId: string;
  nationality: string;
  email?: string;
  visitCount: number;
  isFrequent: boolean; // Auto-set when visitCount >= threshold
  loyaltyDiscountPercent: number; // e.g. 10%
  totalSpent: number;
  isVip: boolean;
  isBlacklisted?: boolean;
  notes?: string;
  photo?: string; // compressed JPEG data URL — personal photo
  idImage?: string; // compressed JPEG data URL — ID / passport
  createdAt: string;
  lastVisitDate: string;
}

export type PaymentMethod = 'cash' | 'card' | 'transfer' | 'unpaid';

export interface Payment {
  id: number;
  bookingId: number;
  guestId: number;
  amount: number;
  method: PaymentMethod;
  date: string;
  receiptNumber: string;
  notes?: string;
}

/** A person staying in the room together with the main guest. */
export interface Companion {
  id: string;
  name: string;
  relation: string;
  nationalId?: string;
  phone?: string;
  age?: number;
}

export interface AdditionalCharge {
  id: string;
  description: string;
  amount: number;
  date: string;
}

export interface Booking {
  id: number;
  bookingCode: string;
  roomId: number;
  roomNumber: string;
  guestId: number;
  guestName: string;
  guestPhone: string;
  guestNationalId: string;
  checkInDate: string; // ISO string or YYYY-MM-DD HH:mm
  expectedCheckOutDate: string;
  actualCheckOutDate?: string | null;
  nights: number;
  pricePerNight: number;
  discountPercent: number;
  roomTotal: number;
  companions?: Companion[];
  additionalCharges: AdditionalCharge[];
  totalAmount: number;
  paidAmount: number;
  paymentStatus: 'paid' | 'partial' | 'pending';
  paymentMethod: PaymentMethod;
  isActive: boolean; // true if currently occupied/active
  notes?: string;
  createdAt: string;
}

export type CleaningPriority = 'normal' | 'urgent' | 'low';
export type CleaningStatus = 'dirty' | 'in_progress' | 'inspected' | 'clean';

export interface HousekeepingTask {
  id: number;
  roomId: number;
  roomNumber: string;
  assignedTo: string;
  priority: CleaningPriority;
  status: CleaningStatus;
  checklist: {
    linensChanged: boolean;
    bathroomCleaned: boolean;
    roomDisinfected: boolean;
    amenitiesRestocked: boolean;
    floorCleaned: boolean;
  };
  notes?: string;
  reportedAt: string;
  completedAt?: string | null;
}

export type NotificationType =
  | 'overdue_checkout'
  | 'checkout_today'
  | 'cleaning_needed'
  | 'frequent_guest_arrival'
  | 'occupancy_alert'
  | 'system';

export interface HotelNotification {
  id: string;
  type: NotificationType;
  title: string;
  message: string;
  roomId?: number;
  roomNumber?: string;
  bookingId?: number;
  timestamp: string;
  isRead: boolean;
  severity: 'info' | 'warning' | 'danger' | 'success';
}

export interface HotelSettings {
  hotelName: string;
  hotelNameEn: string;
  address: string;
  phone: string;
  currency: string;
  currencySymbol: string;
  taxRatePercent: number;
  frequentGuestThreshold: number; // default 3 visits
  defaultLoyaltyDiscount: number; // default 10%
  checkInTime: string; // default '14:00'
  checkOutTime: string; // default '12:00'
  enableAudioAlerts: boolean;
  vatNumber?: string;
  commercialRegistration?: string;
}

export interface ActivityLog {
  id: number;
  timestamp: string;
  action: string;
  details: string;
  category: 'booking' | 'room' | 'guest' | 'housekeeping' | 'payment' | 'database' | 'room_service' | 'finance' | 'staff';
}

export type RoomServiceCategory =
  | 'breakfast'
  | 'meals'
  | 'beverages'
  | 'desserts_snacks'
  | 'laundry'
  | 'amenities'
  | 'custom';

export interface RoomServiceItem {
  id: number;
  name: string;
  nameEn?: string;
  category: RoomServiceCategory;
  price: number;
  description?: string;
  isAvailable: boolean;
  prepTimeMinutes?: number;
  imageIcon?: string;
}

export interface RoomServiceOrderItem {
  itemId: number;
  name: string;
  price: number;
  quantity: number;
  notes?: string;
}

export type RoomServiceOrderStatus =
  | 'pending'
  | 'preparing'
  | 'on_the_way'
  | 'delivered'
  | 'cancelled';

export type RoomServiceChargeTo =
  | 'room_bill'
  | 'cash_on_delivery'
  | 'card_on_delivery'
  | 'complimentary';

export interface RoomServiceOrder {
  id: number;
  orderCode: string;
  roomId: number;
  roomNumber: string;
  bookingId?: number | null;
  guestId?: number | null;
  guestName: string;
  guestPhone?: string;
  items: RoomServiceOrderItem[];
  subtotal: number;
  tax: number;
  totalAmount: number;
  chargeTo: RoomServiceChargeTo;
  isPaid: boolean;
  status: RoomServiceOrderStatus;
  notes?: string;
  assignedStaff?: string;
  createdAt: string;
  completedAt?: string | null;
}

// Financial & Expense Modules (الإيرادات والمصروفات والرواتب)
export type ExpenseCategory =
  | 'salaries' // رواتب الموظفين
  | 'utilities' // فواتير كهرباء ومياه وانترنت
  | 'maintenance' // صيانة وسباكة وتكييف
  | 'supplies' // بوفيه ومشتريات ونظافة
  | 'government' // رسوم وتراخيص
  | 'other'; // مصروفات نثرية أخرى

export interface ExpenseRecord {
  id: number;
  expenseCode: string;
  title: string;
  category: ExpenseCategory;
  amount: number;
  paymentMethod: PaymentMethod;
  date: string;
  recipientName: string;
  recordedBy: string;
  notes?: string;
  invoiceNumber?: string;
}

export type OtherRevenueCategory =
  | 'laundry' // خدمات المغسلة الخارجية
  | 'minibar' // مبيعات الميني بار المباشرة
  | 'hall_rental' // تأجير قاعة المناسبات والاجتماعات
  | 'transport' // خدمات التوصيل والمطار
  | 'coffee_shop' // مبيعات الكوفي شوب المباشرة
  | 'parking' // مواقف السيارات
  | 'other';

export interface OtherRevenueRecord {
  id: number;
  revenueCode: string;
  title: string;
  category: OtherRevenueCategory;
  amount: number;
  paymentMethod: PaymentMethod;
  date: string;
  customerName?: string;
  roomNumber?: string;
  receiptNumber: string;
  recordedBy: string;
  notes?: string;
}

// Staff & Salaries Management (إدارة الموظفين والرواتب)
export type StaffRole =
  | 'receptionist'
  | 'manager'
  | 'housekeeper'
  | 'chef'
  | 'maintenance'
  | 'accountant'
  | 'security';

export interface StaffMember {
  id: number;
  name: string;
  username?: string;
  role: StaffRole;
  roleTitleAr: string;
  phone: string;
  nationalId: string;
  monthlySalary: number;
  joinDate: string;
  status: 'active' | 'on_leave' | 'resigned';
  leaveDate?: string; // date the employee left
  notes?: string;
}

export interface StaffSalaryRecord {
  id: number;
  slipCode: string;
  staffId: number;
  staffName: string;
  roleTitleAr: string;
  month: string; // e.g. "2026-08"
  baseSalary: number;
  bonus: number;
  deductions: number;
  netSalary: number;
  paymentDate: string;
  paymentMethod: PaymentMethod;
  status: 'paid' | 'pending';
  notes?: string;
}

// User Profile for the system (e.g. admin)
export interface SystemUser {
  id: number;
  username: string; // "admin"
  name: string;
  role: string;
  roleAr: string;
  email: string;
  phone: string;
  shift: string;
  lastLogin: string;
  permissions: string[];
}

// Google Drive Account Manual Link Integration
export interface GoogleAccountLink {
  id: string;
  email: string;
  displayName: string;
  avatarUrl?: string;
  isLinked: boolean;
  linkedAt?: string;
  folderName: string;
  folderId?: string;
  storageUsedMb?: number;
  storageTotalMb?: number;
  authMethod: 'manual_selection' | 'oauth_token' | 'api_sync';
  syncStatus: 'idle' | 'syncing' | 'synced' | 'error';
  lastSyncAt?: string | null;
  lastSyncError?: string | null;
  autoSyncEnabled: boolean;
}

// Automatic Backup Configuration
export type AutoBackupFrequency = '1h' | '3h' | '6h' | '12h' | '24h' | 'weekly' | 'disabled';

export interface AutoBackupConfig {
  enabled: boolean;
  frequency: AutoBackupFrequency;
  includeSqliteDb: boolean;
  includeFinance: boolean;
  includeRoomService: boolean;
  includeLogs: boolean;
  syncToGoogleDrive: boolean;
  retentionCount: number; // e.g. 10 snapshots kept
  lastBackupTime: string | null;
  nextBackupTime: string | null;
}

export interface BackupSnapshot {
  id: string;
  filename: string;
  createdAt: string;
  sizeKb: number;
  type: 'auto' | 'manual' | 'cloud_sync';
  googleAccountEmail?: string;
  googleDriveFileId?: string;
  isSyncedToGoogleDrive: boolean;
  recordsCount: {
    rooms: number;
    guests: number;
    bookings: number;
    payments: number;
    expenses: number;
    salaries: number;
    roomService: number;
    logs: number;
  };
  rawJson: string;
}



// Future (advance) reservation — becomes a real Booking when the guest checks in
export type ReservationStatus = 'confirmed' | 'checked_in' | 'cancelled' | 'no_show';

export interface FutureReservation {
  id: number;
  code: string;
  roomId: number;
  roomNumber: string;
  guestName: string;
  guestPhone: string;
  guestNationalId: string;
  nationality: string;
  arrivalDate: string; // YYYY-MM-DD
  nights: number;
  departureDate: string; // YYYY-MM-DD (exclusive: room is free again on this day)
  pricePerNight: number;
  discountPercent: number;
  totalAmount: number;
  depositPaid: number; // becomes the first payment at check-in
  paymentMethod: PaymentMethod;
  status: ReservationStatus;
  notes?: string;
  createdAt: string;
}
