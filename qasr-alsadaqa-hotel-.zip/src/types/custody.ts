export type CustodyKind = 'deposit' | 'pledge' | 'lost_found';
export type CustodyStatus = 'held' | 'returned';

export const CUSTODY_KIND_AR: Record<CustodyKind, string> = {
  deposit: 'إيداع أمانة',
  pledge: 'رهن',
  lost_found: 'مفقودات / أغراض منسية',
};

/** An item the hotel keeps for a guest (deposit, pledge, forgotten belongings). Photos live in IndexedDB. */
export interface CustodyItem {
  id: number;
  code: string; // AMN-0001
  kind: CustodyKind;
  title: string;
  description?: string;
  estimatedValue?: number;
  guestId?: number;
  guestName: string;
  guestPhone: string;
  roomNumber?: string;
  receivedAt: string;
  receivedBy: string;
  status: CustodyStatus;
  returnedAt?: string;
  returnedTo?: string;
  photoIds: string[]; // keys in the image store
  notes?: string;
}

export interface SmsLogEntry {
  id: number;
  at: string;
  guestId?: number;
  name: string;
  phone: string;
  text: string;
  kind: string;
  by: string;
}

export interface SmsDraft {
  guestId?: number;
  templateId?: string;
  text?: string;
  vars?: Record<string, string>;
}
