import React from 'react';
import { useHotel } from '../context/HotelContext';
import {
  Home,
  Calendar,
  UtensilsCrossed,
  BarChart2,
  ArrowLeftRight,
  Settings,
  User,
  HelpCircle,
  Globe,
  Power,
  Mail,
  Building2,
  Repeat,
  X,
  Cloud,
  Archive,
  Package,
  MessageSquare,
} from 'lucide-react';
import { ActiveTab } from '../types/hotel';

export const NavigationDrawer: React.FC = () => {
  const {
    isDrawerOpen,
    setIsDrawerOpen,
    activeTab,
    setActiveTab,
    currentUser,
    setIsAccountModalOpen,
    setIsHelpModalOpen,
    setIsLanguageModalOpen,
    setIsLogoutModalOpen,
    unreadNotificationCount,
    roomServiceOrders,
    setIsGoogleDriveLinkModalOpen,
    selectedGoogleAccount,
  } = useHotel();

  if (!isDrawerOpen) return null;

  const activeOrdersCount = roomServiceOrders.filter(
    (o) => o.status === 'pending' || o.status === 'preparing' || o.status === 'on_the_way'
  ).length;

  const handleNavClick = (tab: ActiveTab) => {
    setActiveTab(tab);
    setIsDrawerOpen(false);
  };

  return (
    <div className="fixed inset-0 z-50 flex" dir="rtl">
      {/* Backdrop */}
      <div
        onClick={() => setIsDrawerOpen(false)}
        className="fixed inset-0 bg-black/60 backdrop-blur-[2px] transition-opacity animate-fadeIn"
      />

      {/* Drawer Panel */}
      <aside className="relative w-[310px] sm:w-[340px] max-w-[85vw] bg-white dark:bg-slate-900 h-full flex flex-col shadow-2xl z-10 select-none overflow-hidden transition-transform animate-slideInRight">
        {/* Top Header with Sky Blue Banner */}
        <div className="bg-gradient-to-b from-sky-400 via-sky-500 to-sky-600 p-5 text-white flex flex-col justify-between shrink-0 min-h-[175px] relative">
          {/* Close button on mobile */}
          <button
            onClick={() => setIsDrawerOpen(false)}
            className="absolute top-3 left-3 p-1.5 rounded-full bg-black/10 hover:bg-black/20 text-white transition cursor-pointer"
            aria-label="إغلاق القائمة"
          >
            <X className="w-5 h-5" />
          </button>

          {/* Top Right Building Logo Box */}
          <div className="self-end mb-2">
            <div className="w-14 h-14 bg-white/20 backdrop-blur-md rounded-2xl border border-white/30 flex items-center justify-center shadow-inner">
              <Building2 className="w-9 h-9 text-white stroke-[1.75]" />
            </div>
          </div>

          {/* User Account Capsule Badge: ⇄ admin 👤 */}
          <div className="self-end w-full flex justify-end">
            <button
              onClick={() => {
                setIsDrawerOpen(false);
                setIsAccountModalOpen(true);
              }}
              title="تبديل الحساب أو عرض الملف الشخصي"
              className="inline-flex items-center gap-2.5 px-4 py-2 rounded-full bg-white/20 hover:bg-white/30 backdrop-blur-md border border-white/30 text-white text-sm font-medium transition cursor-pointer shadow-sm active:scale-95"
            >
              <Repeat className="w-4 h-4 text-white/90" />
              <span className="font-mono tracking-wide font-semibold text-white">
                {currentUser.username || 'admin'}
              </span>
              <User className="w-4 h-4 text-white/90" />
            </button>
          </div>
        </div>

        {/* Navigation Items List */}
        <div className="flex-1 overflow-y-auto py-2 divide-y divide-slate-100 dark:divide-slate-800 text-slate-700 dark:text-slate-200">
          {/* 1. الرئيسية (Home / Rooms Grid) */}
          <button
            onClick={() => handleNavClick('rooms')}
            className={`w-full px-5 py-3.5 flex items-center justify-between transition cursor-pointer text-sm font-medium ${
              activeTab === 'rooms'
                ? 'bg-sky-50 dark:bg-sky-950/40 text-sky-600 dark:text-sky-400 font-semibold'
                : 'hover:bg-slate-50 dark:hover:bg-slate-800/60'
            }`}
          >
            <span className="text-base">الرئيسية</span>
            <Home className="w-5 h-5 text-sky-500 stroke-[1.8]" />
          </button>

          {/* 2. الحجز (Bookings / Reservations) */}
          <button
            onClick={() => handleNavClick('reservations')}
            className={`w-full px-5 py-3.5 flex items-center justify-between transition cursor-pointer text-sm font-medium ${
              activeTab === 'reservations'
                ? 'bg-sky-50 dark:bg-sky-950/40 text-sky-600 dark:text-sky-400 font-semibold'
                : 'hover:bg-slate-50 dark:hover:bg-slate-800/60'
            }`}
          >
            <span className="text-base">الحجز</span>
            <Calendar className="w-5 h-5 text-sky-500 stroke-[1.8]" />
          </button>

          {/* 3. خدمة الغرف (Room Service) */}
          <button
            onClick={() => handleNavClick('room_service')}
            className={`w-full px-5 py-3.5 flex items-center justify-between transition cursor-pointer text-sm font-medium ${
              activeTab === 'room_service'
                ? 'bg-sky-50 dark:bg-sky-950/40 text-sky-600 dark:text-sky-400 font-semibold'
                : 'hover:bg-slate-50 dark:hover:bg-slate-800/60'
            }`}
          >
            <div className="flex items-center gap-2">
              <span className="text-base">خدمة الغرف</span>
              {activeOrdersCount > 0 && (
                <span className="px-2 py-0.5 text-[11px] rounded-full bg-amber-500 text-white font-bold animate-pulse">
                  {activeOrdersCount}
                </span>
              )}
            </div>
            <UtensilsCrossed className="w-5 h-5 text-sky-500 stroke-[1.8]" />
          </button>

          {/* 4. الإحصائيات (Statistics & Reports) */}
          <button
            onClick={() => handleNavClick('reports')}
            className={`w-full px-5 py-3.5 flex items-center justify-between transition cursor-pointer text-sm font-medium ${
              activeTab === 'reports'
                ? 'bg-sky-50 dark:bg-sky-950/40 text-sky-600 dark:text-sky-400 font-semibold'
                : 'hover:bg-slate-50 dark:hover:bg-slate-800/60'
            }`}
          >
            <span className="text-base">الإحصائيات</span>
            <BarChart2 className="w-5 h-5 text-sky-500 stroke-[1.8]" />
          </button>

          {/* 5. الإيرادات والمصروفات الأخرى (Revenues, Expenses, Staff Salaries) */}
          <button
            onClick={() => handleNavClick('finance')}
            className={`w-full px-5 py-3.5 flex items-center justify-between transition cursor-pointer text-sm font-medium ${
              activeTab === 'finance'
                ? 'bg-sky-50 dark:bg-sky-950/40 text-sky-600 dark:text-sky-400 font-semibold'
                : 'hover:bg-slate-50 dark:hover:bg-slate-800/60'
            }`}
          >
            <span className="text-base">الإيرادات والمصروفات الأخرى</span>
            <ArrowLeftRight className="w-5 h-5 text-sky-500 stroke-[1.8]" />
          </button>

          {/* الأرشيف اليومي والإقفالات */}
          <button
            onClick={() => handleNavClick('archive')}
            className={`w-full px-5 py-3.5 flex items-center justify-between transition cursor-pointer text-sm font-medium ${
              activeTab === 'archive'
                ? 'bg-sky-50 dark:bg-sky-950/40 text-sky-600 dark:text-sky-400 font-semibold'
                : 'hover:bg-slate-50 dark:hover:bg-slate-800/60'
            }`}
          >
            <span className="text-base">الأرشيف والإقفالات</span>
            <Archive className="w-5 h-5 text-sky-500 stroke-[1.8]" />
          </button>

          {/* الأمانات */}
          <button
            onClick={() => handleNavClick('custody')}
            className={`w-full px-5 py-3.5 flex items-center justify-between transition cursor-pointer text-sm font-medium ${
              activeTab === 'custody'
                ? 'bg-sky-50 dark:bg-sky-950/40 text-sky-600 dark:text-sky-400 font-semibold'
                : 'hover:bg-slate-50 dark:hover:bg-slate-800/60'
            }`}
          >
            <span className="text-base">الأمانات</span>
            <Package className="w-5 h-5 text-sky-500 stroke-[1.8]" />
          </button>

          {/* مراسلة العملاء (SMS) */}
          <button
            onClick={() => handleNavClick('messages')}
            className={`w-full px-5 py-3.5 flex items-center justify-between transition cursor-pointer text-sm font-medium ${
              activeTab === 'messages'
                ? 'bg-sky-50 dark:bg-sky-950/40 text-sky-600 dark:text-sky-400 font-semibold'
                : 'hover:bg-slate-50 dark:hover:bg-slate-800/60'
            }`}
          >
            <span className="text-base">مراسلة العملاء (SMS)</span>
            <MessageSquare className="w-5 h-5 text-sky-500 stroke-[1.8]" />
          </button>

          {/* 6. إدارة النظام (System Administration / Settings) */}
          <button
            onClick={() => handleNavClick('system_admin')}
            className={`w-full px-5 py-3.5 flex items-center justify-between transition cursor-pointer text-sm font-medium ${
              activeTab === 'system_admin'
                ? 'bg-sky-50 dark:bg-sky-950/40 text-sky-600 dark:text-sky-400 font-semibold'
                : 'hover:bg-slate-50 dark:hover:bg-slate-800/60'
            }`}
          >
            <span className="text-base">إدارة النظام</span>
            <Settings className="w-5 h-5 text-sky-500 stroke-[1.8]" />
          </button>

          {/* 7. النسخ الاحتياطي و Google Drive (Cloud Backup & Google Drive Integration) */}
          <button
            onClick={() => {
              setIsDrawerOpen(false);
              setIsGoogleDriveLinkModalOpen(true);
            }}
            className="w-full px-5 py-3.5 flex items-center justify-between hover:bg-slate-50 dark:hover:bg-slate-800/60 transition cursor-pointer text-sm font-medium"
          >
            <div className="flex items-center gap-2">
              <span className="text-base">النسخ الاحتياطي و Google Drive</span>
              <span className="px-2 py-0.5 text-[10px] rounded-full bg-sky-100 dark:bg-sky-950 text-sky-700 dark:text-sky-300 font-bold border border-sky-200 dark:border-sky-800">
                {selectedGoogleAccount ? selectedGoogleAccount.email.split('@')[0] : 'سحابي'}
              </span>
            </div>
            <Cloud className="w-5 h-5 text-sky-500 stroke-[1.8]" />
          </button>

          {/* 8. معلومات الحساب (Account Information) */}
          <button
            onClick={() => {
              setIsDrawerOpen(false);
              setIsAccountModalOpen(true);
            }}
            className="w-full px-5 py-3.5 flex items-center justify-between hover:bg-slate-50 dark:hover:bg-slate-800/60 transition cursor-pointer text-sm font-medium"
          >
            <span className="text-base">معلومات الحساب</span>
            <User className="w-5 h-5 text-sky-500 stroke-[1.8]" />
          </button>

          {/* 8. تعليمات (Instructions & User Guide) */}
          <button
            onClick={() => {
              setIsDrawerOpen(false);
              setIsHelpModalOpen(true);
            }}
            className="w-full px-5 py-3.5 flex items-center justify-between hover:bg-slate-50 dark:hover:bg-slate-800/60 transition cursor-pointer text-sm font-medium"
          >
            <span className="text-base">تعليمات</span>
            <HelpCircle className="w-5 h-5 text-sky-500 stroke-[1.8]" />
          </button>

          {/* 9. اللغة (Language) */}
          <button
            onClick={() => {
              setIsDrawerOpen(false);
              setIsLanguageModalOpen(true);
            }}
            className="w-full px-5 py-3.5 flex items-center justify-between hover:bg-slate-50 dark:hover:bg-slate-800/60 transition cursor-pointer text-sm font-medium"
          >
            <span className="text-base">اللغة</span>
            <Globe className="w-5 h-5 text-sky-500 stroke-[1.8]" />
          </button>
        </div>

        {/* Drawer Bottom Actions & Footer */}
        <div className="p-4 bg-slate-50 dark:bg-slate-950 border-t border-slate-100 dark:border-slate-800 space-y-3 shrink-0">
          {/* 10. تسجيل الخروج (Soft Red/Pink Pill Button) */}
          <button
            onClick={() => {
              setIsDrawerOpen(false);
              setIsLogoutModalOpen(true);
            }}
            className="w-full py-3 px-4 bg-rose-50 hover:bg-rose-100 dark:bg-rose-950/40 dark:hover:bg-rose-900/50 rounded-2xl flex items-center justify-between text-rose-600 dark:text-rose-400 font-semibold text-sm transition cursor-pointer border border-rose-100 dark:border-rose-900/40 active:scale-[0.98]"
          >
            <span className="text-base">تسجيل الخروج</span>
            <Power className="w-5 h-5 text-rose-500 stroke-[2]" />
          </button>

          {/* Hotel name footer */}
          <div className="flex items-center justify-center gap-2 pt-1 text-sky-600 dark:text-sky-400 font-mono text-xs hover:underline cursor-pointer">
            <span>فندق قصر الصداقة السياحي</span>
            <Mail className="w-4 h-4 text-rose-500 inline-block" />
          </div>
        </div>
      </aside>
    </div>
  );
};
