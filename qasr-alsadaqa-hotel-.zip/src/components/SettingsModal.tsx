import { saveText } from '../utils/saveFile';
import React, { useState, useRef } from 'react';
import { useHotel } from '../context/HotelContext';
import { HotelSettings, Room, Guest, AutoBackupFrequency } from '../types/hotel';
import {
  Settings,
  X,
  Building,
  DollarSign,
  Sparkles,
  Clock,
  Volume2,
  CheckCircle,
  Database,
  Download,
  Upload,
  FileCode,
  FileJson,
  Terminal,
  RefreshCw,
  AlertTriangle,
  HardDrive,
  Bed,
  Users,
  Plus,
  Trash2,
  ArrowLeftRight,
  FileText,
  Search,
  Shield,
  Cloud,
  CloudUpload,
  CloudDownload,
  FolderSync,
  Check,
  CheckCircle2,
  Sliders,
  ExternalLink,
  ShieldCheck,
} from 'lucide-react';

export const SettingsModal: React.FC = () => {
  const {
    isSettingsOpen,
    setIsSettingsOpen,
    settings,
    updateSettings,
    playAlertSound,
    exportDatabaseSql,
    exportDatabaseJson,
    importDatabaseJson,
    resetToDemoData,
    setIsSqlConsoleOpen,
    rooms,
    guests,
    bookings,
    deleteRoom,
    deleteGuest,
    addGuest,
    setIsAddRoomModalOpen,
    setSelectedGuestForStatement,
    setIsLinkGuestModalOpen,
    setPreselectedGuestForLink,
    setPreselectedRoomForLink,
    // Google Drive & Auto Backup
    googleAccounts,
    selectedGoogleAccount,
    selectedGoogleAccountId,
    selectActiveGoogleAccount,
    linkGoogleAccountManually,
    autoBackupConfig,
    updateAutoBackupConfig,
    backupSnapshots,
    createBackupSnapshot,
    restoreBackupSnapshot,
    syncSnapshotToGoogleDrive,
    syncAllToGoogleDriveNow,
    isSyncingToGoogleDrive,
    setIsGoogleDriveLinkModalOpen,
    setIsAutoBackupModalOpen,
  } = useHotel();

  // Tab State: 'rooms' | 'guests' | 'hotel' | 'backup'
  const [activeTab, setActiveTab] = useState<'rooms' | 'guests' | 'hotel' | 'backup'>('rooms');

  // Manual Google link quick form state
  const [showAddGoogleAccount, setShowAddGoogleAccount] = useState<boolean>(false);
  const [googleEmailInput, setGoogleEmailInput] = useState<string>('');
  const [googleNameInput, setGoogleNameInput] = useState<string>('');
  const [confirmSnapshotRestoreId, setConfirmSnapshotRestoreId] = useState<string | null>(null);

  // General Settings Form State
  const [formData, setFormData] = useState<HotelSettings>({ ...settings });
  const [isSaved, setIsSaved] = useState<boolean>(false);
  const [importStatus, setImportStatus] = useState<{ type: 'success' | 'error' | 'loading' | null; message: string }>({
    type: null,
    message: '',
  });
  const [showResetConfirm, setShowResetConfirm] = useState<boolean>(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Quick Inline Add Customer State
  const [showAddGuestForm, setShowAddGuestForm] = useState<boolean>(false);
  const [newGuestName, setNewGuestName] = useState<string>('');
  const [newGuestPhone, setNewGuestPhone] = useState<string>('');
  const [newGuestNationalId, setNewGuestNationalId] = useState<string>('');
  const [newGuestNationality, setNewGuestNationality] = useState<string>('يمني');
  const [newGuestIsVip, setNewGuestIsVip] = useState<boolean>(false);
  const [guestFeedback, setGuestFeedback] = useState<string>('');

  // Search filters
  const [roomFilterText, setRoomFilterText] = useState<string>('');
  const [guestFilterText, setGuestFilterText] = useState<string>('');

  // Delete Room / Guest confirmation state
  const [deleteConfirmRoomId, setDeleteConfirmRoomId] = useState<number | null>(null);
  const [deleteConfirmGuestId, setDeleteConfirmGuestId] = useState<number | null>(null);
  const [actionError, setActionError] = useState<string>('');

  if (!isSettingsOpen) return null;

  const handleSubmitSettings = (e: React.FormEvent) => {
    e.preventDefault();
    updateSettings(formData);
    setIsSaved(true);
    playAlertSound('success');
    setTimeout(() => {
      setIsSaved(false);
    }, 2000);
  };

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setImportStatus({
      type: 'loading',
      message: 'جاري استيراد وفحص ملف قاعدة البيانات...',
    });

    try {
      const ok = await importDatabaseJson(file);
      if (ok) {
        setImportStatus({
          type: 'success',
          message: `تم استعادة النسخة الاحتياطية بنجاح! تم تحديث بيانات الغرف والحجوزات والنزلاء.`,
        });
        playAlertSound('success');
        setTimeout(() => {
          setImportStatus({ type: null, message: '' });
        }, 4000);
      } else {
        setImportStatus({
          type: 'error',
          message: 'تعذر استيراد الملف. تأكد من أن الملف هو نسخة احتياطية صالحة (JSON) للنظام.',
        });
        playAlertSound('alert');
      }
    } catch {
      setImportStatus({
        type: 'error',
        message: 'حدث خطأ أثناء معالجة ملف النسخة الاحتياطية.',
      });
      playAlertSound('alert');
    }

    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  // Add Customer Form Submit
  const handleAddGuestSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setActionError('');
    setGuestFeedback('');

    if (!newGuestName.trim() || !newGuestPhone.trim()) {
      setActionError('يرجى تعبئة اسم العميل ورقم الجوال.');
      return;
    }

    const res = addGuest({
      name: newGuestName.trim(),
      phone: newGuestPhone.trim(),
      nationalId: newGuestNationalId.trim(),
      nationality: newGuestNationality.trim() || 'يمني',
      isVip: newGuestIsVip,
    });

    if (res.success) {
      setGuestFeedback(`تمت إضافة العميل (${res.guest?.name}) بنجاح.`);
      setNewGuestName('');
      setNewGuestPhone('');
      setNewGuestNationalId('');
      setNewGuestIsVip(false);
      setShowAddGuestForm(false);
    } else {
      setActionError(res.error || 'حدث خطأ أثناء إضافة العميل.');
    }
  };

  // Delete Room Handler
  const handleDeleteRoom = (roomId: number) => {
    setActionError('');
    const res = deleteRoom(roomId);
    if (res.success) {
      setDeleteConfirmRoomId(null);
    } else {
      setActionError(res.error || 'تعذر حذف الغرفة.');
    }
  };

  // Delete Guest Handler
  const handleDeleteGuest = (guestId: number) => {
    setActionError('');
    const res = deleteGuest(guestId);
    if (res.success) {
      setDeleteConfirmGuestId(null);
    } else {
      setActionError(res.error || 'تعذر حذف العميل.');
    }
  };

  // Filtered rooms & guests
  const filteredRooms = rooms.filter(
    (r) =>
      r.roomNumber.toLowerCase().includes(roomFilterText.toLowerCase()) ||
      r.type.toLowerCase().includes(roomFilterText.toLowerCase())
  );

  const filteredGuests = guests.filter(
    (g) =>
      g.name.toLowerCase().includes(guestFilterText.toLowerCase()) ||
      g.phone.includes(guestFilterText) ||
      g.nationalId.includes(guestFilterText)
  );

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-950/75 backdrop-blur-xs animate-fadeIn">
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl w-full max-w-4xl max-h-[92vh] overflow-y-auto shadow-2xl flex flex-col">
        {/* Top Header */}
        <div className="p-4 sm:p-5 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between bg-slate-50 dark:bg-slate-950/60 sticky top-0 z-20">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-slate-900 dark:bg-slate-800 text-white flex items-center justify-center shadow-md">
              <Settings className="w-5 h-5 text-emerald-400" />
            </div>
            <div>
              <h2 className="text-base font-bold text-slate-900 dark:text-white">إعدادات النظام والتحكم الشامل</h2>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                إدارة الغرف، إدارة العملاء، كشوفات الحساب، والنسخ الاحتياطي لقاعدة البيانات
              </p>
            </div>
          </div>

          <button
            onClick={() => setIsSettingsOpen(false)}
            className="p-1.5 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Global Error Banner */}
        {actionError && (
          <div className="m-4 p-3 rounded-xl bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-900/60 text-xs text-rose-700 dark:text-rose-300 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 shrink-0 text-rose-500" />
              <span>{actionError}</span>
            </div>
            <button onClick={() => setActionError('')} className="text-slate-400 hover:text-slate-600">
              <X className="w-3.5 h-3.5" />
            </button>
          </div>
        )}

        {/* Navigation Tabs */}
        <div className="px-4 pt-3 border-b border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-950/30 flex items-center gap-1 overflow-x-auto text-xs">
          <button
            onClick={() => setActiveTab('rooms')}
            className={`px-3.5 py-2.5 rounded-t-xl font-bold flex items-center gap-2 transition cursor-pointer border-b-2 ${
              activeTab === 'rooms'
                ? 'border-emerald-500 text-emerald-600 dark:text-emerald-400 bg-white dark:bg-slate-900'
                : 'border-transparent text-slate-500 hover:text-slate-800 dark:hover:text-slate-200'
            }`}
          >
            <Bed className="w-4 h-4" />
            <span>إدارة الغرف ({rooms.length})</span>
          </button>

          <button
            onClick={() => setActiveTab('guests')}
            className={`px-3.5 py-2.5 rounded-t-xl font-bold flex items-center gap-2 transition cursor-pointer border-b-2 ${
              activeTab === 'guests'
                ? 'border-emerald-500 text-emerald-600 dark:text-emerald-400 bg-white dark:bg-slate-900'
                : 'border-transparent text-slate-500 hover:text-slate-800 dark:hover:text-slate-200'
            }`}
          >
            <Users className="w-4 h-4" />
            <span>إدارة العملاء ({guests.length})</span>
          </button>

          <button
            onClick={() => setActiveTab('hotel')}
            className={`px-3.5 py-2.5 rounded-t-xl font-bold flex items-center gap-2 transition cursor-pointer border-b-2 ${
              activeTab === 'hotel'
                ? 'border-emerald-500 text-emerald-600 dark:text-emerald-400 bg-white dark:bg-slate-900'
                : 'border-transparent text-slate-500 hover:text-slate-800 dark:hover:text-slate-200'
            }`}
          >
            <Building className="w-4 h-4" />
            <span>هوية الفندق والولاء</span>
          </button>

          <button
            onClick={() => setActiveTab('backup')}
            className={`px-3.5 py-2.5 rounded-t-xl font-bold flex items-center gap-2 transition cursor-pointer border-b-2 ${
              activeTab === 'backup'
                ? 'border-emerald-500 text-emerald-600 dark:text-emerald-400 bg-white dark:bg-slate-900'
                : 'border-transparent text-slate-500 hover:text-slate-800 dark:hover:text-slate-200'
            }`}
          >
            <Cloud className="w-4 h-4 text-sky-500" />
            <span>النسخ الاحتياطي و Google Drive</span>
          </button>
        </div>

        {/* Tab 1: ROOMS MANAGEMENT (إضافة غرفة، حذف غرفة، ربط) */}
        {activeTab === 'rooms' && (
          <div className="p-4 sm:p-6 space-y-4">
            {/* Header Action Bar */}
            <div className="flex flex-wrap items-center justify-between gap-2">
              <div className="relative flex-1 min-w-[200px] max-w-xs">
                <Search className="w-3.5 h-3.5 absolute right-3 top-2.5 text-slate-400" />
                <input
                  type="text"
                  placeholder="بحث برقم الغرفة أو النوع..."
                  value={roomFilterText}
                  onChange={(e) => setRoomFilterText(e.target.value)}
                  className="w-full pl-3 pr-8 py-1.5 bg-slate-50 dark:bg-slate-800/60 border border-slate-300 dark:border-slate-700 rounded-lg text-xs"
                />
              </div>

              <button
                onClick={() => setIsAddRoomModalOpen(true)}
                className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg text-xs font-bold transition flex items-center gap-1.5 shadow-sm cursor-pointer"
              >
                <Plus className="w-4 h-4" />
                <span>+ إضافة غرفة جديدة</span>
              </button>
            </div>

            {/* Room List Table */}
            <div className="overflow-x-auto border border-slate-200 dark:border-slate-800 rounded-xl">
              <table className="w-full text-right text-xs">
                <thead className="bg-slate-50 dark:bg-slate-800/80 text-slate-500 dark:text-slate-400 border-b border-slate-200 dark:border-slate-800">
                  <tr>
                    <th className="p-3 font-semibold">رقم الغرفة</th>
                    <th className="p-3 font-semibold">الطابق</th>
                    <th className="p-3 font-semibold">النوع والتصنيف</th>
                    <th className="p-3 font-semibold">السعر / ليلة</th>
                    <th className="p-3 font-semibold">السعة</th>
                    <th className="p-3 font-semibold">الحالة</th>
                    <th className="p-3 font-semibold text-center">الإجراءات</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                  {filteredRooms.length === 0 ? (
                    <tr>
                      <td colSpan={7} className="p-8 text-center text-slate-400">
                        لا توجد غرف مطابقة
                      </td>
                    </tr>
                  ) : (
                    filteredRooms.map((room) => {
                      const isOccupied = room.status === 'occupied' || !!room.currentBookingId;
                      const isConfirming = deleteConfirmRoomId === room.id;

                      return (
                        <tr key={room.id} className="hover:bg-slate-50/60 dark:hover:bg-slate-800/40">
                          <td className="p-3 font-mono font-bold text-sm text-slate-900 dark:text-white">
                            #{room.roomNumber}
                          </td>
                          <td className="p-3 font-mono text-slate-500">الطابق {room.floor}</td>
                          <td className="p-3 font-medium text-slate-700 dark:text-slate-300">{room.type}</td>
                          <td className="p-3 font-bold text-emerald-600 dark:text-emerald-400">
                            {room.pricePerNight} {settings.currencySymbol}
                          </td>
                          <td className="p-3 text-slate-500">{room.capacity} أفراد</td>
                          <td className="p-3">
                            <span
                              className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                                room.status === 'available'
                                  ? 'bg-emerald-500/20 text-emerald-600 dark:text-emerald-400'
                                  : room.status === 'occupied'
                                  ? 'bg-rose-500/20 text-rose-600 dark:text-rose-400'
                                  : room.status === 'cleaning'
                                  ? 'bg-amber-500/20 text-amber-600 dark:text-amber-400'
                                  : 'bg-purple-500/20 text-purple-600 dark:text-purple-400'
                              }`}
                            >
                              {room.status === 'available'
                                ? '🟢 متاحة'
                                : room.status === 'occupied'
                                ? `🔴 مشغولة (${room.currentGuestName || 'نزيل'})`
                                : room.status === 'cleaning'
                                ? '🟡 تنظيف'
                                : '🟣 صيانة'}
                            </span>
                          </td>
                          <td className="p-3">
                            <div className="flex items-center justify-center gap-1.5">
                              {/* Link guest button */}
                              {room.status === 'available' && (
                                <button
                                  onClick={() => {
                                    setPreselectedRoomForLink(room);
                                    setIsSettingsOpen(false);
                                    setIsLinkGuestModalOpen(true);
                                  }}
                                  className="px-2.5 py-1 bg-emerald-50 dark:bg-emerald-950/40 text-emerald-700 dark:text-emerald-300 hover:bg-emerald-100 rounded text-[11px] font-semibold flex items-center gap-1 transition cursor-pointer"
                                  title="ربط عميل بالغرفة وتسكينه"
                                >
                                  <ArrowLeftRight className="w-3 h-3" />
                                  <span>ربط بعميل</span>
                                </button>
                              )}

                              {/* Delete Room Button */}
                              {isConfirming ? (
                                <div className="flex items-center gap-1">
                                  <button
                                    onClick={() => setDeleteConfirmRoomId(null)}
                                    className="px-2 py-1 text-slate-400 hover:bg-slate-100 rounded text-[10px]"
                                  >
                                    إلغاء
                                  </button>
                                  <button
                                    onClick={() => handleDeleteRoom(room.id)}
                                    className="px-2 py-1 bg-rose-600 hover:bg-rose-500 text-white rounded text-[10px] font-bold"
                                  >
                                    تأكيد الحذف
                                  </button>
                                </div>
                              ) : (
                                <button
                                  onClick={() => {
                                    if (isOccupied) {
                                      setActionError(
                                        `لا يمكن حذف الغرفة #${room.roomNumber} لأنها مشغولة بحجز نشط. يرجى تسجيل المغادرة أولاً.`
                                      );
                                    } else {
                                      setDeleteConfirmRoomId(room.id);
                                    }
                                  }}
                                  disabled={isOccupied}
                                  className={`p-1.5 rounded transition cursor-pointer ${
                                    isOccupied
                                      ? 'text-slate-300 dark:text-slate-700 cursor-not-allowed'
                                      : 'text-rose-500 hover:bg-rose-50 dark:hover:bg-rose-950/40 hover:text-rose-600'
                                  }`}
                                  title={isOccupied ? 'لا يمكن حذف غرفة مشغولة' : 'حذف الغرفة نهائياً'}
                                >
                                  <Trash2 className="w-4 h-4" />
                                </button>
                              )}
                            </div>
                          </td>
                        </tr>
                      );
                    })
                  )}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* Tab 2: GUESTS MANAGEMENT (إضافة عميل، حذف عميل، كشف حساب، ربط) */}
        {activeTab === 'guests' && (
          <div className="p-4 sm:p-6 space-y-4">
            {/* Header & Add Customer toggle */}
            <div className="flex flex-wrap items-center justify-between gap-2">
              <div className="relative flex-1 min-w-[200px] max-w-xs">
                <Search className="w-3.5 h-3.5 absolute right-3 top-2.5 text-slate-400" />
                <input
                  type="text"
                  placeholder="بحث بالاسم أو الهاتف أو الهوية..."
                  value={guestFilterText}
                  onChange={(e) => setGuestFilterText(e.target.value)}
                  className="w-full pl-3 pr-8 py-1.5 bg-slate-50 dark:bg-slate-800/60 border border-slate-300 dark:border-slate-700 rounded-lg text-xs"
                />
              </div>

              <button
                onClick={() => setShowAddGuestForm(!showAddGuestForm)}
                className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg text-xs font-bold transition flex items-center gap-1.5 shadow-sm cursor-pointer"
              >
                <Plus className="w-4 h-4" />
                <span>{showAddGuestForm ? 'إخفاء نموذج الإضافة' : '+ إضافة عميل جديد'}</span>
              </button>
            </div>

            {/* Inline Add Customer Form */}
            {showAddGuestForm && (
              <form
                onSubmit={handleAddGuestSubmit}
                className="p-4 bg-emerald-50/60 dark:bg-emerald-950/30 border border-emerald-200 dark:border-emerald-800/50 rounded-xl space-y-3 animate-fadeIn"
              >
                <div className="flex items-center justify-between border-b border-emerald-200 dark:border-emerald-800/50 pb-2">
                  <span className="text-xs font-bold text-emerald-900 dark:text-emerald-200">
                    تسجيل عميل جديد في قاعدة بيانات SQLite:
                  </span>
                  <button
                    type="button"
                    onClick={() => setShowAddGuestForm(false)}
                    className="text-xs text-slate-400 hover:text-slate-600"
                  >
                    إلغاء
                  </button>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  <div>
                    <label className="text-xs font-semibold text-slate-700 dark:text-slate-300 block mb-1">
                      اسم العميل *
                    </label>
                    <input
                      type="text"
                      placeholder="الاسم الكامل"
                      value={newGuestName}
                      onChange={(e) => setNewGuestName(e.target.value)}
                      required
                      className="w-full px-3 py-1.5 bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-lg text-xs focus:outline-emerald-500"
                    />
                  </div>

                  <div>
                    <label className="text-xs font-semibold text-slate-700 dark:text-slate-300 block mb-1">
                      رقم الجوال *
                    </label>
                    <input
                      type="tel"
                      placeholder="05XXXXXXXX"
                      value={newGuestPhone}
                      onChange={(e) => setNewGuestPhone(e.target.value)}
                      required
                      className="w-full px-3 py-1.5 bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-lg text-xs font-mono focus:outline-emerald-500"
                    />
                  </div>

                  <div>
                    <label className="text-xs font-semibold text-slate-700 dark:text-slate-300 block mb-1">
                      رقم الهوية / الإقامة
                    </label>
                    <input
                      type="text"
                      placeholder="10XXXXXXXX"
                      value={newGuestNationalId}
                      onChange={(e) => setNewGuestNationalId(e.target.value)}
                      className="w-full px-3 py-1.5 bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-lg text-xs font-mono focus:outline-emerald-500"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="text-xs font-semibold text-slate-700 dark:text-slate-300 block mb-1">
                      الجنسية
                    </label>
                    <input
                      type="text"
                      value={newGuestNationality}
                      onChange={(e) => setNewGuestNationality(e.target.value)}
                      className="w-full px-3 py-1.5 bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-lg text-xs focus:outline-emerald-500"
                    />
                  </div>

                  <div className="flex items-center gap-2 pt-5">
                    <input
                      type="checkbox"
                      id="newGuestIsVip"
                      checked={newGuestIsVip}
                      onChange={(e) => setNewGuestIsVip(e.target.checked)}
                      className="w-4 h-4 accent-amber-500 cursor-pointer"
                    />
                    <label htmlFor="newGuestIsVip" className="text-xs font-semibold text-slate-700 dark:text-slate-300 cursor-pointer">
                      تصنيف العميل كـ VIP ملكي
                    </label>
                  </div>
                </div>

                <div className="flex justify-end gap-2 pt-2 border-t border-emerald-200 dark:border-emerald-800/40">
                  <button
                    type="submit"
                    className="px-4 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg text-xs font-bold transition shadow-sm cursor-pointer"
                  >
                    حفظ العميل
                  </button>
                </div>
              </form>
            )}

            {guestFeedback && (
              <div className="p-3 rounded-xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-900/60 text-xs text-emerald-700 dark:text-emerald-300 flex items-center justify-between">
                <span>{guestFeedback}</span>
                <button onClick={() => setGuestFeedback('')} className="text-slate-400 hover:text-slate-600">
                  <X className="w-3.5 h-3.5" />
                </button>
              </div>
            )}

            {/* Customers Table */}
            <div className="overflow-x-auto border border-slate-200 dark:border-slate-800 rounded-xl">
              <table className="w-full text-right text-xs">
                <thead className="bg-slate-50 dark:bg-slate-800/80 text-slate-500 dark:text-slate-400 border-b border-slate-200 dark:border-slate-800">
                  <tr>
                    <th className="p-3 font-semibold">اسم العميل</th>
                    <th className="p-3 font-semibold">رقم الجوال</th>
                    <th className="p-3 font-semibold">الهوية / الإقامة</th>
                    <th className="p-3 font-semibold">عدد الزيارات</th>
                    <th className="p-3 font-semibold">تصنيف الولاء</th>
                    <th className="p-3 font-semibold">إجمالي المشتريات</th>
                    <th className="p-3 font-semibold text-center">الإجراءات</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                  {filteredGuests.length === 0 ? (
                    <tr>
                      <td colSpan={7} className="p-8 text-center text-slate-400">
                        لا يوجد عملاء مطابقين
                      </td>
                    </tr>
                  ) : (
                    filteredGuests.map((guest) => {
                      const isConfirming = deleteConfirmGuestId === guest.id;
                      const hasActiveStay = bookings.some((b) => b.guestId === guest.id && b.isActive);

                      return (
                        <tr key={guest.id} className="hover:bg-slate-50/60 dark:hover:bg-slate-800/40">
                          <td className="p-3 font-bold text-slate-800 dark:text-slate-200">
                            {guest.name}
                          </td>
                          <td className="p-3 font-mono text-slate-600 dark:text-slate-400">{guest.phone}</td>
                          <td className="p-3 font-mono text-slate-500">{guest.nationalId || '—'}</td>
                          <td className="p-3 font-mono">{guest.visitCount} مرات</td>
                          <td className="p-3">
                            {guest.isVip ? (
                              <span className="px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-600 dark:text-amber-300 text-[10px] font-bold border border-amber-500/30 flex items-center gap-1 w-fit">
                                <Sparkles className="w-2.5 h-2.5" /> VIP
                              </span>
                            ) : guest.isFrequent ? (
                              <span className="px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-600 text-[10px] font-bold">
                                دائم ({guest.loyaltyDiscountPercent}%)
                              </span>
                            ) : (
                              <span className="text-slate-400 text-[11px]">عادي</span>
                            )}
                          </td>
                          <td className="p-3 font-bold text-slate-900 dark:text-white">
                            {guest.totalSpent.toLocaleString()} {settings.currencySymbol}
                          </td>
                          <td className="p-3">
                            <div className="flex items-center justify-center gap-1.5">
                              {/* Account Statement Button */}
                              <button
                                onClick={() => {
                                  setSelectedGuestForStatement(guest);
                                  setIsSettingsOpen(false);
                                }}
                                className="px-2.5 py-1 bg-slate-800 hover:bg-slate-700 text-white rounded text-[11px] font-semibold flex items-center gap-1 transition cursor-pointer"
                                title="عرض وطباعة كشف حساب العميل"
                              >
                                <FileText className="w-3 h-3 text-emerald-400" />
                                <span>كشف الحساب</span>
                              </button>

                              {/* Link to Room Button */}
                              <button
                                onClick={() => {
                                  setPreselectedGuestForLink(guest);
                                  setIsSettingsOpen(false);
                                  setIsLinkGuestModalOpen(true);
                                }}
                                className="px-2.5 py-1 bg-emerald-50 dark:bg-emerald-950/40 text-emerald-700 dark:text-emerald-300 hover:bg-emerald-100 rounded text-[11px] font-semibold flex items-center gap-1 transition cursor-pointer"
                                title="ربط العميل بغرفة وتسكينه"
                              >
                                <Bed className="w-3 h-3" />
                                <span>ربط بغرفة</span>
                              </button>

                              {/* Delete Customer Button */}
                              {isConfirming ? (
                                <div className="flex items-center gap-1">
                                  <button
                                    onClick={() => setDeleteConfirmGuestId(null)}
                                    className="px-2 py-1 text-slate-400 hover:bg-slate-100 rounded text-[10px]"
                                  >
                                    إلغاء
                                  </button>
                                  <button
                                    onClick={() => handleDeleteGuest(guest.id)}
                                    className="px-2 py-1 bg-rose-600 hover:bg-rose-500 text-white rounded text-[10px] font-bold"
                                  >
                                    تأكيد الحذف
                                  </button>
                                </div>
                              ) : (
                                <button
                                  onClick={() => {
                                    if (hasActiveStay) {
                                      setActionError(
                                        `لا يمكن حذف العميل (${guest.name}) لأنه مسجل حالياً في إقامة نشطة بالفندق.`
                                      );
                                    } else {
                                      setDeleteConfirmGuestId(guest.id);
                                    }
                                  }}
                                  disabled={hasActiveStay}
                                  className={`p-1.5 rounded transition cursor-pointer ${
                                    hasActiveStay
                                      ? 'text-slate-300 dark:text-slate-700 cursor-not-allowed'
                                      : 'text-rose-500 hover:bg-rose-50 dark:hover:bg-rose-950/40 hover:text-rose-600'
                                  }`}
                                  title={hasActiveStay ? 'لا يمكن حذف نزيل مقيم حالياً' : 'حذف العميل نهائياً'}
                                >
                                  <Trash2 className="w-4 h-4" />
                                </button>
                              )}
                            </div>
                          </td>
                        </tr>
                      );
                    })
                  )}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* Tab 3: HOTEL IDENTITY & LOYALTY RULES */}
        {activeTab === 'hotel' && (
          <form onSubmit={handleSubmitSettings} className="p-4 sm:p-6 space-y-4 text-xs">
            {/* Hotel Identity */}
            <div className="p-4 bg-slate-50 dark:bg-slate-800/40 rounded-xl border border-slate-200 dark:border-slate-700/60 space-y-3">
              <span className="font-bold text-slate-800 dark:text-slate-200 flex items-center gap-1.5 text-xs">
                <Building className="w-4 h-4 text-emerald-600" />
                بيانات وهوية الفندق
              </span>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-600 dark:text-slate-400 mb-1">اسم الفندق (بالعربية):</label>
                  <input
                    type="text"
                    value={formData.hotelName}
                    onChange={(e) => setFormData({ ...formData, hotelName: e.target.value })}
                    required
                    className="w-full bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-lg px-3 py-2 text-slate-900 dark:text-white focus:outline-none focus:border-emerald-500"
                  />
                </div>

                <div>
                  <label className="block text-slate-600 dark:text-slate-400 mb-1">اسم الفندق (بالإنجليزية):</label>
                  <input
                    type="text"
                    value={formData.hotelNameEn}
                    onChange={(e) => setFormData({ ...formData, hotelNameEn: e.target.value })}
                    required
                    className="w-full bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-lg px-3 py-2 text-slate-900 dark:text-white focus:outline-none focus:border-emerald-500"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-600 dark:text-slate-400 mb-1">العنوان والموقع:</label>
                  <input
                    type="text"
                    value={formData.address}
                    onChange={(e) => setFormData({ ...formData, address: e.target.value })}
                    className="w-full bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-lg px-3 py-2 text-slate-900 dark:text-white focus:outline-none focus:border-emerald-500"
                  />
                </div>

                <div>
                  <label className="block text-slate-600 dark:text-slate-400 mb-1">هاتف الاستقبال:</label>
                  <input
                    type="text"
                    value={formData.phone}
                    onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                    className="w-full bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-lg px-3 py-2 text-slate-900 dark:text-white focus:outline-none focus:border-emerald-500"
                  />
                </div>
              </div>
            </div>

            {/* Frequent Guests Loyalty Rules */}
            <div className="p-4 bg-slate-50 dark:bg-slate-800/40 rounded-xl border border-slate-200 dark:border-slate-700/60 space-y-3">
              <span className="font-bold text-slate-800 dark:text-slate-200 flex items-center gap-1.5 text-xs">
                <Sparkles className="w-4 h-4 text-amber-500" />
                نظام وقواعد العملاء المستمرين (Frequent / VIP Loyalty System)
              </span>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-600 dark:text-slate-400 mb-1">
                    الحد الأدنى لعدد الزيارات ليصبح "عميلاً دائماً":
                  </label>
                  <input
                    type="number"
                    min="1"
                    max="20"
                    value={formData.frequentGuestThreshold}
                    onChange={(e) =>
                      setFormData({ ...formData, frequentGuestThreshold: parseInt(e.target.value, 10) || 3 })
                    }
                    className="w-full bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-lg px-3 py-2 font-mono font-bold text-center focus:outline-none focus:border-emerald-500"
                  />
                </div>

                <div>
                  <label className="block text-slate-600 dark:text-slate-400 mb-1">
                    نسبة الخصم الافتراضية للعميل الدائم (%):
                  </label>
                  <input
                    type="number"
                    min="0"
                    max="50"
                    value={formData.defaultLoyaltyDiscount}
                    onChange={(e) =>
                      setFormData({ ...formData, defaultLoyaltyDiscount: parseInt(e.target.value, 10) || 10 })
                    }
                    className="w-full bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-lg px-3 py-2 font-mono font-bold text-center focus:outline-none focus:border-emerald-500"
                  />
                </div>
              </div>
            </div>

            {/* Operational Times */}
            <div className="p-4 bg-slate-50 dark:bg-slate-800/40 rounded-xl border border-slate-200 dark:border-slate-700/60 space-y-3">
              <span className="font-bold text-slate-800 dark:text-slate-200 flex items-center gap-1.5 text-xs">
                <Clock className="w-4 h-4 text-indigo-600" />
                مواعيد الدخول والمغادرة الافتراضية
              </span>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-600 dark:text-slate-400 mb-1">وقت تسجيل الدخول (Check-in):</label>
                  <input
                    type="text"
                    value={formData.checkInTime}
                    onChange={(e) => setFormData({ ...formData, checkInTime: e.target.value })}
                    className="w-full bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-lg px-3 py-2 text-center font-mono focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block text-slate-600 dark:text-slate-400 mb-1">وقت تسجيل المغادرة (Check-out):</label>
                  <input
                    type="text"
                    value={formData.checkOutTime}
                    onChange={(e) => setFormData({ ...formData, checkOutTime: e.target.value })}
                    className="w-full bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-lg px-3 py-2 text-center font-mono focus:outline-none"
                  />
                </div>
              </div>
            </div>

            {/* Audio Alerts */}
            <div className="flex items-center justify-between p-3 rounded-xl bg-slate-50 dark:bg-slate-800/40 border border-slate-200 dark:border-slate-700/60">
              <div className="flex items-center gap-2">
                <Volume2 className="w-4 h-4 text-emerald-600" />
                <div>
                  <span className="font-semibold text-slate-800 dark:text-slate-200 block">التنبيهات والأصوات التفاعلية</span>
                  <span className="text-[11px] text-slate-400">تشغيل نغمات صوتية عند تسجيل الدخول أو التنبيهات العاجلة</span>
                </div>
              </div>

              <input
                type="checkbox"
                checked={formData.enableAudioAlerts}
                onChange={(e) => setFormData({ ...formData, enableAudioAlerts: e.target.checked })}
                className="w-4 h-4 accent-emerald-600 cursor-pointer"
              />
            </div>

            {/* Footer Save */}
            <div className="flex items-center justify-between pt-3 border-t border-slate-200 dark:border-slate-800">
              {isSaved ? (
                <span className="text-xs text-emerald-600 font-bold flex items-center gap-1">
                  <CheckCircle className="w-4 h-4" />
                  تم حفظ الإعدادات بنجاح
                </span>
              ) : (
                <div></div>
              )}

              <button
                type="submit"
                className="px-5 py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-xl transition cursor-pointer shadow-sm"
              >
                حفظ التعديلات
              </button>
            </div>
          </form>
        )}

        {/* Tab 4: GOOGLE DRIVE & AUTOMATIC BACKUP SUITE */}
        {activeTab === 'backup' && (
          <div className="p-4 sm:p-6 space-y-6 text-xs animate-fadeIn">
            {/* SECTION 1: GOOGLE DRIVE MANUAL ACCOUNT SELECTION */}
            <div className="p-4 sm:p-5 bg-gradient-to-br from-sky-50 via-white to-blue-50/50 dark:from-slate-900 dark:via-slate-900 dark:to-sky-950/30 rounded-2xl border border-sky-200 dark:border-sky-800/60 shadow-xs space-y-4">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-sky-100 dark:border-slate-800 pb-3">
                <div>
                  <div className="flex items-center gap-2">
                    <Cloud className="w-5 h-5 text-sky-600 dark:text-sky-400" />
                    <span className="font-bold text-slate-900 dark:text-white text-sm">
                      ربط سحابة Google Drive وتحديد الحساب يدويًا
                    </span>
                    <span className="px-2 py-0.5 rounded-full bg-sky-100 dark:bg-sky-950 text-sky-700 dark:text-sky-300 font-semibold text-[10px] border border-sky-300 dark:border-sky-800">
                      Manual Account Selection
                    </span>
                  </div>
                  <p className="text-slate-500 dark:text-slate-400 text-xs mt-0.5">
                    الربط يتم يدويًا بناءً على الحساب الذي تقوم باختياره وتحديده للنسخ الاحتياطي:
                  </p>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => setShowAddGoogleAccount(!showAddGoogleAccount)}
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-sky-600 hover:bg-sky-700 text-white font-bold transition shadow-xs cursor-pointer text-xs"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    <span>{showAddGoogleAccount ? 'إغلاق النموذج' : 'إضافة حساب Google'}</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      setIsSettingsOpen(false);
                      setIsGoogleDriveLinkModalOpen(true);
                    }}
                    className="inline-flex items-center gap-1 px-2.5 py-1.5 rounded-xl bg-white dark:bg-slate-800 hover:bg-slate-100 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 border border-slate-300 dark:border-slate-700 font-medium transition cursor-pointer text-xs"
                  >
                    <ExternalLink className="w-3.5 h-3.5" />
                    <span>النافذة الشاملة</span>
                  </button>
                </div>
              </div>

              {/* Add Account Inline Form */}
              {showAddGoogleAccount && (
                <div className="p-3.5 rounded-xl bg-white dark:bg-slate-950 border border-sky-300 dark:border-sky-800 space-y-3 animate-fadeIn">
                  <div className="font-bold text-sky-700 dark:text-sky-300 text-xs flex items-center gap-1.5">
                    <CloudUpload className="w-4 h-4" />
                    <span>إدخال وربط حساب Google يدوياً:</span>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                    <div>
                      <label className="block text-[11px] text-slate-600 dark:text-slate-400 mb-1">
                        البريد الإلكتروني لحساب Google:
                      </label>
                      <input
                        type="email"
                        value={googleEmailInput}
                        onChange={(e) => setGoogleEmailInput(e.target.value)}
                        placeholder="example@gmail.com"
                        className="w-full px-3 py-1.5 text-xs rounded-lg border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 font-mono text-left focus:outline-none focus:border-sky-500"
                        dir="ltr"
                      />
                    </div>

                    <div>
                      <label className="block text-[11px] text-slate-600 dark:text-slate-400 mb-1">
                        الاسم التعريفي للحساب:
                      </label>
                      <input
                        type="text"
                        value={googleNameInput}
                        onChange={(e) => setGoogleNameInput(e.target.value)}
                        placeholder="e.g. حساب الإدارة"
                        className="w-full px-3 py-1.5 text-xs rounded-lg border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 focus:outline-none focus:border-sky-500"
                      />
                    </div>
                  </div>

                  <div className="flex items-center justify-end gap-2 pt-1">
                    <button
                      type="button"
                      onClick={() => setShowAddGoogleAccount(false)}
                      className="px-3 py-1 text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg text-xs"
                    >
                      إلغاء
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        if (googleEmailInput.trim()) {
                          linkGoogleAccountManually({
                            email: googleEmailInput.trim(),
                            displayName: googleNameInput.trim() || undefined,
                          });
                          setShowAddGoogleAccount(false);
                        }
                      }}
                      className="px-4 py-1 bg-sky-600 hover:bg-sky-700 text-white rounded-lg font-bold text-xs shadow-xs transition"
                    >
                      ربط وتعيين كحساب نشط
                    </button>
                  </div>
                </div>
              )}

              {/* Account Selector Cards */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {googleAccounts.map((account) => {
                  const isSelected = selectedGoogleAccountId === account.id;

                  return (
                    <div
                      key={account.id}
                      onClick={() => selectActiveGoogleAccount(account.id)}
                      className={`p-3.5 rounded-xl border transition-all cursor-pointer ${
                        isSelected
                          ? 'bg-sky-100/70 dark:bg-sky-950/60 border-sky-500 ring-2 ring-sky-500/20 shadow-xs'
                          : 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800 hover:border-sky-300'
                      }`}
                    >
                      <div className="flex items-center justify-between gap-2">
                        <div className="flex items-center gap-2.5">
                          <div
                            className={`w-8 h-8 rounded-full flex items-center justify-center font-bold text-white text-xs ${
                              isSelected ? 'bg-sky-600' : 'bg-slate-400 dark:bg-slate-600'
                            }`}
                          >
                            {account.email.substring(0, 1).toUpperCase()}
                          </div>
                          <div>
                            <span className="font-bold text-slate-900 dark:text-white block truncate">
                              {account.displayName}
                            </span>
                            <span className="font-mono text-[10px] text-slate-500 block" dir="ltr">
                              {account.email}
                            </span>
                          </div>
                        </div>

                        <div
                          className={`w-4 h-4 rounded-full border flex items-center justify-center ${
                            isSelected ? 'border-sky-600 bg-sky-600 text-white' : 'border-slate-300'
                          }`}
                        >
                          {isSelected && <Check className="w-3 h-3 stroke-[3]" />}
                        </div>
                      </div>

                      <div className="mt-2.5 pt-2 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between text-[10px] text-slate-500">
                        <span>المجلد: <span className="font-mono text-sky-600">{account.folderName}</span></span>
                        {isSelected && (
                          <span className="text-emerald-600 dark:text-emerald-400 font-bold flex items-center gap-1">
                            <CheckCircle2 className="w-3 h-3" />
                            نشط للنسخ
                          </span>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>

              {/* Active Account Status & Instant Sync */}
              {selectedGoogleAccount && (
                <div className="p-3 bg-white dark:bg-slate-900/90 rounded-xl border border-sky-200 dark:border-sky-900/50 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                  <div className="flex items-center gap-2.5">
                    <FolderSync className="w-4 h-4 text-sky-600 animate-pulse" />
                    <div>
                      <span className="font-bold text-slate-800 dark:text-slate-200 block">
                        الحساب المعتمد حالياً: {selectedGoogleAccount.email}
                      </span>
                      <span className="text-[11px] text-slate-400">
                        مساحة السحابة: {((selectedGoogleAccount.storageUsedMb || 1200) / 1024).toFixed(2)} GB من 15 GB
                      </span>
                    </div>
                  </div>

                  <button
                    type="button"
                    disabled={isSyncingToGoogleDrive}
                    onClick={() => syncAllToGoogleDriveNow()}
                    className="inline-flex items-center justify-center gap-2 px-3.5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50 text-white font-bold text-xs shadow-xs transition cursor-pointer"
                  >
                    <CloudUpload className={`w-3.5 h-3.5 ${isSyncingToGoogleDrive ? 'animate-spin' : ''}`} />
                    <span>{isSyncingToGoogleDrive ? 'جاري المزامنة...' : 'مزامنة مع Google Drive الآن'}</span>
                  </button>
                </div>
              )}
            </div>

            {/* SECTION 2: AUTOMATIC BACKUP CONFIGURATION */}
            <div className="p-4 sm:p-5 bg-slate-50 dark:bg-slate-900/60 rounded-2xl border border-slate-200 dark:border-slate-800 space-y-4">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-200 dark:border-slate-800 pb-3">
                <div className="space-y-0.5">
                  <div className="flex items-center gap-2">
                    <Clock className="w-5 h-5 text-emerald-600 dark:text-emerald-400" />
                    <span className="font-bold text-slate-900 dark:text-white text-sm">
                      محرك النسخ الاحتياطي التلقائي (Auto Backup Schedule)
                    </span>
                  </div>
                  <p className="text-slate-500 dark:text-slate-400 text-xs">
                    توليد لقطات دورية وحفظها في قاعدة البيانات وسحابة Google Drive
                  </p>
                </div>

                <div className="flex items-center gap-3">
                  <label className="relative inline-flex items-center cursor-pointer">
                    <input
                      type="checkbox"
                      checked={autoBackupConfig.enabled}
                      onChange={(e) => updateAutoBackupConfig({ enabled: e.target.checked })}
                      className="sr-only peer"
                    />
                    <div className="w-12 h-6 bg-slate-300 dark:bg-slate-700 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full rtl:peer-checked:after:-translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:start-[3px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-emerald-600"></div>
                  </label>
                  <span className="font-bold text-slate-700 dark:text-slate-300 text-xs">
                    {autoBackupConfig.enabled ? 'النسخ التلقائي مفعل' : 'معطل'}
                  </span>
                </div>
              </div>

              {/* Frequency Picker */}
              <div className="space-y-2">
                <label className="block font-bold text-slate-700 dark:text-slate-300 text-xs">
                  دورية وتكرار النسخ التلقائي:
                </label>
                <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-6 gap-2">
                  {[
                    { id: '1h' as AutoBackupFrequency, label: 'كل 1 ساعة' },
                    { id: '3h' as AutoBackupFrequency, label: 'كل 3 ساعات' },
                    { id: '6h' as AutoBackupFrequency, label: 'كل 6 ساعات' },
                    { id: '12h' as AutoBackupFrequency, label: 'كل 12 ساعة' },
                    { id: '24h' as AutoBackupFrequency, label: 'يومياً (24h)' },
                    { id: 'weekly' as AutoBackupFrequency, label: 'أسبوعياً' },
                  ].map((f) => {
                    const isSelected = autoBackupConfig.frequency === f.id;
                    return (
                      <button
                        key={f.id}
                        type="button"
                        onClick={() => updateAutoBackupConfig({ frequency: f.id })}
                        className={`py-2 px-2.5 rounded-xl border text-center font-bold text-xs transition cursor-pointer ${
                          isSelected
                            ? 'bg-emerald-600 text-white border-emerald-600 shadow-xs'
                            : 'bg-white dark:bg-slate-800 border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 hover:border-emerald-300'
                        }`}
                      >
                        {f.label}
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Checkboxes & Instant Trigger */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
                <label className="flex items-center gap-2 p-2.5 rounded-xl bg-white dark:bg-slate-950 border border-slate-200 dark:border-slate-800 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={autoBackupConfig.syncToGoogleDrive}
                    onChange={(e) => updateAutoBackupConfig({ syncToGoogleDrive: e.target.checked })}
                    className="w-4 h-4 rounded text-sky-600 focus:ring-sky-500"
                  />
                  <span className="font-semibold text-slate-700 dark:text-slate-300 text-xs">
                    مزامنة تلقائية مع Google Drive ({selectedGoogleAccount?.displayName || 'الحساب النشط'})
                  </span>
                </label>

                <div className="flex items-center justify-between p-2.5 rounded-xl bg-white dark:bg-slate-950 border border-slate-200 dark:border-slate-800">
                  <span className="text-slate-500 text-xs">آخر عملية: {autoBackupConfig.lastBackupTime || 'لم تُنفذ بعد'}</span>
                  <button
                    type="button"
                    onClick={() => createBackupSnapshot('manual')}
                    className="px-3 py-1 bg-emerald-50 dark:bg-emerald-950/60 hover:bg-emerald-100 text-emerald-700 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-800 rounded-lg font-bold transition cursor-pointer text-xs"
                  >
                    أخذ نسخة فورية
                  </button>
                </div>
              </div>
            </div>

            {/* SECTION 3: RECENT BACKUP SNAPSHOTS VAULT */}
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <span className="font-bold text-slate-900 dark:text-white text-xs flex items-center gap-2">
                  <Database className="w-4 h-4 text-slate-600 dark:text-slate-400" />
                  <span>سجل النسخ الاحتياطية المتاحة ({backupSnapshots.length})</span>
                </span>
                <span className="text-slate-400 text-[11px]">يتم حفظ آخر 10 نسخ تلقائياً</span>
              </div>

              <div className="divide-y divide-slate-200 dark:divide-slate-800 rounded-2xl border border-slate-200 dark:border-slate-800 overflow-hidden bg-white dark:bg-slate-900">
                {backupSnapshots.map((snap) => (
                  <div key={snap.id} className="p-3.5 flex flex-col sm:flex-row sm:items-center justify-between gap-2.5 hover:bg-slate-50 dark:hover:bg-slate-800/40 transition">
                    <div className="space-y-1">
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="font-mono font-bold text-slate-800 dark:text-slate-200" dir="ltr">
                          {snap.filename}
                        </span>
                        {snap.isSyncedToGoogleDrive && (
                          <span className="px-2 py-0.5 rounded-full bg-emerald-100 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-300 text-[10px] font-bold flex items-center gap-1">
                            <Cloud className="w-3 h-3" />
                            Google Drive
                          </span>
                        )}
                        <span className="px-1.5 py-0.5 rounded bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 text-[10px] font-mono">
                          {snap.sizeKb} KB
                        </span>
                      </div>
                      <div className="text-[11px] text-slate-500 flex items-center gap-3">
                        <span>{snap.createdAt}</span>
                        <span>الغرف: {snap.recordsCount.rooms}</span>
                        <span>الحجوزات: {snap.recordsCount.bookings}</span>
                        <span>النزلاء: {snap.recordsCount.guests}</span>
                      </div>
                    </div>

                    <div className="flex items-center gap-2 shrink-0">
                      {confirmSnapshotRestoreId === snap.id ? (
                        <div className="flex items-center gap-1">
                          <button
                            type="button"
                            onClick={async () => {
                              await restoreBackupSnapshot(snap.id);
                              setConfirmSnapshotRestoreId(null);
                            }}
                            className="px-3 py-1 rounded-lg bg-rose-600 hover:bg-rose-700 text-white font-bold text-xs cursor-pointer shadow-xs"
                          >
                            تأكيد الاستعادة
                          </button>
                          <button
                            type="button"
                            onClick={() => setConfirmSnapshotRestoreId(null)}
                            className="px-2 py-1 rounded-lg border border-slate-300 dark:border-slate-700 text-slate-600 dark:text-slate-400 hover:bg-slate-100 text-xs"
                          >
                            إلغاء
                          </button>
                        </div>
                      ) : (
                        <button
                          type="button"
                          onClick={() => setConfirmSnapshotRestoreId(snap.id)}
                          className="px-3 py-1.5 rounded-lg bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 font-semibold text-xs transition cursor-pointer"
                        >
                          استعادة
                        </button>
                      )}

                      {!snap.isSyncedToGoogleDrive && (
                        <button
                          type="button"
                          onClick={() => syncSnapshotToGoogleDrive(snap.id)}
                          className="p-1.5 rounded-lg border border-sky-200 dark:border-sky-800 text-sky-600 dark:text-sky-400 hover:bg-sky-50 dark:hover:bg-sky-950/40 transition cursor-pointer"
                          title="رفع إلى Google Drive"
                        >
                          <CloudUpload className="w-3.5 h-3.5" />
                        </button>
                      )}

                      <button
                        type="button"
                        onClick={() => {
                          const data = snap.rawJson || JSON.stringify(snap, null, 2);
                          saveText(snap.filename, data, 'application/json');
                        }}
                        className="p-1.5 rounded-lg border border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition cursor-pointer"
                        title="تنزيل الملف"
                      >
                        <Download className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* SECTION 4: SQLITE EXPORT / IMPORT & MAINTENANCE */}
            <div className="p-4 bg-slate-50 dark:bg-slate-950/80 rounded-xl border border-slate-200 dark:border-slate-800 space-y-3">
              <div className="flex items-center justify-between">
                <span className="font-bold text-slate-900 dark:text-white flex items-center gap-2 text-xs">
                  <Terminal className="w-4 h-4 text-emerald-600" />
                  <span>تصدير واستيراد ملفات SQLite يدوياً</span>
                </span>

                <button
                  type="button"
                  onClick={() => {
                    setIsSettingsOpen(false);
                    setIsSqlConsoleOpen(true);
                  }}
                  className="text-xs text-cyan-600 dark:text-cyan-400 hover:underline flex items-center gap-1 font-semibold cursor-pointer"
                >
                  <Terminal className="w-3.5 h-3.5" />
                  <span>وحدة تحكم SQL</span>
                </button>
              </div>

              {/* Export Buttons */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                <button
                  type="button"
                  onClick={() => {
                    exportDatabaseJson();
                    playAlertSound('success');
                  }}
                  className="flex items-center justify-center gap-2 p-2.5 bg-white dark:bg-slate-900 hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-800 dark:text-slate-200 border border-slate-300 dark:border-slate-700 rounded-lg font-medium transition cursor-pointer text-xs group shadow-xs"
                >
                  <FileJson className="w-4 h-4 text-cyan-500 group-hover:scale-110 transition-transform" />
                  <span>تصدير ملف JSON</span>
                  <Download className="w-3.5 h-3.5 text-slate-400 mr-auto" />
                </button>

                <button
                  type="button"
                  onClick={() => {
                    exportDatabaseSql();
                    playAlertSound('success');
                  }}
                  className="flex items-center justify-center gap-2 p-2.5 bg-white dark:bg-slate-900 hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-800 dark:text-slate-200 border border-slate-300 dark:border-slate-700 rounded-lg font-medium transition cursor-pointer text-xs group shadow-xs"
                >
                  <FileCode className="w-4 h-4 text-emerald-500 group-hover:scale-110 transition-transform" />
                  <span>تصدير أوامر SQL Dump</span>
                  <Download className="w-3.5 h-3.5 text-slate-400 mr-auto" />
                </button>
              </div>

              {/* Import / Restore Section */}
              <div className="pt-2 border-t border-slate-200 dark:border-slate-800 space-y-2">
                <div className="flex items-center gap-2">
                  <input
                    ref={fileInputRef}
                    type="file"
                    accept=".json,.sql"
                    onChange={handleFileUpload}
                    className="hidden"
                    id="settings-database-file-import"
                  />
                  <label
                    htmlFor="settings-database-file-import"
                    className="flex-1 flex items-center justify-center gap-2 py-2 px-3 bg-emerald-600/10 dark:bg-emerald-950/40 hover:bg-emerald-600/20 text-emerald-700 dark:text-emerald-300 border border-emerald-500/30 rounded-lg cursor-pointer transition font-medium text-xs text-center"
                  >
                    <Upload className="w-4 h-4 text-emerald-600 dark:text-emerald-400 shrink-0" />
                    <span>استيراد ملف قاعدة بيانات خارجي (.json / .sql)</span>
                  </label>
                </div>

                {importStatus.message && (
                  <div
                    className={`p-2.5 rounded-lg text-xs flex items-center gap-2 ${
                      importStatus.type === 'success'
                        ? 'bg-emerald-100 dark:bg-emerald-950/60 text-emerald-800 dark:text-emerald-300 border border-emerald-300 dark:border-emerald-800'
                        : importStatus.type === 'error'
                        ? 'bg-rose-100 dark:bg-rose-950/60 text-rose-800 dark:text-rose-300 border border-rose-300 dark:border-rose-800'
                        : 'bg-cyan-100 dark:bg-cyan-950/60 text-cyan-800 dark:text-cyan-300 border border-cyan-300 dark:border-cyan-800'
                    }`}
                  >
                    {importStatus.type === 'success' ? (
                      <CheckCircle className="w-4 h-4 shrink-0 text-emerald-600" />
                    ) : importStatus.type === 'error' ? (
                      <AlertTriangle className="w-4 h-4 shrink-0 text-rose-600" />
                    ) : (
                      <RefreshCw className="w-4 h-4 shrink-0 animate-spin text-cyan-600" />
                    )}
                    <span>{importStatus.message}</span>
                  </div>
                )}
              </div>

              {/* Factory Reset */}
              <div className="pt-2 border-t border-slate-200 dark:border-slate-800 flex items-center justify-between">
                <div>
                  <span className="font-semibold text-slate-700 dark:text-slate-300 text-[11px] block">
                    إعادة ضبط البيانات التجريبية الافتراضية
                  </span>
                  <span className="text-[10px] text-slate-500">
                    استرجاع 24 غرفة مع نماذج حجوزات نظيفة
                  </span>
                </div>

                {showResetConfirm ? (
                  <div className="flex items-center gap-1.5">
                    <button
                      type="button"
                      onClick={() => setShowResetConfirm(false)}
                      className="px-2 py-1 text-slate-500 hover:bg-slate-200 dark:hover:bg-slate-800 rounded text-[11px]"
                    >
                      إلغاء
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        resetToDemoData();
                        setShowResetConfirm(false);
                        setImportStatus({
                          type: 'success',
                          message: 'تمت إعادة ضبط قاعدة البيانات إلى الحالة الافتراضية بنجاح.',
                        });
                      }}
                      className="px-2.5 py-1 bg-rose-600 hover:bg-rose-500 text-white rounded text-[11px] font-bold"
                    >
                      تأكيد المسح
                    </button>
                  </div>
                ) : (
                  <button
                    type="button"
                    onClick={() => setShowResetConfirm(true)}
                    className="px-2.5 py-1 text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950/40 rounded border border-rose-200 dark:border-rose-900 text-[11px] font-medium transition cursor-pointer"
                  >
                    إعادة تعيين
                  </button>
                )}
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

