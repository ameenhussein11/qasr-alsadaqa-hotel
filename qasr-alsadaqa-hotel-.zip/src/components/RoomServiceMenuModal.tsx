import React, { useState } from 'react';
import { useHotel } from '../context/HotelContext';
import {
  X,
  Plus,
  Trash2,
  Edit2,
  Check,
  UtensilsCrossed,
  Coffee,
  ShoppingBag,
  Sparkles,
  Shirt,
  Bed,
  Search,
  Clock,
  CheckCircle2,
  XCircle,
  ChefHat,
  Tag,
} from 'lucide-react';
import { RoomServiceCategory, RoomServiceItem } from '../types/hotel';

export const RoomServiceMenuModal: React.FC = () => {
  const {
    roomServiceMenu,
    settings,
    isRoomServiceMenuModalOpen,
    setIsRoomServiceMenuModalOpen,
    addRoomServiceMenuItem,
    updateRoomServiceMenuItem,
    deleteRoomServiceMenuItem,
    toggleRoomServiceItemAvailability,
  } = useHotel();

  const [selectedCategory, setSelectedCategory] = useState<RoomServiceCategory | 'all'>('all');
  const [searchFilter, setSearchFilter] = useState('');
  const [isAddingNew, setIsAddingNew] = useState(false);
  const [editingItemId, setEditingItemId] = useState<number | null>(null);

  // Form State
  const [name, setName] = useState('');
  const [nameEn, setNameEn] = useState('');
  const [category, setCategory] = useState<RoomServiceCategory>('meals');
  const [price, setPrice] = useState<number>(30);
  const [prepTimeMinutes, setPrepTimeMinutes] = useState<number>(15);
  const [description, setDescription] = useState('');
  const [imageIcon, setImageIcon] = useState('🍽️');
  const [isAvailable, setIsAvailable] = useState(true);

  if (!isRoomServiceMenuModalOpen) return null;

  const filteredItems = roomServiceMenu.filter((item) => {
    if (selectedCategory !== 'all' && item.category !== selectedCategory) return false;
    if (searchFilter.trim()) {
      const q = searchFilter.toLowerCase();
      const matchName = item.name.toLowerCase().includes(q);
      const matchNameEn = item.nameEn?.toLowerCase().includes(q);
      const matchDesc = item.description?.toLowerCase().includes(q);
      if (!matchName && !matchNameEn && !matchDesc) return false;
    }
    return true;
  });

  const handleStartAdd = () => {
    setIsAddingNew(true);
    setEditingItemId(null);
    setName('');
    setNameEn('');
    setCategory('meals');
    setPrice(35);
    setPrepTimeMinutes(15);
    setDescription('');
    setImageIcon('🍽️');
    setIsAvailable(true);
  };

  const handleStartEdit = (item: RoomServiceItem) => {
    setIsAddingNew(false);
    setEditingItemId(item.id);
    setName(item.name);
    setNameEn(item.nameEn || '');
    setCategory(item.category);
    setPrice(item.price);
    setPrepTimeMinutes(item.prepTimeMinutes || 15);
    setDescription(item.description || '');
    setImageIcon(item.imageIcon || '🍽️');
    setIsAvailable(item.isAvailable);
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;

    if (isAddingNew) {
      addRoomServiceMenuItem({
        name: name.trim(),
        nameEn: nameEn.trim() || undefined,
        category,
        price: Number(price),
        prepTimeMinutes: Number(prepTimeMinutes),
        description: description.trim() || undefined,
        imageIcon: imageIcon.trim() || '🍽️',
        isAvailable,
      });
      setIsAddingNew(false);
    } else if (editingItemId) {
      updateRoomServiceMenuItem(editingItemId, {
        name: name.trim(),
        nameEn: nameEn.trim() || undefined,
        category,
        price: Number(price),
        prepTimeMinutes: Number(prepTimeMinutes),
        description: description.trim() || undefined,
        imageIcon: imageIcon.trim() || '🍽️',
        isAvailable,
      });
      setEditingItemId(null);
    }
  };

  const handleCancelForm = () => {
    setIsAddingNew(false);
    setEditingItemId(null);
  };

  const categories = [
    { id: 'all', label: 'الكل', icon: Sparkles },
    { id: 'breakfast', label: 'الفطور', icon: UtensilsCrossed },
    { id: 'meals', label: 'وجبات رئيسية', icon: UtensilsCrossed },
    { id: 'beverages', label: 'مشروبات وقهوة', icon: Coffee },
    { id: 'desserts_snacks', label: 'حلويات وسناكات', icon: ShoppingBag },
    { id: 'laundry', label: 'خدمات المغسلة', icon: Shirt },
    { id: 'amenities', label: 'لوازم ومرافق', icon: Bed },
  ];

  const commonIcons = ['🍳', '🥐', '🥞', '🍛', '🍔', '🥪', '🍕', '🥗', '🍲', '☕', '🍊', '🍹', '🍰', '🍨', '🍇', '👔', '🧺', '🧴', '🛏️', '🍽️'];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-slate-950/80 backdrop-blur-sm overflow-y-auto">
      <div className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-4xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="bg-slate-800/80 px-5 py-4 border-b border-slate-700/80 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-amber-500/20 border border-amber-500/30 flex items-center justify-center text-amber-400">
              <ChefHat className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base sm:text-lg font-bold text-white flex items-center gap-2">
                <span>إدارة قائمة خدمة الغرف (Menu & Services Manager)</span>
              </h2>
              <p className="text-xs text-slate-400">
                إضافة أصناف جديدة، تعديل الأسعار، التحكم في التوفر، وإدارة فئات الطعام والخدمات
              </p>
            </div>
          </div>
          <button
            onClick={() => setIsRoomServiceMenuModalOpen(false)}
            className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-700 transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Action & Filter Bar */}
        <div className="p-4 bg-slate-950/50 border-b border-slate-800 flex flex-wrap items-center justify-between gap-3">
          {/* Categories */}
          <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar py-1">
            {categories.map((cat) => {
              const Icon = cat.icon;
              const isSelected = selectedCategory === cat.id;
              return (
                <button
                  key={cat.id}
                  onClick={() => setSelectedCategory(cat.id as any)}
                  className={`px-3 py-1.5 rounded-lg text-xs font-medium whitespace-nowrap transition cursor-pointer flex items-center gap-1.5 ${
                    isSelected
                      ? 'bg-amber-500 text-slate-950 font-bold'
                      : 'bg-slate-900 hover:bg-slate-800 text-slate-300 border border-slate-800'
                  }`}
                >
                  <Icon className="w-3.5 h-3.5" />
                  <span>{cat.label}</span>
                </button>
              );
            })}
          </div>

          <div className="flex items-center gap-2 w-full sm:w-auto">
            <div className="relative flex-1 sm:w-56">
              <Search className="w-3.5 h-3.5 text-slate-400 absolute right-3 top-2.5" />
              <input
                type="text"
                value={searchFilter}
                onChange={(e) => setSearchFilter(e.target.value)}
                placeholder="بحث في القائمة..."
                className="w-full bg-slate-900 border border-slate-800 rounded-lg pr-9 pl-3 py-1.5 text-xs text-slate-200 placeholder-slate-500 focus:outline-none focus:border-amber-500"
              />
            </div>
            {!isAddingNew && !editingItemId && (
              <button
                onClick={handleStartAdd}
                className="bg-emerald-600 hover:bg-emerald-500 text-white font-medium text-xs px-3.5 py-1.5 rounded-lg transition cursor-pointer flex items-center gap-1.5 shrink-0 shadow-sm"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>إضافة صنف جديد</span>
              </button>
            )}
          </div>
        </div>

        {/* Body Content */}
        <div className="p-4 flex-1 overflow-y-auto space-y-4">
          {/* Add / Edit Form Panel */}
          {(isAddingNew || editingItemId !== null) && (
            <form
              onSubmit={handleSave}
              className="bg-slate-800/90 border border-amber-500/40 rounded-xl p-4 shadow-lg mb-4 space-y-4 animate-in fade-in"
            >
              <div className="flex items-center justify-between border-b border-slate-700 pb-2">
                <h3 className="font-bold text-sm text-white flex items-center gap-2">
                  <Tag className="w-4 h-4 text-amber-400" />
                  <span>{isAddingNew ? 'إضافة صنف أو خدمة جديدة' : 'تعديل بيانات الصنف'}</span>
                </h3>
                <button
                  type="button"
                  onClick={handleCancelForm}
                  className="text-xs text-slate-400 hover:text-white cursor-pointer"
                >
                  إلغاء
                </button>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">
                    اسم الصنف (بالعربية) *
                  </label>
                  <input
                    type="text"
                    required
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="مثال: برجر لحم أنجوس"
                    className="w-full bg-slate-900 border border-slate-700 text-white rounded-lg px-3 py-1.5 text-xs focus:outline-none focus:border-amber-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">
                    الاسم بالإنجليزية (اختياري)
                  </label>
                  <input
                    type="text"
                    value={nameEn}
                    onChange={(e) => setNameEn(e.target.value)}
                    placeholder="e.g. Angus Beef Burger"
                    className="w-full bg-slate-900 border border-slate-700 text-white rounded-lg px-3 py-1.5 text-xs focus:outline-none focus:border-amber-500 font-mono"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">
                    القسم / الفئة
                  </label>
                  <select
                    value={category}
                    onChange={(e) => setCategory(e.target.value as any)}
                    className="w-full bg-slate-900 border border-slate-700 text-white rounded-lg px-3 py-1.5 text-xs focus:outline-none focus:border-amber-500"
                  >
                    <option value="breakfast">الفطور (Breakfast)</option>
                    <option value="meals">وجبات رئيسية (Meals)</option>
                    <option value="beverages">مشروبات وقهوة (Beverages)</option>
                    <option value="desserts_snacks">حلويات وسناكات (Desserts & Snacks)</option>
                    <option value="laundry">خدمات المغسلة والكوي (Laundry)</option>
                    <option value="amenities">لوازم ومرافق إضافية (Amenities)</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">
                    السعر ({settings.currency}) *
                  </label>
                  <input
                    type="number"
                    min="0"
                    step="0.5"
                    required
                    value={price}
                    onChange={(e) => setPrice(Number(e.target.value))}
                    className="w-full bg-slate-900 border border-slate-700 text-white rounded-lg px-3 py-1.5 text-xs focus:outline-none focus:border-amber-500 font-mono font-bold"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">
                    وقت التحضير والتسليم (بالدقائق)
                  </label>
                  <input
                    type="number"
                    min="1"
                    value={prepTimeMinutes}
                    onChange={(e) => setPrepTimeMinutes(Number(e.target.value))}
                    className="w-full bg-slate-900 border border-slate-700 text-white rounded-lg px-3 py-1.5 text-xs focus:outline-none focus:border-amber-500 font-mono"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">
                    أيقونة / إيموجي الصنف
                  </label>
                  <div className="flex items-center gap-2">
                    <input
                      type="text"
                      value={imageIcon}
                      onChange={(e) => setImageIcon(e.target.value)}
                      className="w-14 text-center bg-slate-900 border border-slate-700 text-white rounded-lg px-2 py-1.5 text-lg"
                    />
                    <div className="flex items-center gap-1 overflow-x-auto no-scrollbar py-1">
                      {commonIcons.slice(0, 7).map((icon) => (
                        <button
                          key={icon}
                          type="button"
                          onClick={() => setImageIcon(icon)}
                          className="w-7 h-7 rounded bg-slate-900 hover:bg-slate-700 flex items-center justify-center text-sm cursor-pointer"
                        >
                          {icon}
                        </button>
                      ))}
                    </div>
                  </div>
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  وصف المكونات أو تفاصيل الخدمة
                </label>
                <input
                  type="text"
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  placeholder="مكونات الطبق، الحجم، أو شروط الخدمة..."
                  className="w-full bg-slate-900 border border-slate-700 text-white rounded-lg px-3 py-1.5 text-xs focus:outline-none focus:border-amber-500"
                />
              </div>

              <div className="flex items-center justify-between pt-2">
                <label className="flex items-center gap-2 cursor-pointer text-xs text-slate-300">
                  <input
                    type="checkbox"
                    checked={isAvailable}
                    onChange={(e) => setIsAvailable(e.target.checked)}
                    className="rounded border-slate-700 text-amber-500 focus:ring-amber-500 bg-slate-900"
                  />
                  <span>متوفر للطلب حالياً (Available)</span>
                </label>

                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={handleCancelForm}
                    className="px-3 py-1.5 rounded-lg border border-slate-700 text-slate-300 hover:bg-slate-700 text-xs font-medium cursor-pointer"
                  >
                    إلغاء
                  </button>
                  <button
                    type="submit"
                    className="px-4 py-1.5 rounded-lg bg-amber-500 hover:bg-amber-400 text-slate-950 text-xs font-bold transition cursor-pointer flex items-center gap-1.5"
                  >
                    <Check className="w-3.5 h-3.5" />
                    <span>{isAddingNew ? 'حفظ الصنف' : 'تحديث البيانات'}</span>
                  </button>
                </div>
              </div>
            </form>
          )}

          {/* Menu Items Table / Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {filteredItems.map((item) => (
              <div
                key={item.id}
                className={`bg-slate-950/70 border rounded-xl p-3 flex items-start justify-between gap-3 transition ${
                  item.isAvailable ? 'border-slate-800' : 'border-rose-900/40 bg-rose-950/10 opacity-70'
                }`}
              >
                <div className="flex items-start gap-3">
                  <span className="text-2xl shrink-0 p-2 bg-slate-900 rounded-xl border border-slate-800">
                    {item.imageIcon || '🍽️'}
                  </span>
                  <div>
                    <div className="flex items-center gap-2">
                      <h4 className="text-xs sm:text-sm font-bold text-white">{item.name}</h4>
                      {!item.isAvailable && (
                        <span className="text-[10px] bg-rose-500/20 text-rose-300 px-1.5 py-0.2 rounded border border-rose-500/30">
                          غير متوفر
                        </span>
                      )}
                    </div>
                    {item.nameEn && (
                      <p className="text-[10px] text-slate-400 font-mono">{item.nameEn}</p>
                    )}
                    {item.description && (
                      <p className="text-[11px] text-slate-400 line-clamp-1 mt-0.5">
                        {item.description}
                      </p>
                    )}
                    <div className="flex items-center gap-3 mt-2 text-[11px]">
                      <span className="font-bold text-emerald-400 font-mono">
                        {item.price} {settings.currency}
                      </span>
                      {item.prepTimeMinutes && (
                        <span className="text-slate-400 flex items-center gap-1">
                          <Clock className="w-3 h-3 text-amber-400" />
                          <span>{item.prepTimeMinutes} د</span>
                        </span>
                      )}
                    </div>
                  </div>
                </div>

                {/* Actions */}
                <div className="flex flex-col gap-1.5 shrink-0">
                  <button
                    onClick={() => toggleRoomServiceItemAvailability(item.id)}
                    title={item.isAvailable ? 'تعطيل التوفر مؤقتاً' : 'تفعيل التوفر'}
                    className={`p-1.5 rounded-lg border transition cursor-pointer ${
                      item.isAvailable
                        ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30 hover:bg-emerald-500/20'
                        : 'bg-rose-500/10 text-rose-400 border-rose-500/30 hover:bg-rose-500/20'
                    }`}
                  >
                    {item.isAvailable ? <CheckCircle2 className="w-3.5 h-3.5" /> : <XCircle className="w-3.5 h-3.5" />}
                  </button>
                  <button
                    onClick={() => handleStartEdit(item)}
                    title="تعديل"
                    className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700 transition cursor-pointer"
                  >
                    <Edit2 className="w-3.5 h-3.5" />
                  </button>
                  <button
                    onClick={() => {
                      if (confirm(`هل أنت متأكد من حذف الصنف (${item.name})؟`)) {
                        deleteRoomServiceMenuItem(item.id);
                      }
                    }}
                    title="حذف"
                    className="p-1.5 rounded-lg bg-slate-800 hover:bg-rose-500/20 text-slate-400 hover:text-rose-400 border border-slate-700 hover:border-rose-500/30 transition cursor-pointer"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 bg-slate-950 border-t border-slate-800 flex justify-end">
          <button
            onClick={() => setIsRoomServiceMenuModalOpen(false)}
            className="px-5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-white text-xs font-semibold transition cursor-pointer"
          >
            إغلاق
          </button>
        </div>
      </div>
    </div>
  );
};
