import React, { useState } from 'react';
import { useHotel } from '../context/HotelContext';
import { QueryResult, SQL_SCHEMA_DDL } from '../db/sqliteEngine';
import {
  Database,
  X,
  Play,
  Download,
  Upload,
  RefreshCw,
  Terminal,
  Code,
  FileCode,
  CheckCircle,
  AlertCircle,
  Copy,
  Check,
} from 'lucide-react';

export const SqlConsoleModal: React.FC = () => {
  const {
    isSqlConsoleOpen,
    setIsSqlConsoleOpen,
    executeSql,
    exportDatabaseSql,
    exportDatabaseJson,
    importDatabaseJson,
    resetToDemoData,
  } = useHotel();

  const [sqlInput, setSqlInput] = useState<string>('SELECT * FROM rooms WHERE status = \'available\';');
  const [queryResult, setQueryResult] = useState<QueryResult | null>(null);
  const [activeTab, setActiveTab] = useState<'console' | 'schema' | 'backup'>('console');
  const [isCopied, setIsCopied] = useState<boolean>(false);
  const [importStatus, setImportStatus] = useState<string>('');

  if (!isSqlConsoleOpen) return null;

  const handleRunQuery = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!sqlInput.trim()) return;
    const res = executeSql(sqlInput);
    setQueryResult(res);
  };

  const handleShortcut = (query: string) => {
    setSqlInput(query);
    const res = executeSql(query);
    setQueryResult(res);
  };

  const handleCopySchema = () => {
    navigator.clipboard.writeText(SQL_SCHEMA_DDL);
    setIsCopied(true);
    setTimeout(() => setIsCopied(false), 2000);
  };

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setImportStatus('جاري استيراد البيانات...');
    const ok = await importDatabaseJson(file);
    if (ok) {
      setImportStatus('تم استيراد قاعدة البيانات بنجاح!');
      setTimeout(() => setImportStatus(''), 3000);
    } else {
      setImportStatus('فشل استيراد الملف. تأكد من صحة تنسيق JSON لقاعدة البيانات.');
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/75 backdrop-blur-xs animate-fadeIn">
      <div className="bg-slate-900 border border-slate-700 rounded-2xl w-full max-w-4xl max-h-[92vh] overflow-hidden shadow-2xl flex flex-col text-slate-200">
        {/* Header */}
        <div className="p-4 bg-slate-950 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-cyan-600/20 text-cyan-400 border border-cyan-500/30 flex items-center justify-center font-mono">
              <Database className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-sm font-bold text-white">وحدة تحكم قاعدة بيانات SQLite (Room Persistence)</h2>
                <span className="px-1.5 py-0.2 bg-emerald-500/20 text-emerald-400 text-[10px] font-mono rounded">
                  Local SQLite Engine
                </span>
              </div>
              <p className="text-xs text-slate-400">
                استعلامات SQL مباشرة، فحص الجداول ومخطط DDL، وتصدير ملفات النسخ الاحتياطي
              </p>
            </div>
          </div>

          <button
            onClick={() => setIsSqlConsoleOpen(false)}
            className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Switcher */}
        <div className="bg-slate-950/60 border-b border-slate-800 px-4 flex items-center gap-2 text-xs">
          <button
            onClick={() => setActiveTab('console')}
            className={`px-3 py-2 border-b-2 font-medium transition cursor-pointer flex items-center gap-1.5 ${
              activeTab === 'console'
                ? 'border-cyan-500 text-cyan-400'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Terminal className="w-4 h-4" />
            <span>محرر استعلامات SQL (Query Runner)</span>
          </button>

          <button
            onClick={() => setActiveTab('schema')}
            className={`px-3 py-2 border-b-2 font-medium transition cursor-pointer flex items-center gap-1.5 ${
              activeTab === 'schema'
                ? 'border-cyan-500 text-cyan-400'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <FileCode className="w-4 h-4" />
            <span>مخطط الجداول (DDL Schema)</span>
          </button>

          <button
            onClick={() => setActiveTab('backup')}
            className={`px-3 py-2 border-b-2 font-medium transition cursor-pointer flex items-center gap-1.5 ${
              activeTab === 'backup'
                ? 'border-cyan-500 text-cyan-400'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Download className="w-4 h-4" />
            <span>النسخ الاحتياطي والتصدير (Backup & Restore)</span>
          </button>
        </div>

        {/* Tab Content */}
        <div className="p-4 flex-1 overflow-y-auto space-y-4">
          {activeTab === 'console' && (
            <div className="space-y-4">
              {/* Quick Query Shortcuts */}
              <div className="space-y-1.5">
                <span className="text-[11px] text-slate-400 block font-semibold">استعلامات سريعة جاهزة:</span>
                <div className="flex items-center gap-1.5 flex-wrap">
                  <button
                    onClick={() => handleShortcut("SELECT * FROM rooms WHERE status = 'available';")}
                    className="px-2 py-1 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded text-[11px] font-mono border border-slate-700 transition"
                  >
                    الغرف المتاحة (Available)
                  </button>
                  <button
                    onClick={() => handleShortcut("SELECT * FROM rooms WHERE status = 'occupied';")}
                    className="px-2 py-1 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded text-[11px] font-mono border border-slate-700 transition"
                  >
                    الغرف المشغولة (Occupied)
                  </button>
                  <button
                    onClick={() => handleShortcut('SELECT * FROM guests WHERE is_frequent = 1;')}
                    className="px-2 py-1 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded text-[11px] font-mono border border-slate-700 transition"
                  >
                    العملاء المستمرين (Frequent VIPs)
                  </button>
                  <button
                    onClick={() => handleShortcut('SELECT * FROM housekeeping_tasks;')}
                    className="px-2 py-1 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded text-[11px] font-mono border border-slate-700 transition"
                  >
                    مهام الهاوس كيبينج (Housekeeping)
                  </button>
                  <button
                    onClick={() => handleShortcut('SELECT * FROM payments ORDER BY id DESC LIMIT 5;')}
                    className="px-2 py-1 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded text-[11px] font-mono border border-slate-700 transition"
                  >
                    آخر المدفوعات (Payments)
                  </button>
                  <button
                    onClick={() => handleShortcut('.TABLES')}
                    className="px-2 py-1 bg-cyan-950/80 hover:bg-cyan-900 text-cyan-300 rounded text-[11px] font-mono border border-cyan-800 transition"
                  >
                    عرض الجداول (.TABLES)
                  </button>
                </div>
              </div>

              {/* SQL Code Input */}
              <form onSubmit={handleRunQuery} className="space-y-2">
                <div className="relative">
                  <textarea
                    value={sqlInput}
                    onChange={(e) => setSqlInput(e.target.value)}
                    rows={3}
                    placeholder="اكتب استعلام SQL هنا (مثال: SELECT * FROM rooms;)"
                    className="w-full bg-slate-950 font-mono text-xs text-emerald-400 p-3 rounded-xl border border-slate-700 focus:outline-none focus:border-cyan-500 leading-relaxed"
                  />
                </div>

                <div className="flex items-center justify-between">
                  <span className="text-[11px] text-slate-500">
                    يدعم: SELECT, UPDATE, INSERT, DELETE, DESCRIBE, PRAGMA
                  </span>

                  <button
                    type="submit"
                    className="px-4 py-2 bg-cyan-600 hover:bg-cyan-500 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 transition cursor-pointer shadow-sm"
                  >
                    <Play className="w-3.5 h-3.5 fill-current" />
                    <span>تنفيذ الاستعلام (Execute SQL)</span>
                  </button>
                </div>
              </form>

              {/* Query Result Output */}
              {queryResult && (
                <div className="space-y-2">
                  <div className="flex items-center justify-between text-xs border-t border-slate-800 pt-3">
                    <div className="flex items-center gap-2">
                      {queryResult.success ? (
                        <span className="text-emerald-400 flex items-center gap-1 font-semibold">
                          <CheckCircle className="w-4 h-4" />
                          نجح التنفيذ
                        </span>
                      ) : (
                        <span className="text-rose-400 flex items-center gap-1 font-semibold">
                          <AlertCircle className="w-4 h-4" />
                          خطأ في الاستعلام
                        </span>
                      )}

                      {queryResult.rowCount !== undefined && (
                        <span className="text-slate-400 font-mono text-[11px]">
                          ({queryResult.rowCount} صفوف مُرجعة)
                        </span>
                      )}
                    </div>

                    {queryResult.executionTimeMs !== undefined && (
                      <span className="text-slate-500 text-[11px] font-mono">
                        الوقت: {queryResult.executionTimeMs}ms
                      </span>
                    )}
                  </div>

                  {queryResult.message && (
                    <div
                      className={`p-3 rounded-xl text-xs ${
                        queryResult.success
                          ? 'bg-emerald-950/40 text-emerald-300 border border-emerald-800'
                          : 'bg-rose-950/40 text-rose-300 border border-rose-800'
                      }`}
                    >
                      {queryResult.message}
                    </div>
                  )}

                  {queryResult.rows && queryResult.rows.length > 0 && queryResult.columns && (
                    <div className="overflow-x-auto rounded-xl border border-slate-800 max-h-64">
                      <table className="w-full text-right text-xs font-mono">
                        <thead className="bg-slate-950 text-slate-400 text-[11px] sticky top-0">
                          <tr>
                            {queryResult.columns.map((col) => (
                              <th key={col} className="p-2 border-b border-slate-800 font-bold">
                                {col}
                              </th>
                            ))}
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-slate-800 bg-slate-900/60">
                          {queryResult.rows.map((row, idx) => (
                            <tr key={idx} className="hover:bg-slate-800/40">
                              {queryResult.columns!.map((col) => (
                                <td key={col} className="p-2 text-slate-300 whitespace-nowrap">
                                  {String(row[col] ?? 'NULL')}
                                </td>
                              ))}
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  )}
                </div>
              )}
            </div>
          )}

          {activeTab === 'schema' && (
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs text-slate-400">
                  مخطط DDL متوافق مع Android Room / SQLite Persistence:
                </span>
                <button
                  onClick={handleCopySchema}
                  className="px-2.5 py-1 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs rounded flex items-center gap-1"
                >
                  {isCopied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{isCopied ? 'تم النسخ' : 'نسخ المخطط'}</span>
                </button>
              </div>

              <pre className="p-4 bg-slate-950 font-mono text-xs text-cyan-300 rounded-xl border border-slate-800 overflow-x-auto max-h-96 leading-relaxed">
                {SQL_SCHEMA_DDL}
              </pre>
            </div>
          )}

          {activeTab === 'backup' && (
            <div className="space-y-4 text-xs">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {/* Export SQL */}
                <div className="p-4 bg-slate-950 rounded-xl border border-slate-800 space-y-3">
                  <h3 className="font-bold text-white text-sm flex items-center gap-2">
                    <Download className="w-4 h-4 text-emerald-400" />
                    تصدير ملف SQLite Dump (.sql)
                  </h3>
                  <p className="text-slate-400 text-xs">
                    توليد ملف نصي يحتوي على كامل أوامر CREATE TABLE و INSERT لجميع بيانات الفندق.
                  </p>
                  <button
                    onClick={exportDatabaseSql}
                    className="w-full py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-lg transition cursor-pointer"
                  >
                    تنزيل ملف qasr_alsadaqa_backup.sql
                  </button>
                </div>

                {/* Export JSON */}
                <div className="p-4 bg-slate-950 rounded-xl border border-slate-800 space-y-3">
                  <h3 className="font-bold text-white text-sm flex items-center gap-2">
                    <Download className="w-4 h-4 text-cyan-400" />
                    تصدير نسخة احتياطية كاملة (.json)
                  </h3>
                  <p className="text-slate-400 text-xs">
                    حفظ نسخة احتياطية متكاملة لبيانات الغرف، النزلاء، الحجوزات وإعدادات النظام.
                  </p>
                  <button
                    onClick={exportDatabaseJson}
                    className="w-full py-2 bg-cyan-600 hover:bg-cyan-500 text-white font-bold rounded-lg transition cursor-pointer"
                  >
                    تنزيل ملف JSON Backup
                  </button>
                </div>
              </div>

              {/* Restore JSON */}
              <div className="p-4 bg-slate-950 rounded-xl border border-slate-800 space-y-3">
                <h3 className="font-bold text-white text-sm flex items-center gap-2">
                  <Upload className="w-4 h-4 text-amber-400" />
                  استعادة نسخة احتياطية من ملف
                </h3>
                <p className="text-slate-400 text-xs">
                  اختر ملف نسخة احتياطية (.json) لاستعادة البيانات مباشرة إلى قاعدة البيانات المحلية.
                </p>
                <input
                  type="file"
                  accept=".json"
                  onChange={handleFileUpload}
                  className="block w-full text-xs text-slate-400 file:mr-4 file:py-2 file:px-4 file:rounded-lg file:border-0 file:text-xs file:font-semibold file:bg-slate-800 file:text-white hover:file:bg-slate-700 cursor-pointer"
                />
                {importStatus && (
                  <p className="text-xs text-emerald-400 font-semibold">{importStatus}</p>
                )}
              </div>

              {/* Reset Database */}
              <div className="p-4 bg-rose-950/30 rounded-xl border border-rose-900/50 flex items-center justify-between gap-4">
                <div>
                  <h4 className="font-bold text-rose-300">إعادة تعيين البيانات التجريبية (Factory Reset)</h4>
                  <p className="text-slate-400 text-[11px]">
                    استعادة 24 غرفة ونزلاء تجريبيين وإعادة ضبط جداول SQLite الافتراضية.
                  </p>
                </div>
                <button
                  onClick={() => {
                    if (window.confirm('هل أنت متأكد من إعادة ضبط قاعدة البيانات إلى البيانات الافتراضية؟')) {
                      resetToDemoData();
                      setQueryResult({
                        success: true,
                        message: 'تمت إعادة ضبط قاعدة البيانات المحلية بنجاح!',
                      });
                    }
                  }}
                  className="px-3.5 py-2 bg-rose-600 hover:bg-rose-500 text-white rounded-lg font-bold shrink-0 transition cursor-pointer"
                >
                  إعادة التعيين
                </button>
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="p-3 bg-slate-950 border-t border-slate-800 flex justify-end">
          <button
            onClick={() => setIsSqlConsoleOpen(false)}
            className="px-4 py-1.5 bg-slate-800 hover:bg-slate-700 text-white rounded-lg text-xs font-semibold"
          >
            إغلاق
          </button>
        </div>
      </div>
    </div>
  );
};
