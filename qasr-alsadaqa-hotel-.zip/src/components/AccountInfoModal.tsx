import { isValidPin, savePin } from '../utils/pin';
import { AccountManageTab } from './AccountManageTab';
import React, { useState } from 'react';
import { useHotel } from '../context/HotelContext';
import {
  User,
  Shield,
  Phone,
  Mail,
  Clock,
  KeyRound,
  CheckCircle2,
  Repeat,
  X,
  Lock,
} from 'lucide-react';

export const AccountInfoModal: React.FC = () => {
  const {
    isAccountModalOpen,
    setIsAccountModalOpen,
    currentUser,
    systemProfiles,
    staffMembers,
    switchUser,
  } = useHotel();

  const [activeTab, setActiveTab] = useState<'profile' | 'switch_user' | 'manage' | 'security'>('profile');
  const [newPin, setNewPin] = useState('');
  const [pinSaved, setPinSaved] = useState(false);

  if (!isAccountModalOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4" dir="rtl">
      <div className="bg-white dark:bg-slate-900 rounded-3xl p-6 w-full max-w-lg max-h-[92vh] overflow-y-auto border border-slate-200 dark:border-slate-800 shadow-2xl space-y-5 animate-scaleUp">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-sky-500/10 text-sky-500">
              <User className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base sm:text-lg font-bold text-slate-800 dark:text-slate-100">
                معلومات الحساب (Account Information)
              </h3>
              <p className="text-xs text-slate-400 font-mono">@{currentUser.username}</p>
            </div>
          </div>

          <button
            onClick={() => setIsAccountModalOpen(false)}
            className="p-1 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Sub Tabs */}
        <div className="flex items-center gap-2 border-b border-slate-100 dark:border-slate-800 pb-2">
          <button
            onClick={() => setActiveTab('profile')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition cursor-pointer ${
              activeTab === 'profile'
                ? 'bg-sky-600 text-white'
                : 'text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800'
            }`}
          >
            الملف الشخصي
          </button>

          <button
            onClick={() => setActiveTab('switch_user')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition cursor-pointer flex items-center gap-1 ${
              activeTab === 'switch_user'
                ? 'bg-sky-600 text-white'
                : 'text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800'
            }`}
          >
            <Repeat className="w-3.5 h-3.5" />
            <span>تبديل المستخدم (⇄)</span>
          </button>

          <button
            onClick={() => setActiveTab('manage')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition cursor-pointer ${
              activeTab === 'manage'
                ? 'bg-sky-600 text-white'
                : 'text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800'
            }`}
          >
            الحسابات والكادر
          </button>

          <button
            onClick={() => setActiveTab('security')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition cursor-pointer ${
              activeTab === 'security'
                ? 'bg-sky-600 text-white'
                : 'text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800'
            }`}
          >
            الأمان ورمز PIN
          </button>
        </div>

        {/* Tab 1: Profile Details */}
        {activeTab === 'profile' && (
          <div className="space-y-4 text-xs sm:text-sm">
            <div className="p-4 rounded-2xl bg-sky-50 dark:bg-sky-950/30 border border-sky-100 dark:border-sky-900/50 flex items-center gap-3">
              <div className="w-12 h-12 rounded-full bg-sky-600 text-white flex items-center justify-center font-bold text-lg">
                {currentUser.name.charAt(0)}
              </div>
              <div>
                <div className="font-bold text-slate-800 dark:text-slate-100 text-base">{currentUser.name}</div>
                <div className="text-sky-600 dark:text-sky-400 font-semibold">{currentUser.roleAr}</div>
                <div className="text-[11px] text-slate-400 mt-0.5">الشفت: {currentUser.shift}</div>
              </div>
            </div>

            <div className="space-y-2.5">
              <div className="flex items-center justify-between p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800/40">
                <span className="text-slate-500 flex items-center gap-1.5">
                  <User className="w-4 h-4 text-sky-500" />
                  <span>اسم المستخدم:</span>
                </span>
                <span className="font-mono font-bold text-slate-700 dark:text-slate-200">
                  {currentUser.username}
                </span>
              </div>

              <div className="flex items-center justify-between p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800/40">
                <span className="text-slate-500 flex items-center gap-1.5">
                  <Mail className="w-4 h-4 text-sky-500" />
                  <span>البريد الإلكتروني:</span>
                </span>
                <span className="font-mono text-slate-700 dark:text-slate-200">{currentUser.email}</span>
              </div>

              <div className="flex items-center justify-between p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800/40">
                <span className="text-slate-500 flex items-center gap-1.5">
                  <Phone className="w-4 h-4 text-sky-500" />
                  <span>رقم الهاتف:</span>
                </span>
                <span className="font-mono text-slate-700 dark:text-slate-200">{currentUser.phone}</span>
              </div>

              <div className="flex items-center justify-between p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800/40">
                <span className="text-slate-500 flex items-center gap-1.5">
                  <Clock className="w-4 h-4 text-sky-500" />
                  <span>آخر تسجيل دخول:</span>
                </span>
                <span className="font-mono text-xs text-slate-500">{currentUser.lastLogin}</span>
              </div>
            </div>

            <div className="pt-2">
              <div className="font-semibold text-slate-700 dark:text-slate-300 mb-2 flex items-center gap-1.5">
                <Shield className="w-4 h-4 text-emerald-500" />
                <span>الصلاحيات الممنوحة للحساب:</span>
              </div>
              <div className="flex flex-wrap gap-1.5">
                {currentUser.permissions.map((p, idx) => (
                  <span
                    key={idx}
                    className="px-2.5 py-1 rounded-lg text-[11px] bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 font-medium"
                  >
                    ✓ {p}
                  </span>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* Tab 2: Switch User (⇄ admin) */}
        {activeTab === 'switch_user' && (
          <div className="space-y-3">
            <p className="text-xs text-slate-500">
              اختر حساب المستخدم أو الموظف للتبديل الفوري وتسجيل الشفت:
            </p>

            <div className="space-y-2">
              <button
                onClick={() => {
                  switchUser('admin');
                  setActiveTab('profile');
                }}
                className={`w-full p-3 rounded-2xl border text-right transition cursor-pointer flex items-center justify-between ${
                  currentUser.username === 'admin'
                    ? 'border-sky-500 bg-sky-50 dark:bg-sky-950/40'
                    : 'border-slate-200 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800'
                }`}
              >
                <div>
                  <div className="font-bold text-slate-800 dark:text-slate-100 flex items-center gap-1.5">
                    <span>مدير النظام (admin)</span>
                    <span className="px-2 py-0.5 rounded text-[10px] bg-sky-500 text-white font-mono">
                      مدير النظام
                    </span>
                  </div>
                  <div className="text-xs text-slate-500 font-mono">@admin</div>
                </div>
                {currentUser.username === 'admin' && (
                  <CheckCircle2 className="w-5 h-5 text-sky-600 shrink-0" />
                )}
              </button>

              <button
                onClick={() => {
                  switchUser('reception');
                  setActiveTab('profile');
                }}
                className={`w-full p-3 rounded-2xl border text-right transition cursor-pointer flex items-center justify-between ${
                  currentUser.username === 'reception'
                    ? 'border-sky-500 bg-sky-50 dark:bg-sky-950/40'
                    : 'border-slate-200 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800'
                }`}
              >
                <div>
                  <div className="font-bold text-slate-800 dark:text-slate-100">{systemProfiles.reception.name}</div>
                  <div className="text-xs text-slate-500">{systemProfiles.reception.roleAr}</div>
                </div>
                {currentUser.username === 'reception' && <CheckCircle2 className="w-5 h-5 text-sky-600 shrink-0" />}
              </button>

              {staffMembers.filter((st) => st.status !== 'resigned' && st.username !== 'admin').map((staff) => (
                <button
                  key={staff.id}
                  onClick={() => {
                    switchUser(staff.username || staff.name);
                    setActiveTab('profile');
                  }}
                  className={`w-full p-3 rounded-2xl border text-right transition cursor-pointer flex items-center justify-between ${
                    currentUser.name === staff.name
                      ? 'border-sky-500 bg-sky-50 dark:bg-sky-950/40'
                      : 'border-slate-200 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800'
                  }`}
                >
                  <div>
                    <div className="font-bold text-slate-800 dark:text-slate-100">
                      {staff.name}
                    </div>
                    <div className="text-xs text-slate-500">{staff.roleTitleAr}</div>
                  </div>
                  {currentUser.name === staff.name && (
                    <CheckCircle2 className="w-5 h-5 text-sky-600 shrink-0" />
                  )}
                </button>
              ))}
            </div>
          </div>
        )}

        {activeTab === 'manage' && <AccountManageTab />}

        {/* Tab 3: Security & PIN */}
        {activeTab === 'security' && (
          <div className="space-y-4 text-xs sm:text-sm">
            <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/40 border border-slate-200 dark:border-slate-700 space-y-3">
              <div className="font-bold text-slate-800 dark:text-slate-100 flex items-center gap-1.5">
                <KeyRound className="w-4 h-4 text-sky-500" />
                <span>تعيين رمز PIN سريع للشاشة</span>
              </div>
              <p className="text-xs text-slate-500">
                يمكنك استخدام رمز PIN مكون من 4 أرقام لإلغاء قفل شاشة الاستقبال بسرعة.
              </p>

              <div>
                <input
                  type="password"
                  maxLength={4}
                  placeholder="••••"
                  value={newPin}
                  inputMode="numeric"
                  onChange={(e) => setNewPin(e.target.value.replace(/\D/g, ''))}
                  className="w-32 text-center text-xl font-mono tracking-widest bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl p-2 font-bold"
                />
              </div>

              <button
                type="button"
                onClick={async () => {
                  if (isValidPin(newPin)) {
                    await savePin(newPin);
                    setNewPin('');
                    setPinSaved(true);
                    setTimeout(() => setPinSaved(false), 2500);
                  } else {
                    alert('يرجى إدخال 4 أرقام فقط لرمز PIN');
                  }
                }}
                className="px-4 py-2 bg-sky-600 hover:bg-sky-500 text-white rounded-xl font-semibold text-xs shadow-sm transition cursor-pointer"
              >
                حفظ رمز PIN
              </button>

              {pinSaved && (
                <span className="inline-flex items-center gap-1 text-emerald-600 text-xs font-bold mr-2">
                  <CheckCircle2 className="w-4 h-4" />
                  تم الحفظ بنجاح
                </span>
              )}
            </div>
          </div>
        )}

        {/* Footer Close */}
        <div className="pt-2 flex justify-end">
          <button
            onClick={() => setIsAccountModalOpen(false)}
            className="px-5 py-2.5 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 font-semibold text-xs hover:bg-slate-200 dark:hover:bg-slate-700 transition cursor-pointer"
          >
            إغلاق
          </button>
        </div>
      </div>
    </div>
  );
};
