import React, { useState } from 'react';
import { useHotel } from '../context/HotelContext';
import { RoomType, RoomStatus } from '../types/hotel';
import {
  X,
  Bed,
  Plus,
  CheckCircle2,
  AlertCircle,
  Building,
  Layers,
  Sparkles,
  Wifi,
  Tv,
  Coffee,
  Shield,
  Eye,
} from 'lucide-react';

const COMMON_FEATURES = [
  'واي فاي فائق السرعة',
  'تكييف هواء سبليت',
  'شاشة تلفزيون ذكية',
  'ثلاجة وميني بار',
  'إطلالة بانورامية',
  'جاكوزي خاص',
  'مكتب عمل مجهز',
  'غلاية شاي ومشروبات ساخنة',
  'خزنة أمانات رقمية',
  'بلكونة خاصة',
  'أرواب وحمام رخامي',
  'نظام صوتي بلوتوث',
];

export const AddRoomModal: React.FC = () => {
  const { isAddRoomModalOpen, setIsAddRoomModalOpen, addRoom, rooms, settings } = useHotel();

  const [roomNumber, setRoomNumber] = useState<string>('');
  const [floor, setFloor] = useState<number>(1);
  const [type, setType] = useState<RoomType>('double');
  const [pricePerNight, setPricePerNight] = useState<number>(250);
  const [capacity, setCapacity] = useState<number>(2);
  const [status, setStatus] = useState<RoomStatus>('available');
  const [features, setFeatures] = useState<string[]>([
    'واي فاي فائق السرعة',
    'تكييف هواء سبليت',
    'شاشة تلفزيون ذكية',
    'ثلاجة وميني بار',
  ]);
  const [notes, setNotes] = useState<string>('');
  const [customFeature, setCustomFeature] = useState<string>('');
  const [errorMessage, setErrorMessage] = useState<string>('');

  if (!isAddRoomModalOpen) return null;

  const isDuplicateNumber = rooms.some(
    (r) => r.roomNumber.trim().toLowerCase() === roomNumber.trim().toLowerCase()
  );

  const handleToggleFeature = (feat: string) => {
    if (features.includes(feat)) {
      setFeatures(features.filter((f) => f !== feat));
    } else {
      setFeatures([...features, feat]);
    }
  };

  const handleAddCustomFeature = (e: React.FormEvent) => {
    e.preventDefault();
    if (customFeature.trim() && !features.includes(customFeature.trim())) {
      setFeatures([...features, customFeature.trim()]);
      setCustomFeature('');
    }
  };

  const handleTypeChange = (selectedType: RoomType) => {
    setType(selectedType);
    if (selectedType === 'single') {
      setCapacity(1);
      if (pricePerNight === 250) setPricePerNight(180);
    } else if (selectedType === 'double') {
      setCapacity(2);
      if (pricePerNight === 180) setPricePerNight(250);
    } else if (selectedType === 'triple') {
      setCapacity(3);
      setPricePerNight(350);
    } else if (selectedType === 'suite') {
      setCapacity(4);
      setPricePerNight(500);
    } else if (selectedType === 'vip_deluxe') {
      setCapacity(4);
      setPricePerNight(750);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage('');

    if (!roomNumber.trim()) {
      setErrorMessage('يرجى إدخال رقم الغرفة.');
      return;
    }

    if (isDuplicateNumber) {
      setErrorMessage(`الغرفة رقم ${roomNumber} مسجلة مسبقاً.`);
      return;
    }

    const result = addRoom({
      roomNumber: roomNumber.trim(),
      floor,
      type,
      pricePerNight: Math.max(1, pricePerNight),
      capacity: Math.max(1, capacity),
      status,
      features,
      notes: notes.trim() || undefined,
    });

    if (result.success) {
      // Reset form
      setRoomNumber('');
      setFloor(1);
      setType('double');
      setPricePerNight(250);
      setCapacity(2);
      setNotes('');
      setErrorMessage('');
      setIsAddRoomModalOpen(false);
    } else {
      setErrorMessage(result.error || 'حدث خطأ أثناء إضافة الغرفة.');
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-950/75 backdrop-blur-xs animate-fadeIn">
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl w-full max-w-xl max-h-[92vh] overflow-y-auto shadow-2xl flex flex-col">
        {/* Header */}
        <div className="p-4 sm:p-5 border-b border-slate-100 dark:border-slate-800 bg-slate-50 dark:bg-slate-950/60 sticky top-0 z-10 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-emerald-600 dark:bg-emerald-500 text-white flex items-center justify-center font-bold shadow-md shadow-emerald-600/20">
              <Plus className="w-6 h-6" />
            </div>
            <div>
              <h2 className="text-base font-bold text-slate-900 dark:text-white">
                إضافة غرفة جديدة للوحدات الفندقية
              </h2>
              <p className="text-xs text-slate-500">
                تسجيل غرفة جديدة في قاعدة بيانات SQLite المحلية
              </p>
            </div>
          </div>

          <button
            onClick={() => setIsAddRoomModalOpen(false)}
            className="p-2 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Form */}
        <form onSubmit={handleSubmit} className="p-4 sm:p-6 space-y-4">
          {errorMessage && (
            <div className="p-3 rounded-xl bg-rose-50 dark:bg-rose-950/30 border border-rose-200 dark:border-rose-900/50 flex items-center gap-2 text-xs text-rose-700 dark:text-rose-300">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{errorMessage}</span>
            </div>
          )}

          {/* Top Row: Room Number & Floor */}
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
            <div className="col-span-1">
              <label className="text-xs font-semibold text-slate-700 dark:text-slate-300 block mb-1">
                رقم الغرفة *
              </label>
              <input
                type="text"
                placeholder="مثال: 101 أو 205"
                value={roomNumber}
                onChange={(e) => setRoomNumber(e.target.value)}
                required
                className={`w-full px-3 py-2 bg-slate-50 dark:bg-slate-800/60 border rounded-xl text-sm font-mono font-bold focus:outline-emerald-500 ${
                  isDuplicateNumber
                    ? 'border-rose-400 text-rose-600'
                    : 'border-slate-300 dark:border-slate-700 text-slate-900 dark:text-white'
                }`}
              />
              {isDuplicateNumber && (
                <span className="text-[10px] text-rose-500 mt-1 block">رقم الغرفة مستخدم بالفعل</span>
              )}
            </div>

            <div>
              <label className="text-xs font-semibold text-slate-700 dark:text-slate-300 block mb-1">
                الطابق *
              </label>
              <select
                value={floor}
                onChange={(e) => setFloor(parseInt(e.target.value) || 1)}
                className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800/60 border border-slate-300 dark:border-slate-700 rounded-xl text-xs font-medium focus:outline-emerald-500"
              >
                {[1, 2, 3, 4, 5, 6, 7, 8, 9, 10].map((fl) => (
                  <option key={fl} value={fl}>
                    الطابق {fl}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="text-xs font-semibold text-slate-700 dark:text-slate-300 block mb-1">
                السعة (أفراد) *
              </label>
              <input
                type="number"
                min="1"
                max="10"
                value={capacity}
                onChange={(e) => setCapacity(parseInt(e.target.value) || 1)}
                className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800/60 border border-slate-300 dark:border-slate-700 rounded-xl text-xs font-bold text-center focus:outline-emerald-500"
                required
              />
            </div>
          </div>

          {/* Row 2: Room Type & Price */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="text-xs font-semibold text-slate-700 dark:text-slate-300 block mb-1">
                نوع الغرفة / التصنيف *
              </label>
              <select
                value={type}
                onChange={(e) => handleTypeChange(e.target.value as RoomType)}
                className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800/60 border border-slate-300 dark:border-slate-700 rounded-xl text-xs font-medium focus:outline-emerald-500"
              >
                <option value="single">غرفة مفردة (Single)</option>
                <option value="double">غرفة مزدوجة (Double)</option>
                <option value="triple">غرفة ثلاثية (Triple)</option>
                <option value="suite">جناح فندقي (Suite)</option>
                <option value="vip_deluxe">جناح ملكي فاخر (VIP Deluxe)</option>
              </select>
            </div>

            <div>
              <label className="text-xs font-semibold text-slate-700 dark:text-slate-300 block mb-1">
                سعر الليلة الواحدة ({settings.currencySymbol}) *
              </label>
              <input
                type="number"
                min="1"
                step="any"
                value={pricePerNight}
                onChange={(e) => setPricePerNight(parseFloat(e.target.value) || 0)}
                required
                className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800/60 border border-slate-300 dark:border-slate-700 rounded-xl text-sm font-bold text-emerald-600 focus:outline-emerald-500"
              />
            </div>
          </div>

          {/* Row 3: Initial Status */}
          <div>
            <label className="text-xs font-semibold text-slate-700 dark:text-slate-300 block mb-1">
              الحالة المبدئية عند الإنشاء
            </label>
            <div className="grid grid-cols-3 gap-2">
              <button
                type="button"
                onClick={() => setStatus('available')}
                className={`py-2 text-xs rounded-xl border font-medium transition cursor-pointer flex items-center justify-center gap-1.5 ${
                  status === 'available'
                    ? 'border-emerald-600 bg-emerald-50 dark:bg-emerald-950/40 text-emerald-700 dark:text-emerald-300 font-bold'
                    : 'border-slate-200 dark:border-slate-800 text-slate-600 hover:bg-slate-50 dark:hover:bg-slate-800'
                }`}
              >
                <span className="w-2 h-2 rounded-full bg-emerald-500"></span>
                🟢 متاحة للحجز
              </button>

              <button
                type="button"
                onClick={() => setStatus('cleaning')}
                className={`py-2 text-xs rounded-xl border font-medium transition cursor-pointer flex items-center justify-center gap-1.5 ${
                  status === 'cleaning'
                    ? 'border-amber-600 bg-amber-50 dark:bg-amber-950/40 text-amber-700 dark:text-amber-300 font-bold'
                    : 'border-slate-200 dark:border-slate-800 text-slate-600 hover:bg-slate-50 dark:hover:bg-slate-800'
                }`}
              >
                <span className="w-2 h-2 rounded-full bg-amber-500"></span>
                🟡 تحت التنظيف
              </button>

              <button
                type="button"
                onClick={() => setStatus('maintenance')}
                className={`py-2 text-xs rounded-xl border font-medium transition cursor-pointer flex items-center justify-center gap-1.5 ${
                  status === 'maintenance'
                    ? 'border-purple-600 bg-purple-50 dark:bg-purple-950/40 text-purple-700 dark:text-purple-300 font-bold'
                    : 'border-slate-200 dark:border-slate-800 text-slate-600 hover:bg-slate-50 dark:hover:bg-slate-800'
                }`}
              >
                <span className="w-2 h-2 rounded-full bg-purple-500"></span>
                🟣 صيانة وتجهيز
              </button>
            </div>
          </div>

          {/* Features Checkbox Grid */}
          <div>
            <label className="text-xs font-semibold text-slate-700 dark:text-slate-300 block mb-1.5">
              المميزات والتجهيزات المتوفرة ({features.length})
            </label>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-1.5 max-h-36 overflow-y-auto p-2 bg-slate-50 dark:bg-slate-800/40 border border-slate-200 dark:border-slate-700/60 rounded-xl text-xs">
              {COMMON_FEATURES.map((feat) => {
                const isSelected = features.includes(feat);
                return (
                  <button
                    type="button"
                    key={feat}
                    onClick={() => handleToggleFeature(feat)}
                    className={`p-1.5 rounded-lg text-right transition cursor-pointer flex items-center gap-1.5 ${
                      isSelected
                        ? 'bg-emerald-600 text-white font-medium shadow-xs'
                        : 'bg-white dark:bg-slate-800 text-slate-600 dark:text-slate-400 hover:bg-slate-100 border border-slate-200 dark:border-slate-700'
                    }`}
                  >
                    <span className="text-[11px] truncate">{feat}</span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Notes */}
          <div>
            <label className="text-xs font-semibold text-slate-700 dark:text-slate-300 block mb-1">
              ملاحظات إضافية (موقع الغرفة، إطلالة، تعليمات)
            </label>
            <input
              type="text"
              placeholder="مثال: واجهة أمامية، بجانب المصعد..."
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800/60 border border-slate-300 dark:border-slate-700 rounded-xl text-xs focus:outline-emerald-500"
            />
          </div>

          {/* Actions */}
          <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-100 dark:border-slate-800">
            <button
              type="button"
              onClick={() => setIsAddRoomModalOpen(false)}
              className="px-4 py-2 text-xs font-semibold text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg transition cursor-pointer"
            >
              إلغاء
            </button>

            <button
              type="submit"
              disabled={!roomNumber.trim() || isDuplicateNumber}
              className="px-5 py-2 bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 disabled:cursor-not-allowed text-white text-xs font-bold rounded-lg transition flex items-center gap-1.5 shadow-md shadow-emerald-600/20 cursor-pointer"
            >
              <CheckCircle2 className="w-4 h-4" />
              <span>إضافة الغرفة وحفظها</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
