import React, { useState } from 'react';
import { useHotel } from '../context/HotelContext';
import {
  Settings,
  Building2,
  Database,
  Users,
  Percent,
  Clock,
  Shield,
  FileCode2,
  Download,
  Upload,
  RotateCcw,
  CheckCircle2,
  Plus,
  Trash2,
  Edit2,
  KeyRound,
  FileText,
  Cloud,
  CloudUpload,
  FolderSync,
  Check,
  ExternalLink,
} from 'lucide-react';
import { RoomType, AutoBackupFrequency } from '../types/hotel';

export const SystemAdminView: React.FC = () => {
  const {
    settings,
    updateSettings,
    rooms,
    addRoom,
    deleteRoom,
    staffMembers,
    addStaffMember,
    deleteStaffMember,
    exportDatabaseSql,
    exportDatabaseJson,
    importDatabaseJson,
    resetToDemoData,
    currentUser,
    // Google Drive & Backup
    googleAccounts,
    selectedGoogleAccount,
    selectedGoogleAccountId,
    selectActiveGoogleAccount,
    linkGoogleAccountManually,
    autoBackupConfig,
    updateAutoBackupConfig,
    backupSnapshots,
    createBackupSnapshot,
    restoreBackupSnapshot,
    syncSnapshotToGoogleDrive,
    syncAllToGoogleDriveNow,
    isSyncingToGoogleDrive,
    setIsGoogleDriveLinkModalOpen,
    setIsAutoBackupModalOpen,
  } = useHotel();

  const [adminTab, setAdminTab] = useState<'general' | 'rooms' | 'staff' | 'database'>('general');
  const [generalForm, setGeneralForm] = useState({ ...settings });
  const [isSavedToast, setIsSavedToast] = useState(false);

  // New Google Account Form
  const [showAddGoogleAccount, setShowAddGoogleAccount] = useState(false);
  const [googleEmail, setGoogleEmail] = useState('');
  const [googleName, setGoogleName] = useState('');

  // New Room Form
  const [newRoomForm, setNewRoomForm] = useState({
    roomNumber: '',
    floor: 1,
    type: 'single' as RoomType,
    pricePerNight: 250,
    capacity: 2,
  });

  const handleSaveGeneral = (e: React.FormEvent) => {
    e.preventDefault();
    updateSettings(generalForm);
    setIsSavedToast(true);
    setTimeout(() => setIsSavedToast(false), 3000);
  };

  const handleAddRoom = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newRoomForm.roomNumber) return;

    const res = addRoom({
      roomNumber: newRoomForm.roomNumber,
      floor: Number(newRoomForm.floor),
      type: newRoomForm.type,
      pricePerNight: Number(newRoomForm.pricePerNight),
      capacity: Number(newRoomForm.capacity),
      status: 'available',
      features: ['واي فاي فائق السرعة', 'تكييف هواء', 'شاشة ذكية', 'ثلاجة وميني بار'],
    });

    if (res.success) {
      setNewRoomForm({
        roomNumber: '',
        floor: 1,
        type: 'single',
        pricePerNight: 250,
        capacity: 2,
      });
    } else {
      alert(res.error || 'حدث خطأ أثناء إضافة الغرفة');
    }
  };

  const handleImportFile = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const ok = await importDatabaseJson(file);
    if (ok) {
      alert('تمت استعادة قاعدة بيانات SQLite بنجاح!');
    } else {
      alert('فشل استيراد النسخة الاحتياطية. يرجى التحقق من صحة الملف.');
    }
  };

  return (
    <div className="space-y-6 animate-fadeIn" dir="rtl">
      {/* Header Banner */}
      <div className="bg-white dark:bg-slate-900 rounded-2xl p-5 sm:p-6 border border-slate-200 dark:border-slate-800 shadow-sm flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="p-3 rounded-2xl bg-sky-500/10 text-sky-500 shrink-0">
            <Settings className="w-7 h-7 stroke-[1.75]" />
          </div>
          <div>
            <h2 className="text-lg sm:text-xl font-bold text-slate-800 dark:text-slate-100">
              إدارة النظام والإعدادات العامة (System Administration)
            </h2>
            <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400">
              التحكم في بيانات المنشأة الضريبية، تسعير الغرف، الصلاحيات، وإدارة قاعدة بيانات SQLite
            </p>
          </div>
        </div>

        {isSavedToast && (
          <div className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-emerald-50 text-emerald-600 border border-emerald-200 text-xs font-bold animate-bounce">
            <CheckCircle2 className="w-4 h-4" />
            <span>تم حفظ الإعدادات بنجاح!</span>
          </div>
        )}
      </div>

      {/* Tabs */}
      <div className="flex items-center gap-2 border-b border-slate-200 dark:border-slate-800 pb-3 overflow-x-auto no-scrollbar">
        <button
          onClick={() => setAdminTab('general')}
          className={`px-4 py-2 rounded-xl text-xs sm:text-sm font-semibold transition cursor-pointer whitespace-nowrap flex items-center gap-2 ${
            adminTab === 'general'
              ? 'bg-sky-600 text-white shadow-sm'
              : 'bg-white dark:bg-slate-900 text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 border border-slate-200 dark:border-slate-800'
          }`}
        >
          <Building2 className="w-4 h-4" />
          <span>بيانات الفندق والفوترة الضريبية</span>
        </button>

        <button
          onClick={() => setAdminTab('rooms')}
          className={`px-4 py-2 rounded-xl text-xs sm:text-sm font-semibold transition cursor-pointer whitespace-nowrap flex items-center gap-2 ${
            adminTab === 'rooms'
              ? 'bg-sky-600 text-white shadow-sm'
              : 'bg-white dark:bg-slate-900 text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 border border-slate-200 dark:border-slate-800'
          }`}
        >
          <Percent className="w-4 h-4" />
          <span>إدارة الغرف والتسعير ({rooms.length})</span>
        </button>

        <button
          onClick={() => setAdminTab('staff')}
          className={`px-4 py-2 rounded-xl text-xs sm:text-sm font-semibold transition cursor-pointer whitespace-nowrap flex items-center gap-2 ${
            adminTab === 'staff'
              ? 'bg-sky-600 text-white shadow-sm'
              : 'bg-white dark:bg-slate-900 text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 border border-slate-200 dark:border-slate-800'
          }`}
        >
          <Users className="w-4 h-4" />
          <span>المستخدمين والصلاحيات ({staffMembers.length})</span>
        </button>

        <button
          onClick={() => setAdminTab('database')}
          className={`px-4 py-2 rounded-xl text-xs sm:text-sm font-semibold transition cursor-pointer whitespace-nowrap flex items-center gap-2 ${
            adminTab === 'database'
              ? 'bg-sky-600 text-white shadow-sm'
              : 'bg-white dark:bg-slate-900 text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 border border-slate-200 dark:border-slate-800'
          }`}
        >
          <Cloud className="w-4 h-4 text-sky-400" />
          <span>النسخ الاحتياطي و Google Drive و SQLite</span>
        </button>
      </div>

      {/* Tab 1: General Settings */}
      {adminTab === 'general' && (
        <form onSubmit={handleSaveGeneral} className="bg-white dark:bg-slate-900 rounded-2xl p-6 border border-slate-200 dark:border-slate-800 shadow-sm space-y-5">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs sm:text-sm">
            <div>
              <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
                اسم الفندق الرسمي:
              </label>
              <input
                type="text"
                value={generalForm.hotelName}
                onChange={(e) => setGeneralForm({ ...generalForm, hotelName: e.target.value })}
                className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl p-2.5 font-bold"
                required
              />
            </div>

            <div>
              <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
                الرقم الضريبي (VAT Number):
              </label>
              <input
                type="text"
                value={generalForm.taxNumber}
                onChange={(e) => setGeneralForm({ ...generalForm, taxNumber: e.target.value })}
                className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl p-2.5 font-mono"
              />
            </div>

            <div>
              <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
                رقم السجل التجاري:
              </label>
              <input
                type="text"
                value={generalForm.commercialRegistration}
                onChange={(e) => setGeneralForm({ ...generalForm, commercialRegistration: e.target.value })}
                className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl p-2.5 font-mono"
              />
            </div>

            <div>
              <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
                العنوان والمدينة:
              </label>
              <input
                type="text"
                value={generalForm.address}
                onChange={(e) => setGeneralForm({ ...generalForm, address: e.target.value })}
                className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl p-2.5"
              />
            </div>

            <div>
              <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
                موعد تسجيل الوصول الافتراضي (Check-in):
              </label>
              <input
                type="time"
                value={generalForm.checkInTime}
                onChange={(e) => setGeneralForm({ ...generalForm, checkInTime: e.target.value })}
                className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl p-2.5 font-mono"
              />
            </div>

            <div>
              <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
                موعد تسجيل المغادرة الافتراضي (Check-out):
              </label>
              <input
                type="time"
                value={generalForm.checkOutTime}
                onChange={(e) => setGeneralForm({ ...generalForm, checkOutTime: e.target.value })}
                className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl p-2.5 font-mono"
              />
            </div>

            <div>
              <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
                رمز العملة:
              </label>
              <input
                type="text"
                value={generalForm.currencySymbol}
                onChange={(e) => setGeneralForm({ ...generalForm, currencySymbol: e.target.value })}
                className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl p-2.5 font-mono"
              />
            </div>

            <div>
              <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
                نسبة ضريبة القيمة المضافة (%):
              </label>
              <input
                type="number"
                value={generalForm.taxRatePercent}
                onChange={(e) => setGeneralForm({ ...generalForm, taxRatePercent: Number(e.target.value) })}
                className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl p-2.5 font-mono"
              />
            </div>
          </div>

          <div className="pt-4 border-t border-slate-100 dark:border-slate-800 flex justify-end">
            <button
              type="submit"
              className="px-6 py-2.5 rounded-xl bg-sky-600 hover:bg-sky-500 text-white font-semibold text-sm shadow-md transition cursor-pointer"
            >
              حفظ التعديلات
            </button>
          </div>
        </form>
      )}

      {/* Tab 2: Rooms Management */}
      {adminTab === 'rooms' && (
        <div className="space-y-6">
          {/* Add Room Box */}
          <form onSubmit={handleAddRoom} className="bg-white dark:bg-slate-900 rounded-2xl p-5 border border-slate-200 dark:border-slate-800 shadow-sm space-y-4">
            <h3 className="font-bold text-sm text-slate-800 dark:text-slate-100 flex items-center gap-2">
              <Plus className="w-4 h-4 text-sky-500" />
              <span>إضافة غرفة جديدة إلى الفندق</span>
            </h3>

            <div className="grid grid-cols-2 md:grid-cols-5 gap-3 text-xs">
              <div>
                <label className="block font-semibold mb-1">رقم الغرفة:</label>
                <input
                  type="text"
                  placeholder="مثال: 301"
                  value={newRoomForm.roomNumber}
                  onChange={(e) => setNewRoomForm({ ...newRoomForm, roomNumber: e.target.value })}
                  className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl p-2 font-mono font-bold"
                  required
                />
              </div>

              <div>
                <label className="block font-semibold mb-1">الطابق:</label>
                <input
                  type="number"
                  min="1"
                  value={newRoomForm.floor}
                  onChange={(e) => setNewRoomForm({ ...newRoomForm, floor: Number(e.target.value) })}
                  className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl p-2 font-mono"
                />
              </div>

              <div>
                <label className="block font-semibold mb-1">نوع الغرفة:</label>
                <select
                  value={newRoomForm.type}
                  onChange={(e) => setNewRoomForm({ ...newRoomForm, type: e.target.value as any })}
                  className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl p-2"
                >
                  <option value="single">غرفة مفردة (Single)</option>
                  <option value="double">غرفة مزدوجة (Double)</option>
                  <option value="triple">غرفة ثلاثية (Triple)</option>
                  <option value="suite">جناح فندقي فاخر (Suite)</option>
                  <option value="vip_deluxe">جناح ملكي ديلوكس (Royal)</option>
                </select>
              </div>

              <div>
                <label className="block font-semibold mb-1">السعر/ليلة ({settings.currencySymbol}):</label>
                <input
                  type="number"
                  min="50"
                  value={newRoomForm.pricePerNight}
                  onChange={(e) => setNewRoomForm({ ...newRoomForm, pricePerNight: Number(e.target.value) })}
                  className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl p-2 font-mono"
                />
              </div>

              <div className="flex items-end">
                <button
                  type="submit"
                  className="w-full py-2 bg-sky-600 hover:bg-sky-500 text-white rounded-xl font-semibold transition cursor-pointer shadow-sm"
                >
                  إضافة الغرفة
                </button>
              </div>
            </div>
          </form>

          {/* Rooms Grid */}
          <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-right text-xs sm:text-sm">
                <thead className="bg-slate-50 dark:bg-slate-950 text-slate-500 border-b border-slate-200 dark:border-slate-800 font-semibold">
                  <tr>
                    <th className="py-3 px-4">رقم الغرفة</th>
                    <th className="py-3 px-4">الطابق</th>
                    <th className="py-3 px-4">النوع</th>
                    <th className="py-3 px-4">السعر / ليلة</th>
                    <th className="py-3 px-4">السعة</th>
                    <th className="py-3 px-4">الحالة الحالية</th>
                    <th className="py-3 px-4 text-center">حذف</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                  {rooms.map((r) => (
                    <tr key={r.id} className="hover:bg-slate-50 dark:hover:bg-slate-800/40">
                      <td className="py-3 px-4 font-mono font-bold text-sky-600">#{r.roomNumber}</td>
                      <td className="py-3 px-4">الطابق {r.floor}</td>
                      <td className="py-3 px-4 font-medium">{r.type}</td>
                      <td className="py-3 px-4 font-mono font-bold">{r.pricePerNight} {settings.currencySymbol}</td>
                      <td className="py-3 px-4">{r.capacity} أفراد</td>
                      <td className="py-3 px-4">
                        <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-slate-100 dark:bg-slate-800">
                          {r.status === 'available' ? 'متاحة' : r.status === 'occupied' ? 'مشغولة' : 'تنظيف'}
                        </span>
                      </td>
                      <td className="py-3 px-4 text-center">
                        <button
                          onClick={() => {
                            if (window.confirm(`هل أنت متأكد من حذف الغرفة #${r.roomNumber}؟`)) {
                              deleteRoom(r.id);
                            }
                          }}
                          className="p-1.5 text-slate-400 hover:text-rose-600 transition cursor-pointer"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* Tab 3: Staff & Permissions */}
      {adminTab === 'staff' && (
        <div className="bg-white dark:bg-slate-900 rounded-2xl p-5 border border-slate-200 dark:border-slate-800 shadow-sm space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="font-bold text-slate-800 dark:text-slate-100 flex items-center gap-2">
              <Shield className="w-5 h-5 text-sky-500" />
              <span>مستخدمي النظام وصلاحيات الدخول</span>
            </h3>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {staffMembers.map((staff) => (
              <div
                key={staff.id}
                className="p-4 rounded-2xl border border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-800/30 flex items-start justify-between"
              >
                <div>
                  <div className="font-bold text-slate-800 dark:text-slate-100 flex items-center gap-2">
                    <span>{staff.name}</span>
                    {staff.username === currentUser.username && (
                      <span className="px-2 py-0.5 rounded-full text-[10px] bg-sky-500 text-white font-bold">
                        الحساب الحالي
                      </span>
                    )}
                  </div>
                  <div className="text-xs text-sky-600 dark:text-sky-400 mt-0.5">{staff.roleTitleAr}</div>
                  <div className="text-xs text-slate-400 font-mono mt-2">
                    اسم المستخدم: <strong>{staff.username || 'user'}</strong> | هاتف: {staff.phone}
                  </div>
                </div>

                <div className="text-left">
                  <span className="px-2 py-1 rounded text-[10px] font-mono bg-slate-200 dark:bg-slate-700 text-slate-700 dark:text-slate-200 font-semibold">
                    {staff.role}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Tab 4: Google Drive & Auto Backup & SQLite Database Tools */}
      {adminTab === 'database' && (
        <div className="space-y-6 animate-fadeIn">
          {/* SECTION 1: GOOGLE DRIVE MANUAL ACCOUNT LINKING */}
          <div className="bg-gradient-to-br from-sky-50 via-white to-blue-50/60 dark:from-slate-900 dark:via-slate-900 dark:to-sky-950/30 rounded-2xl p-5 sm:p-6 border border-sky-200 dark:border-sky-800/60 shadow-xs space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-sky-100 dark:border-slate-800 pb-3">
              <div>
                <div className="flex items-center gap-2">
                  <Cloud className="w-5 h-5 text-sky-600 dark:text-sky-400" />
                  <h3 className="text-base font-bold text-slate-800 dark:text-slate-100">
                    ربط سحابة Google Drive (تحديد الحساب يدويًا)
                  </h3>
                  <span className="px-2 py-0.5 rounded-full bg-sky-100 dark:bg-sky-950 text-sky-700 dark:text-sky-300 font-bold text-[10px] border border-sky-300 dark:border-sky-800">
                    Manual Link
                  </span>
                </div>
                <p className="text-xs text-slate-500 mt-1">
                  اختر حساب Google Drive المخصص يدويًا ليتم حفظ النسخ الاحتياطية تلقائيًا عليه.
                </p>
              </div>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => setShowAddGoogleAccount(!showAddGoogleAccount)}
                  className="px-3 py-1.5 rounded-xl bg-sky-600 hover:bg-sky-700 text-white font-bold text-xs shadow-xs transition cursor-pointer flex items-center gap-1.5"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>{showAddGoogleAccount ? 'إغلاق النموذج' : 'إضافة حساب يدوي'}</span>
                </button>

                <button
                  type="button"
                  onClick={() => setIsGoogleDriveLinkModalOpen(true)}
                  className="px-3 py-1.5 rounded-xl bg-white dark:bg-slate-800 hover:bg-slate-100 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 border border-slate-300 dark:border-slate-700 font-semibold text-xs transition cursor-pointer flex items-center gap-1"
                >
                  <ExternalLink className="w-3.5 h-3.5" />
                  <span>نافذة الربط الكاملة</span>
                </button>
              </div>
            </div>

            {/* Inline Add Account */}
            {showAddGoogleAccount && (
              <div className="p-4 rounded-xl bg-white dark:bg-slate-950 border border-sky-300 dark:border-sky-800 space-y-3">
                <div className="font-bold text-sky-700 dark:text-sky-300 text-xs flex items-center gap-1.5">
                  <CloudUpload className="w-4 h-4" />
                  <span>ربط حساب Google جديد يدوياً:</span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                  <div>
                    <label className="block text-slate-600 dark:text-slate-400 mb-1 font-semibold">
                      البريد الإلكتروني لحساب Google:
                    </label>
                    <input
                      type="email"
                      value={googleEmail}
                      onChange={(e) => setGoogleEmail(e.target.value)}
                      placeholder="example@gmail.com"
                      className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 font-mono text-left focus:outline-none focus:border-sky-500"
                      dir="ltr"
                    />
                  </div>

                  <div>
                    <label className="block text-slate-600 dark:text-slate-400 mb-1 font-semibold">
                      اسم الحساب أو المسمى:
                    </label>
                    <input
                      type="text"
                      value={googleName}
                      onChange={(e) => setGoogleName(e.target.value)}
                      placeholder="e.g. حساب الإدارة الرئيسي"
                      className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 focus:outline-none focus:border-sky-500"
                    />
                  </div>
                </div>

                <div className="flex items-center justify-end gap-2 pt-1">
                  <button
                    type="button"
                    onClick={() => setShowAddGoogleAccount(false)}
                    className="px-3 py-1.5 text-slate-500 hover:bg-slate-100 rounded-lg text-xs"
                  >
                    إلغاء
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      if (googleEmail.trim()) {
                        linkGoogleAccountManually({
                          email: googleEmail.trim(),
                          displayName: googleName.trim() || undefined,
                        });
                        setShowAddGoogleAccount(false);
                      }
                    }}
                    className="px-4 py-1.5 bg-sky-600 hover:bg-sky-700 text-white rounded-xl font-bold text-xs shadow-xs transition"
                  >
                    ربط وتعيين كحساب نشط
                  </button>
                </div>
              </div>
            )}

            {/* List of Accounts */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {googleAccounts.map((account) => {
                const isSelected = selectedGoogleAccountId === account.id;

                return (
                  <div
                    key={account.id}
                    onClick={() => selectActiveGoogleAccount(account.id)}
                    className={`p-3.5 rounded-xl border transition cursor-pointer ${
                      isSelected
                        ? 'bg-sky-100/70 dark:bg-sky-950/60 border-sky-500 ring-2 ring-sky-500/20 shadow-xs'
                        : 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800 hover:border-sky-300'
                    }`}
                  >
                    <div className="flex items-center justify-between gap-2">
                      <div className="flex items-center gap-2.5">
                        <div
                          className={`w-8 h-8 rounded-full flex items-center justify-center font-bold text-white text-xs ${
                            isSelected ? 'bg-sky-600' : 'bg-slate-400 dark:bg-slate-600'
                          }`}
                        >
                          {account.email.substring(0, 1).toUpperCase()}
                        </div>
                        <div>
                          <span className="font-bold text-slate-900 dark:text-white block text-xs truncate">
                            {account.displayName}
                          </span>
                          <span className="font-mono text-[10px] text-slate-500 block" dir="ltr">
                            {account.email}
                          </span>
                        </div>
                      </div>

                      <div
                        className={`w-4 h-4 rounded-full border flex items-center justify-center ${
                          isSelected ? 'border-sky-600 bg-sky-600 text-white' : 'border-slate-300'
                        }`}
                      >
                        {isSelected && <Check className="w-3 h-3 stroke-[3]" />}
                      </div>
                    </div>

                    <div className="mt-2.5 pt-2 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between text-[10px] text-slate-500">
                      <span>المجلد: <span className="font-mono text-sky-600">{account.folderName}</span></span>
                      {isSelected && (
                        <span className="text-emerald-600 dark:text-emerald-400 font-bold flex items-center gap-1">
                          <CheckCircle2 className="w-3 h-3" />
                          الحساب النشط
                        </span>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>

            {/* Sync Bar */}
            {selectedGoogleAccount && (
              <div className="p-3.5 bg-white dark:bg-slate-900 rounded-xl border border-sky-200 dark:border-sky-900/50 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
                <div className="flex items-center gap-2.5">
                  <FolderSync className="w-4 h-4 text-sky-600 animate-pulse" />
                  <div>
                    <span className="font-bold text-slate-800 dark:text-slate-200 block">
                      الحساب المعتمد حالياً: {selectedGoogleAccount.email}
                    </span>
                    <span className="text-[11px] text-slate-400">
                      مجلد السحابة: {selectedGoogleAccount.folderName}
                    </span>
                  </div>
                </div>

                <button
                  type="button"
                  disabled={isSyncingToGoogleDrive}
                  onClick={() => syncAllToGoogleDriveNow()}
                  className="inline-flex items-center justify-center gap-2 px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50 text-white font-bold text-xs shadow-xs transition cursor-pointer"
                >
                  <CloudUpload className={`w-3.5 h-3.5 ${isSyncingToGoogleDrive ? 'animate-spin' : ''}`} />
                  <span>{isSyncingToGoogleDrive ? 'جاري المزامنة...' : 'مزامنة مع Google Drive الآن'}</span>
                </button>
              </div>
            )}
          </div>

          {/* SECTION 2: AUTOMATIC BACKUP CONFIGURATION */}
          <div className="bg-white dark:bg-slate-900 rounded-2xl p-5 sm:p-6 border border-slate-200 dark:border-slate-800 shadow-sm space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-200 dark:border-slate-800 pb-3">
              <div>
                <div className="flex items-center gap-2">
                  <Clock className="w-5 h-5 text-emerald-600 dark:text-emerald-400" />
                  <h3 className="text-base font-bold text-slate-800 dark:text-slate-100">
                    جدولة النسخ الاحتياطي التلقائي (Auto Backup Schedule)
                  </h3>
                </div>
                <p className="text-xs text-slate-500 mt-1">
                  تحديد تردد النسخ التلقائي للبيانات والرفع الدوري إلى Google Drive
                </p>
              </div>

              <div className="flex items-center gap-3">
                <label className="relative inline-flex items-center cursor-pointer">
                  <input
                    type="checkbox"
                    checked={autoBackupConfig.enabled}
                    onChange={(e) => updateAutoBackupConfig({ enabled: e.target.checked })}
                    className="sr-only peer"
                  />
                  <div className="w-12 h-6 bg-slate-300 dark:bg-slate-700 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full rtl:peer-checked:after:-translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:start-[3px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-emerald-600"></div>
                </label>
                <span className="font-bold text-slate-700 dark:text-slate-300 text-xs">
                  {autoBackupConfig.enabled ? 'النسخ التلقائي مفعل' : 'معطل'}
                </span>
              </div>
            </div>

            {/* Frequency Selection */}
            <div className="space-y-2 text-xs">
              <label className="block font-bold text-slate-700 dark:text-slate-300">
                تكرار النسخ التلقائي:
              </label>
              <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-6 gap-2">
                {[
                  { id: '1h' as AutoBackupFrequency, label: 'كل 1 ساعة' },
                  { id: '3h' as AutoBackupFrequency, label: 'كل 3 ساعات' },
                  { id: '6h' as AutoBackupFrequency, label: 'كل 6 ساعات' },
                  { id: '12h' as AutoBackupFrequency, label: 'كل 12 ساعة' },
                  { id: '24h' as AutoBackupFrequency, label: 'يومياً (24h)' },
                  { id: 'weekly' as AutoBackupFrequency, label: 'أسبوعياً' },
                ].map((f) => {
                  const isSelected = autoBackupConfig.frequency === f.id;
                  return (
                    <button
                      key={f.id}
                      type="button"
                      onClick={() => updateAutoBackupConfig({ frequency: f.id })}
                      className={`py-2 px-2.5 rounded-xl border text-center font-bold text-xs transition cursor-pointer ${
                        isSelected
                          ? 'bg-emerald-600 text-white border-emerald-600 shadow-xs'
                          : 'bg-slate-50 dark:bg-slate-800 border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 hover:border-emerald-300'
                      }`}
                    >
                      {f.label}
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Trigger Button & Status */}
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pt-2 text-xs">
              <span className="text-slate-500">
                آخر عملية نسخ: <strong>{autoBackupConfig.lastBackupTime || 'لم تُنفذ بعد'}</strong>
              </span>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => createBackupSnapshot('manual')}
                  className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl font-bold text-xs shadow-xs transition cursor-pointer"
                >
                  أخذ نسخة احتياطية الآن
                </button>
                <button
                  type="button"
                  onClick={() => setIsAutoBackupModalOpen(true)}
                  className="px-3 py-2 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 rounded-xl font-medium text-xs transition cursor-pointer flex items-center gap-1"
                >
                  <ExternalLink className="w-3.5 h-3.5" />
                  <span>عرض السجل الكامل</span>
                </button>
              </div>
            </div>
          </div>

          {/* SECTION 3: SQLITE EXPORT / IMPORT & RESTORE TOOLS */}
          <div className="bg-white dark:bg-slate-900 rounded-2xl p-6 border border-slate-200 dark:border-slate-800 shadow-sm space-y-6">
            <div>
              <h3 className="text-base font-bold text-slate-800 dark:text-slate-100 flex items-center gap-2">
                <Database className="w-5 h-5 text-sky-500" />
                <span>أدوات النسخ الاحتياطي وقاعدة بيانات SQLite المحلية</span>
              </h3>
              <p className="text-xs text-slate-500 mt-1">
                تصدير كامل لقاعدة البيانات في ملف SQL أو JSON لضمان حفظ بيانات الغرف والنزلاء والرواتب
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {/* Export SQL */}
              <div className="p-4 rounded-2xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/40 space-y-3">
                <div className="flex items-center gap-2 font-bold text-sm text-slate-800 dark:text-slate-200">
                  <FileCode2 className="w-5 h-5 text-sky-500" />
                  <span>تصدير سكربت SQL Dump</span>
                </div>
                <p className="text-xs text-slate-500">
                  يحتوي على جمل DDL لإنشاء الجداول وجمل INSERT لكافة الغرف والنزلاء والحجوزات.
                </p>
                <button
                  onClick={exportDatabaseSql}
                  className="w-full py-2.5 rounded-xl bg-sky-600 hover:bg-sky-500 text-white font-semibold text-xs flex items-center justify-center gap-2 shadow-sm transition cursor-pointer"
                >
                  <Download className="w-4 h-4" />
                  <span>تحميل ملف SQL Dump (.sql)</span>
                </button>
              </div>

              {/* Export JSON */}
              <div className="p-4 rounded-2xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/40 space-y-3">
                <div className="flex items-center gap-2 font-bold text-sm text-slate-800 dark:text-slate-200">
                  <Database className="w-5 h-5 text-emerald-500" />
                  <span>تصدير نسخة احتياطية JSON</span>
                </div>
                <p className="text-xs text-slate-500">
                  ملف بيانات كائن JSON متكامل للاستعادة السريعة في أي وقت.
                </p>
                <button
                  onClick={exportDatabaseJson}
                  className="w-full py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-semibold text-xs flex items-center justify-center gap-2 shadow-sm transition cursor-pointer"
                >
                  <Download className="w-4 h-4" />
                  <span>تحميل نسخة JSON (.json)</span>
                </button>
              </div>

              {/* Import Backup */}
              <div className="p-4 rounded-2xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/40 space-y-3">
                <div className="flex items-center gap-2 font-bold text-sm text-slate-800 dark:text-slate-200">
                  <Upload className="w-5 h-5 text-amber-500" />
                  <span>استيراد نسخة احتياطية</span>
                </div>
                <p className="text-xs text-slate-500">
                  استرجاع بيانات الفندق من ملف SQL أو JSON سابق.
                </p>
                <label className="w-full py-2.5 rounded-xl bg-amber-600 hover:bg-amber-500 text-white font-semibold text-xs flex items-center justify-center gap-2 shadow-sm transition cursor-pointer">
                  <Upload className="w-4 h-4" />
                  <span>اختيار ملف للاستعادة</span>
                  <input type="file" accept=".json,.sql" onChange={handleImportFile} className="hidden" />
                </label>
              </div>

              {/* Reset DB */}
              <div className="p-4 rounded-2xl border border-rose-200 dark:border-rose-900/50 bg-rose-50/50 dark:bg-rose-950/20 space-y-3">
                <div className="flex items-center gap-2 font-bold text-sm text-rose-700 dark:text-rose-400">
                  <RotateCcw className="w-5 h-5 text-rose-500" />
                  <span>إعادة تعيين البيانات الافتراضية</span>
                </div>
                <p className="text-xs text-rose-600/80 dark:text-rose-400/80">
                  إعادة ضبط قاعدة بيانات الفندق وعينات الغرف والنزلاء للحالة الأولية.
                </p>
                <button
                  onClick={() => {
                    if (window.confirm('هل أنت متأكد من إعادة تعيين قاعدة البيانات واستعادة العينات التجريبية؟')) {
                      resetToDemoData();
                    }
                  }}
                  className="w-full py-2.5 rounded-xl bg-rose-600 hover:bg-rose-500 text-white font-semibold text-xs flex items-center justify-center gap-2 shadow-sm transition cursor-pointer"
                >
                  <RotateCcw className="w-4 h-4" />
                  <span>استعادة البيانات الافتراضية</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
