import React, { useState, useMemo } from 'react';
import { useHotel } from '../context/HotelContext';
import {
  UtensilsCrossed,
  Plus,
  Search,
  Clock,
  CheckCircle2,
  AlertTriangle,
  XCircle,
  Printer,
  ChevronRight,
  TrendingUp,
  ShoppingBag,
  DollarSign,
  ChefHat,
  Coffee,
  Sparkles,
  FileText,
  CreditCard,
  Banknote,
  Gift,
  ArrowRight,
  Filter,
} from 'lucide-react';
import { RoomServiceOrderStatus, RoomServiceOrder, RoomServiceChargeTo } from '../types/hotel';

export const RoomServiceView: React.FC = () => {
  const {
    roomServiceOrders,
    roomServiceMenu,
    settings,
    setIsNewRoomServiceModalOpen,
    setIsRoomServiceMenuModalOpen,
    updateRoomServiceOrderStatus,
    printRoomServiceOrderTicket,
    setPreselectedRoomForRoomService,
    rooms,
  } = useHotel();

  const [statusFilter, setStatusFilter] = useState<RoomServiceOrderStatus | 'all'>('all');
  const [searchQuery, setSearchQuery] = useState('');

  // Metrics
  const totalOrdersCount = roomServiceOrders.length;
  const pendingCount = roomServiceOrders.filter((o) => o.status === 'pending').length;
  const preparingCount = roomServiceOrders.filter((o) => o.status === 'preparing').length;
  const onTheWayCount = roomServiceOrders.filter((o) => o.status === 'on_the_way').length;
  const deliveredCount = roomServiceOrders.filter((o) => o.status === 'delivered').length;
  const activeOrdersCount = pendingCount + preparingCount + onTheWayCount;

  const totalSales = useMemo(() => {
    return roomServiceOrders
      .filter((o) => o.status !== 'cancelled' && o.chargeTo !== 'complimentary')
      .reduce((sum, o) => sum + o.totalAmount, 0);
  }, [roomServiceOrders]);

  // Filtered Orders
  const filteredOrders = useMemo(() => {
    return roomServiceOrders.filter((order) => {
      if (statusFilter !== 'all' && order.status !== statusFilter) return false;
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        const matchRoom = order.roomNumber.toLowerCase().includes(q);
        const matchCode = order.orderCode.toLowerCase().includes(q);
        const matchGuest = order.guestName.toLowerCase().includes(q);
        if (!matchRoom && !matchCode && !matchGuest) return false;
      }
      return true;
    });
  }, [roomServiceOrders, statusFilter, searchQuery]);

  const getStatusBadge = (status: RoomServiceOrderStatus) => {
    switch (status) {
      case 'pending':
        return (
          <span className="px-2.5 py-1 rounded-full text-xs font-semibold bg-amber-500/20 text-amber-300 border border-amber-500/40 flex items-center gap-1.5 animate-pulse">
            <Clock className="w-3 h-3" />
            <span>جديد / قيد الانتظار</span>
          </span>
        );
      case 'preparing':
        return (
          <span className="px-2.5 py-1 rounded-full text-xs font-semibold bg-blue-500/20 text-blue-300 border border-blue-500/40 flex items-center gap-1.5">
            <ChefHat className="w-3 h-3 text-blue-400" />
            <span>قيد التجهيز في المطبخ</span>
          </span>
        );
      case 'on_the_way':
        return (
          <span className="px-2.5 py-1 rounded-full text-xs font-semibold bg-purple-500/20 text-purple-300 border border-purple-500/40 flex items-center gap-1.5">
            <Sparkles className="w-3 h-3 text-purple-400" />
            <span>جاري التوصيل للغرفة</span>
          </span>
        );
      case 'delivered':
        return (
          <span className="px-2.5 py-1 rounded-full text-xs font-semibold bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 flex items-center gap-1.5">
            <CheckCircle2 className="w-3 h-3 text-emerald-400" />
            <span>تم التسليم بنجاح</span>
          </span>
        );
      case 'cancelled':
        return (
          <span className="px-2.5 py-1 rounded-full text-xs font-semibold bg-slate-800 text-slate-400 border border-slate-700 flex items-center gap-1.5">
            <XCircle className="w-3 h-3" />
            <span>ملغي</span>
          </span>
        );
    }
  };

  const getChargeToBadge = (chargeTo: RoomServiceChargeTo) => {
    switch (chargeTo) {
      case 'room_bill':
        return (
          <span className="px-2 py-0.5 rounded text-[11px] font-medium bg-amber-500/10 text-amber-300 border border-amber-500/20 flex items-center gap-1">
            <FileText className="w-3 h-3" />
            <span>فاتورة الغرفة</span>
          </span>
        );
      case 'card_on_delivery':
        return (
          <span className="px-2 py-0.5 rounded text-[11px] font-medium bg-indigo-500/10 text-indigo-300 border border-indigo-500/20 flex items-center gap-1">
            <CreditCard className="w-3 h-3" />
            <span>دفع بالبطاقة</span>
          </span>
        );
      case 'cash_on_delivery':
        return (
          <span className="px-2 py-0.5 rounded text-[11px] font-medium bg-emerald-500/10 text-emerald-300 border border-emerald-500/20 flex items-center gap-1">
            <Banknote className="w-3 h-3" />
            <span>دفع نقدي (كاش)</span>
          </span>
        );
      case 'complimentary':
        return (
          <span className="px-2 py-0.5 rounded text-[11px] font-medium bg-rose-500/10 text-rose-300 border border-rose-500/20 flex items-center gap-1">
            <Gift className="w-3 h-3" />
            <span>ضيافة مجانية VIP</span>
          </span>
        );
    }
  };

  return (
    <div className="space-y-5 pb-10">
      {/* Top Banner & Stats Overview */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4">
        {/* Total Orders */}
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 flex items-center justify-between shadow-sm">
          <div>
            <span className="text-xs font-semibold text-slate-400 block mb-1">
              إجمالي الطلبات المسجلة
            </span>
            <span className="text-2xl sm:text-3xl font-extrabold text-white font-mono">
              {totalOrdersCount}
            </span>
            <span className="text-[11px] text-slate-400 block mt-1">طلب خدمة غرف</span>
          </div>
          <div className="w-12 h-12 rounded-xl bg-amber-500/10 border border-amber-500/20 flex items-center justify-center text-amber-400">
            <ShoppingBag className="w-6 h-6" />
          </div>
        </div>

        {/* Active Orders in Progress */}
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 flex items-center justify-between shadow-sm">
          <div>
            <span className="text-xs font-semibold text-slate-400 block mb-1">
              طلبات قيد التنفيذ والتحضير
            </span>
            <span className="text-2xl sm:text-3xl font-extrabold text-amber-400 font-mono">
              {activeOrdersCount}
            </span>
            <span className="text-[11px] text-amber-300/80 block mt-1">
              {pendingCount} جديد • {preparingCount} بالمطبخ
            </span>
          </div>
          <div className="w-12 h-12 rounded-xl bg-amber-500/20 border border-amber-500/30 flex items-center justify-center text-amber-400">
            <ChefHat className="w-6 h-6" />
          </div>
        </div>

        {/* Room Service Revenue */}
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 flex items-center justify-between shadow-sm">
          <div>
            <span className="text-xs font-semibold text-slate-400 block mb-1">
              إجمالي إيرادات خدمة الغرف
            </span>
            <span className="text-2xl sm:text-3xl font-extrabold text-emerald-400 font-mono">
              {totalSales.toLocaleString()}
            </span>
            <span className="text-[11px] text-slate-400 block mt-1 font-mono">
              {settings.currency} شامل الضريبة
            </span>
          </div>
          <div className="w-12 h-12 rounded-xl bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center text-emerald-400">
            <DollarSign className="w-6 h-6" />
          </div>
        </div>

        {/* Menu Catalog Items */}
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 flex items-center justify-between shadow-sm">
          <div>
            <span className="text-xs font-semibold text-slate-400 block mb-1">
              أصناف القائمة المتاحة
            </span>
            <span className="text-2xl sm:text-3xl font-extrabold text-indigo-400 font-mono">
              {roomServiceMenu.filter((m) => m.isAvailable).length}
            </span>
            <span className="text-[11px] text-slate-400 block mt-1">
              من أصل {roomServiceMenu.length} صنف وخدمة
            </span>
          </div>
          <div className="w-12 h-12 rounded-xl bg-indigo-500/10 border border-indigo-500/20 flex items-center justify-center text-indigo-400">
            <UtensilsCrossed className="w-6 h-6" />
          </div>
        </div>
      </div>

      {/* Action Bar & Controls */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 flex flex-col md:flex-row items-stretch md:items-center justify-between gap-4">
        {/* Left: Buttons */}
        <div className="flex items-center gap-2.5 flex-wrap">
          <button
            onClick={() => {
              setPreselectedRoomForRoomService(null);
              setIsNewRoomServiceModalOpen(true);
            }}
            className="bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs sm:text-sm px-4 py-2.5 rounded-xl transition cursor-pointer shadow-lg shadow-amber-500/20 flex items-center gap-2"
          >
            <Plus className="w-4 h-4" />
            <span>طلب خدمة غرف جديد</span>
          </button>

          <button
            onClick={() => setIsRoomServiceMenuModalOpen(true)}
            className="bg-slate-800 hover:bg-slate-700 text-white font-medium text-xs sm:text-sm px-3.5 py-2.5 rounded-xl border border-slate-700 transition cursor-pointer flex items-center gap-2"
          >
            <UtensilsCrossed className="w-4 h-4 text-amber-400" />
            <span>إدارة قائمة الأصناف والأسعار</span>
          </button>
        </div>

        {/* Right: Search & Status Filters */}
        <div className="flex items-center gap-2 flex-1 md:max-w-md">
          <div className="relative flex-1">
            <Search className="w-4 h-4 text-slate-400 absolute right-3 top-3" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="بحث برقم الغرفة، كود الطلب، اسم النزيل..."
              className="w-full bg-slate-950 border border-slate-800 rounded-xl pr-9 pl-3 py-2 text-xs sm:text-sm text-slate-200 placeholder-slate-500 focus:outline-none focus:border-amber-500"
            />
          </div>
        </div>
      </div>

      {/* Filter Tabs */}
      <div className="flex items-center gap-2 overflow-x-auto no-scrollbar pb-1">
        {[
          { id: 'all', label: 'جميع الطلبات', count: totalOrdersCount },
          { id: 'pending', label: 'قيد الانتظار', count: pendingCount },
          { id: 'preparing', label: 'قيد التجهيز بالمطبخ', count: preparingCount },
          { id: 'on_the_way', label: 'جاري التوصيل', count: onTheWayCount },
          { id: 'delivered', label: 'تم التسليم', count: deliveredCount },
          {
            id: 'cancelled',
            label: 'ملغي',
            count: roomServiceOrders.filter((o) => o.status === 'cancelled').length,
          },
        ].map((tab) => {
          const isSelected = statusFilter === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setStatusFilter(tab.id as any)}
              className={`px-3.5 py-2 rounded-xl text-xs sm:text-sm font-semibold transition cursor-pointer flex items-center gap-2 whitespace-nowrap ${
                isSelected
                  ? 'bg-amber-500 text-slate-950 shadow-md'
                  : 'bg-slate-900 hover:bg-slate-800 text-slate-400 hover:text-slate-200 border border-slate-800'
              }`}
            >
              <span>{tab.label}</span>
              <span
                className={`px-1.5 py-0.2 rounded-full text-[10px] font-mono ${
                  isSelected ? 'bg-slate-950 text-amber-400' : 'bg-slate-800 text-slate-300'
                }`}
              >
                {tab.count}
              </span>
            </button>
          );
        })}
      </div>

      {/* Orders List / Kanban Cards */}
      {filteredOrders.length === 0 ? (
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-12 text-center text-slate-400 space-y-3">
          <UtensilsCrossed className="w-12 h-12 mx-auto text-slate-600 opacity-60" />
          <h3 className="text-base font-bold text-slate-300">لا توجد طلبات خدمة غرف في هذه الفئة</h3>
          <p className="text-xs text-slate-500 max-w-md mx-auto">
            يمكنك تسجيل طلب خدمة غرف جديد وتحديده للغرفة المطلوبة، أو مراجعة الفلاتر الأخرى.
          </p>
          <button
            onClick={() => {
              setPreselectedRoomForRoomService(null);
              setIsNewRoomServiceModalOpen(true);
            }}
            className="inline-flex items-center gap-2 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs px-4 py-2 rounded-xl transition cursor-pointer mt-2"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>تسجيل أول طلب الآن</span>
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
          {filteredOrders.map((order) => {
            return (
              <div
                key={order.id}
                className={`bg-slate-900 border rounded-2xl p-4.5 flex flex-col justify-between transition shadow-md ${
                  order.status === 'pending'
                    ? 'border-amber-500/60 ring-1 ring-amber-500/20 bg-gradient-to-b from-slate-900 to-amber-950/10'
                    : order.status === 'preparing'
                    ? 'border-blue-500/40 bg-gradient-to-b from-slate-900 to-blue-950/10'
                    : order.status === 'on_the_way'
                    ? 'border-purple-500/40 bg-gradient-to-b from-slate-900 to-purple-950/10'
                    : 'border-slate-800'
                }`}
              >
                {/* Card Top */}
                <div>
                  <div className="flex items-start justify-between gap-2 pb-3 mb-3 border-b border-slate-800">
                    <div className="flex items-center gap-2.5">
                      <div className="w-11 h-11 rounded-xl bg-slate-800 border border-slate-700 flex flex-col items-center justify-center text-white">
                        <span className="text-[10px] text-slate-400 leading-none">غرفة</span>
                        <strong className="text-sm font-extrabold text-amber-400 font-mono">
                          {order.roomNumber}
                        </strong>
                      </div>
                      <div>
                        <div className="flex items-center gap-2">
                          <h4 className="text-sm font-bold text-white">{order.guestName}</h4>
                        </div>
                        <div className="flex items-center gap-2 text-[11px] text-slate-400 mt-0.5">
                          <span className="font-mono">{order.orderCode}</span>
                          <span>•</span>
                          <span>{order.createdAt}</span>
                        </div>
                      </div>
                    </div>

                    <div>{getStatusBadge(order.status)}</div>
                  </div>

                  {/* Items list */}
                  <div className="bg-slate-950/60 rounded-xl p-3 border border-slate-800/80 mb-3 space-y-1.5">
                    <span className="text-[11px] font-semibold text-slate-400 block mb-1">
                      الأصناف المطلوبة ({order.items.length}):
                    </span>
                    {order.items.map((item, idx) => (
                      <div key={idx} className="flex items-center justify-between text-xs gap-2">
                        <div className="flex items-center gap-1.5 overflow-hidden">
                          <span className="w-5 h-5 rounded bg-slate-800 text-amber-400 font-bold font-mono text-[11px] flex items-center justify-center shrink-0">
                            {item.quantity}x
                          </span>
                          <span className="text-slate-200 truncate">{item.name}</span>
                          {item.notes && (
                            <span className="text-[10px] text-amber-300/80 bg-amber-500/10 px-1.5 py-0.2 rounded shrink-0">
                              {item.notes}
                            </span>
                          )}
                        </div>
                        <span className="font-mono text-slate-300 font-medium shrink-0">
                          {(item.price * item.quantity).toFixed(2)}
                        </span>
                      </div>
                    ))}
                  </div>

                  {/* General Delivery Notes if any */}
                  {order.notes && (
                    <div className="bg-amber-500/5 border border-amber-500/20 rounded-lg p-2 mb-3 text-[11px] text-amber-200">
                      <strong>ملاحظة التوصيل:</strong> {order.notes}
                    </div>
                  )}

                  {/* Billing Method & Price Summary */}
                  <div className="flex items-center justify-between pt-1 mb-3 text-xs">
                    <div className="flex items-center gap-2">
                      {getChargeToBadge(order.chargeTo)}
                    </div>
                    <div className="text-left font-mono">
                      <span className="text-[10px] text-slate-400 block">الإجمالي</span>
                      <strong className="text-sm text-emerald-400 font-bold">
                        {order.totalAmount.toFixed(2)} {settings.currency}
                      </strong>
                    </div>
                  </div>
                </div>

                {/* Card Actions & Quick Status Transition */}
                <div className="pt-3 border-t border-slate-800/80 space-y-2">
                  <div className="flex items-center gap-2">
                    {/* Status Forward Stepper Buttons */}
                    {order.status === 'pending' && (
                      <button
                        onClick={() => updateRoomServiceOrderStatus(order.id, 'preparing')}
                        className="flex-1 py-2 px-3 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs transition cursor-pointer flex items-center justify-center gap-1.5 shadow-sm"
                      >
                        <ChefHat className="w-3.5 h-3.5" />
                        <span>بدء التحضير بالمطبخ</span>
                      </button>
                    )}

                    {order.status === 'preparing' && (
                      <button
                        onClick={() => updateRoomServiceOrderStatus(order.id, 'on_the_way')}
                        className="flex-1 py-2 px-3 rounded-xl bg-purple-600 hover:bg-purple-500 text-white font-bold text-xs transition cursor-pointer flex items-center justify-center gap-1.5 shadow-sm"
                      >
                        <Sparkles className="w-3.5 h-3.5" />
                        <span>خروج للتوصيل للغرفة</span>
                      </button>
                    )}

                    {order.status === 'on_the_way' && (
                      <button
                        onClick={() => updateRoomServiceOrderStatus(order.id, 'delivered')}
                        className="flex-1 py-2 px-3 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs transition cursor-pointer flex items-center justify-center gap-1.5 shadow-sm"
                      >
                        <CheckCircle2 className="w-3.5 h-3.5" />
                        <span>تأكيد التسليم للغرفة</span>
                      </button>
                    )}

                    {order.status === 'delivered' && (
                      <div className="flex-1 py-1.5 px-3 rounded-xl bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 text-xs font-semibold flex items-center justify-center gap-1">
                        <CheckCircle2 className="w-3.5 h-3.5" />
                        <span>تم التسليم في {order.completedAt || order.createdAt}</span>
                      </div>
                    )}

                    {/* Print KOT Button */}
                    <button
                      onClick={() => printRoomServiceOrderTicket(order)}
                      title="طباعة إيصال المطبخ والتوصيل (KOT)"
                      className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700 transition cursor-pointer shrink-0"
                    >
                      <Printer className="w-4 h-4 text-cyan-400" />
                    </button>

                    {/* Cancel button if not delivered */}
                    {order.status !== 'delivered' && order.status !== 'cancelled' && (
                      <button
                        onClick={() => {
                          if (confirm(`هل أنت متأكد من إلغاء الطلب (${order.orderCode})؟`)) {
                            updateRoomServiceOrderStatus(order.id, 'cancelled');
                          }
                        }}
                        title="إلغاء الطلب"
                        className="p-2 rounded-xl bg-slate-800 hover:bg-rose-500/20 text-slate-400 hover:text-rose-400 border border-slate-700 transition cursor-pointer shrink-0"
                      >
                        <XCircle className="w-4 h-4" />
                      </button>
                    )}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};
