import React, { useRef, useState } from 'react';
import { Lock, CalendarSearch, Users, Wallet } from 'lucide-react';
import { ClosingPanel } from './archive/ClosingPanel';
import { DayArchivePanel } from './archive/DayArchivePanel';
import { GuestsByDatePanel } from './archive/GuestsByDatePanel';
import { DailyOpsPanel } from './archive/DailyOpsPanel';
import { Card } from './archive/shared';
import { getAllDays, putDay } from '../utils/archiveStore';
import { saveText } from '../utils/saveFile';
import { localDate } from '../utils/dates';
import type { DaySnapshot } from '../types/archive';

type Tab = 'closing' | 'day' | 'guests' | 'daily';
const TABS: { id: Tab; label: string; Icon: typeof Lock }[] = [
  { id: 'closing', label: 'الإقفالات', Icon: Lock },
  { id: 'daily', label: 'مصروف ورواتب', Icon: Wallet },
  { id: 'day', label: 'أرشيف النظام', Icon: CalendarSearch },
  { id: 'guests', label: 'سجل النزلاء', Icon: Users },
];

/** Daily archive (system + guest register), date search, and daily/weekly/monthly/yearly closings. */
export const ArchiveView: React.FC = () => {
  const [tab, setTab] = useState<Tab>('closing');
  const fileRef = useRef<HTMLInputElement>(null);
  const [msg, setMsg] = useState('');

  const exportAll = async () => {
    const days = await getAllDays();
    if (days.length === 0) return setMsg('لا توجد أيام محفوظة بعد.');
    await saveText(`qasr_archive_${localDate()}.json`, JSON.stringify({ app: 'qasr-archive', version: 1, days }), 'application/json;charset=utf-8');
    setMsg(`تم تصدير ${days.length} يوماً.`);
  };

  const importAll = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    e.target.value = '';
    if (!file) return;
    try {
      const raw = JSON.parse(await file.text());
      const days: DaySnapshot[] = Array.isArray(raw) ? raw : raw?.days;
      if (!Array.isArray(days)) throw new Error('bad');
      let n = 0;
      for (const d of days) {
        if (d && typeof d.date === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(d.date)) {
          await putDay(d);
          n++;
        }
      }
      setMsg(`تم استيراد ${n} يوماً. أعد فتح التبويب لرؤيتها.`);
    } catch {
      setMsg('ملف الأرشيف غير صالح.');
    }
  };

  return (
    <div className="space-y-4 animate-fadeIn pb-8" dir="rtl">
      <div>
        <h2 className="font-bold text-lg text-slate-900 dark:text-white">الأرشيف والإقفالات</h2>
        <p className="text-xs text-slate-500 dark:text-slate-400">يُحفظ النظام وسجل النزلاء تلقائياً كل يوم، ويمكنك مراجعة أي يوم وإقفال الفترات المالية.</p>
      </div>

      <div className="grid grid-cols-4 gap-1.5 bg-slate-100 dark:bg-slate-800 p-1 rounded-2xl sticky top-[64px] z-10">
        {TABS.map(({ id, label, Icon }) => (
          <button
            key={id}
            onClick={() => setTab(id)}
            className={`flex flex-col items-center gap-0.5 py-2 rounded-xl text-[11px] sm:text-xs font-bold cursor-pointer transition ${tab === id ? 'bg-white dark:bg-slate-900 text-sky-700 dark:text-sky-300 shadow-sm' : 'text-slate-500'}`}
          >
            <Icon className="w-4 h-4" />
            {label}
          </button>
        ))}
      </div>

      {tab === 'closing' && <ClosingPanel />}
      {tab === 'daily' && <DailyOpsPanel />}
      {tab === 'day' && <DayArchivePanel />}
      {tab === 'guests' && <GuestsByDatePanel />}

      <Card title="نسخ الأرشيف اليومي">
        <p className="text-[11px] text-slate-500 dark:text-slate-400">
          الأرشيف اليومي محفوظ على هذا الجهاز. صدّره بشكل دوري إلى ملف لحفظه خارج الجهاز (Drive أو البريد)، واستورده عند تغيير الجهاز.
        </p>
        <div className="flex flex-wrap gap-2">
          <button onClick={exportAll} className="px-4 py-2 rounded-xl bg-sky-600 text-white text-xs font-bold cursor-pointer">تصدير كل الأيام</button>
          <button onClick={() => fileRef.current?.click()} className="px-4 py-2 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-200 text-xs font-bold cursor-pointer">استيراد أرشيف</button>
          <input ref={fileRef} type="file" accept="application/json,.json" className="hidden" onChange={importAll} />
        </div>
        {msg && <div className="text-xs font-semibold text-sky-700 dark:text-sky-300">{msg}</div>}
      </Card>
    </div>
  );
};
