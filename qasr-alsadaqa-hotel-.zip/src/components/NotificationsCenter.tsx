import React from 'react';
import { useHotel } from '../context/HotelContext';
import {
  Bell,
  X,
  AlertTriangle,
  Clock,
  Sparkles,
  CheckCircle2,
  Building,
  Volume2,
  VolumeX,
} from 'lucide-react';

export const NotificationsCenter: React.FC = () => {
  const {
    notifications,
    isNotificationsOpen,
    setIsNotificationsOpen,
    markNotificationRead,
    clearAllNotifications,
    setSelectedRoom,
    rooms,
    settings,
    updateSettings,
    playAlertSound,
  } = useHotel();

  if (!isNotificationsOpen) return null;

  const handleActionClick = (roomId?: number) => {
    if (roomId) {
      const target = rooms.find((r) => r.id === roomId);
      if (target) {
        setSelectedRoom(target);
      }
    }
    setIsNotificationsOpen(false);
  };

  const getSeverityStyle = (sev: string) => {
    switch (sev) {
      case 'danger':
        return 'bg-rose-50 dark:bg-rose-950/40 border-rose-200 dark:border-rose-900 text-rose-800 dark:text-rose-300';
      case 'warning':
        return 'bg-amber-50 dark:bg-amber-950/40 border-amber-200 dark:border-amber-900 text-amber-800 dark:text-amber-300';
      case 'success':
        return 'bg-emerald-50 dark:bg-emerald-950/40 border-emerald-200 dark:border-emerald-900 text-emerald-800 dark:text-emerald-300';
      default:
        return 'bg-blue-50 dark:bg-blue-950/40 border-blue-200 dark:border-blue-900 text-blue-800 dark:text-blue-300';
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-end bg-slate-950/60 backdrop-blur-xs animate-fadeIn">
      <div className="bg-white dark:bg-slate-900 border-l border-slate-200 dark:border-slate-800 w-full max-w-md h-full shadow-2xl flex flex-col justify-between">
        {/* Top Header */}
        <div className="p-4 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between bg-slate-50 dark:bg-slate-950">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-emerald-600 text-white flex items-center justify-center">
              <Bell className="w-4 h-4" />
            </div>
            <div>
              <h3 className="font-bold text-slate-900 dark:text-white text-sm">
                مركز الإشعارات والتنبيهات الذكية
              </h3>
              <p className="text-[11px] text-slate-400">تنبيهات الغرف المحجوزة، المغادرات والهاوس كيبينج</p>
            </div>
          </div>

          <div className="flex items-center gap-1">
            <button
              onClick={() => {
                updateSettings({ enableAudioAlerts: !settings.enableAudioAlerts });
                playAlertSound('ding');
              }}
              title={settings.enableAudioAlerts ? 'تعطيل التنبيهات الصوتية' : 'تفعيل التنبيهات الصوتية'}
              className="p-1.5 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800"
            >
              {settings.enableAudioAlerts ? (
                <Volume2 className="w-4 h-4 text-emerald-500" />
              ) : (
                <VolumeX className="w-4 h-4 text-slate-400" />
              )}
            </button>

            <button
              onClick={() => setIsNotificationsOpen(false)}
              className="p-1.5 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Notifications List */}
        <div className="p-4 flex-1 overflow-y-auto space-y-3 text-xs">
          {notifications.length === 0 ? (
            <div className="p-8 text-center text-slate-400 space-y-2">
              <CheckCircle2 className="w-8 h-8 text-emerald-500 mx-auto" />
              <p className="font-medium text-sm">لا توجد تنبيهات عاجلة حالياً!</p>
              <p className="text-xs">كافة الغرف والحجوزات منتظمة ولا توجد متأخرات.</p>
            </div>
          ) : (
            notifications.map((n) => (
              <div
                key={n.id}
                onClick={() => markNotificationRead(n.id)}
                className={`p-3.5 rounded-xl border transition space-y-2 cursor-pointer ${getSeverityStyle(
                  n.severity
                )} ${!n.isRead ? 'ring-1 ring-emerald-500/40 shadow-xs' : 'opacity-90'}`}
              >
                <div className="flex items-start justify-between gap-2">
                  <div className="flex items-center gap-1.5 font-bold">
                    <AlertTriangle className="w-3.5 h-3.5 shrink-0" />
                    <span>{n.title}</span>
                  </div>
                  <span className="text-[10px] text-slate-400 shrink-0">{n.timestamp}</span>
                </div>

                <p className="text-[11px] leading-relaxed opacity-95">{n.message}</p>

                {n.roomId && (
                  <div className="pt-1 flex justify-end">
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        handleActionClick(n.roomId);
                      }}
                      className="px-2.5 py-1 bg-white/80 dark:bg-slate-900/80 hover:bg-white dark:hover:bg-slate-900 rounded-md font-bold text-[11px] border border-current shadow-2xs"
                    >
                      فتح الغرفة {n.roomNumber} &larr;
                    </button>
                  </div>
                )}
              </div>
            ))
          )}
        </div>

        {/* Footer */}
        <div className="p-3 border-t border-slate-100 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 flex items-center justify-between text-xs">
          <button
            onClick={clearAllNotifications}
            className="text-slate-500 hover:text-slate-700 dark:hover:text-slate-300 font-medium"
          >
            تحديد الكل كمقروء
          </button>
          <button
            onClick={() => setIsNotificationsOpen(false)}
            className="px-3 py-1.5 bg-slate-800 text-white rounded-lg font-semibold"
          >
            إغلاق
          </button>
        </div>
      </div>
    </div>
  );
};
