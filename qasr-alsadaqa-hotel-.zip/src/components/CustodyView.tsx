import React, { useEffect, useMemo, useRef, useState } from 'react';
import { Package, Plus, Camera, X, FileDown, MessageSquare, Undo2, Trash2, Search } from 'lucide-react';
import { useHotel } from '../context/HotelContext';
import { Card, inputCls } from './archive/shared';
import { CUSTODY_KIND_AR, type CustodyItem, type CustodyKind } from '../types/custody';
import { compressImage, getImage } from '../utils/imageStore';
import { exportArabicPdf, money } from '../utils/arabicPdf';
import { SMS_TEMPLATES, fillTemplate, openSms } from '../utils/sms';

const Thumb: React.FC<{ id: string; onOpen: (src: string) => void }> = ({ id, onOpen }) => {
  const [src, setSrc] = useState<string | null>(null);
  useEffect(() => {
    let live = true;
    getImage(id).then((v) => live && setSrc(v));
    return () => {
      live = false;
    };
  }, [id]);
  if (!src) return <div className="w-16 h-16 rounded-lg bg-slate-100 dark:bg-slate-800" />;
  return <img src={src} alt="" onClick={() => onOpen(src)} className="w-16 h-16 rounded-lg object-cover cursor-pointer border border-slate-200 dark:border-slate-700" />;
};

/** الأمانات: deposits, pledges and forgotten belongings, with photos, a note, an Arabic receipt and an SMS notice. */
export const CustodyView: React.FC = () => {
  const { custody, addCustodyItem, returnCustodyItem, deleteCustodyItem, guests, bookings, settings, logSms, openSmsComposer } = useHotel();
  const sym = settings.currencySymbol;

  const [open, setOpen] = useState(false);
  const [filter, setFilter] = useState<'held' | 'returned' | 'all'>('held');
  const [q, setQ] = useState('');
  const [view, setView] = useState<string | null>(null);

  // form
  const [kind, setKind] = useState<CustodyKind>('deposit');
  const [guestId, setGuestId] = useState<number | ''>('');
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [room, setRoom] = useState('');
  const [title, setTitle] = useState('');
  const [desc, setDesc] = useState('');
  const [value, setValue] = useState<number | ''>('');
  const [notes, setNotes] = useState('');
  const [photos, setPhotos] = useState<string[]>([]);
  const [busy, setBusy] = useState(false);
  const fileRef = useRef<HTMLInputElement>(null);

  const pickGuest = (id: number | '') => {
    setGuestId(id);
    const g = guests.find((x) => x.id === id);
    if (g) {
      setName(g.name);
      setPhone(g.phone);
      const b = bookings.find((x) => x.guestId === g.id && x.isActive);
      setRoom(b ? b.roomNumber : '');
    }
  };

  const addPhotos = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files || []);
    e.target.value = '';
    for (const f of files.slice(0, 6 - photos.length)) {
      try {
        setPhotos((p) => [...p]); // keep UI responsive
        const url = await compressImage(f, 900, 0.7);
        setPhotos((p) => (p.length < 6 ? [...p, url] : p));
      } catch {
        alert('تعذّر قراءة إحدى الصور.');
      }
    }
  };

  const reset = () => {
    setKind('deposit'); setGuestId(''); setName(''); setPhone(''); setRoom(''); setTitle(''); setDesc('');
    setValue(''); setNotes(''); setPhotos([]);
  };

  const notify = (item: CustodyItem, templateId: 'custody' | 'custody_return' | 'lost_found') => {
    if (!item.guestPhone.trim()) return alert('لا يوجد رقم جوال لهذا العميل.');
    const vars = { الاسم: item.guestName, الفندق: settings.hotelName, الأمانة: item.title, الإيصال: item.code };
    if (item.guestId) {
      openSmsComposer({ guestId: item.guestId, templateId, vars });
      return;
    }
    const tpl = SMS_TEMPLATES.find((t) => t.id === templateId)!;
    const body = fillTemplate(tpl.text, vars);
    logSms({ name: item.guestName, phone: item.guestPhone, text: body, kind: templateId });
    openSms(item.guestPhone, body);
  };

  const save = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !title.trim()) return alert('اسم العميل ووصف الأمانة مطلوبان.');
    setBusy(true);
    try {
      const item = await addCustodyItem(
        {
          kind,
          title: title.trim(),
          description: desc.trim() || undefined,
          estimatedValue: value === '' ? undefined : Number(value),
          guestId: guestId === '' ? undefined : guestId,
          guestName: name.trim(),
          guestPhone: phone.trim(),
          roomNumber: room.trim() || undefined,
          notes: notes.trim() || undefined,
        },
        photos
      );
      reset();
      setOpen(false);
      if (item.guestPhone && confirm('تم حفظ الأمانة. هل تريد إشعار العميل برسالة SMS؟')) {
        notify(item, kind === 'lost_found' ? 'lost_found' : 'custody');
      }
    } finally {
      setBusy(false);
    }
  };

  const receipt = (c: CustodyItem) =>
    exportArabicPdf(
      {
        hotelName: settings.hotelName,
        hotelAddress: settings.address,
        title: c.status === 'returned' ? 'سند تسليم أمانة' : 'سند استلام أمانة',
        metaRight: [
          ['رقم السند', c.code],
          ['العميل', c.guestName],
          ['الجوال', c.guestPhone || '—'],
          ['الغرفة', c.roomNumber || '—'],
        ],
        metaLeft: [
          ['النوع', CUSTODY_KIND_AR[c.kind]],
          ['تاريخ الاستلام', c.receivedAt],
          ['المستلِم', c.receivedBy],
          ...(c.returnedAt ? ([['تاريخ التسليم', c.returnedAt], ['سُلّمت إلى', c.returnedTo || '—']] as [string, string][]) : []),
        ],
        columns: [
          { header: 'الأمانة', width: 4 },
          { header: 'الوصف / ملاحظات', width: 5 },
          { header: 'القيمة التقديرية', width: 2.4, align: 'center' },
        ],
        rows: [[c.title, [c.description, c.notes].filter(Boolean).join(' — ') || '—', c.estimatedValue ? money(c.estimatedValue, sym) : '—']],
        signatures: ['توقيع المستلِم (الفندق)', 'توقيع العميل'],
        note: 'يلتزم الفندق بحفظ الأمانة وتسليمها لصاحبها أو لمن يفوّضه كتابياً.',
      },
      `سند-أمانة-${c.code}`
    );

  const list = useMemo(
    () =>
      custody
        .filter((c) => (filter === 'all' ? true : c.status === filter))
        .filter((c) => (q.trim() ? [c.guestName, c.title, c.code, c.guestPhone].some((v) => (v || '').includes(q.trim())) : true)),
    [custody, filter, q]
  );

  return (
    <div className="space-y-4 animate-fadeIn pb-8" dir="rtl">
      <div className="flex items-start justify-between gap-3">
        <div>
          <h2 className="font-bold text-lg text-slate-900 dark:text-white flex items-center gap-2">
            <Package className="w-5 h-5 text-sky-500" /> الأمانات
          </h2>
          <p className="text-xs text-slate-500 dark:text-slate-400">إيداع، رهن، أو أغراض منسية — بالصور وملاحظة وسند عربي وإشعار SMS.</p>
        </div>
        <button onClick={() => setOpen((v) => !v)} className="shrink-0 flex items-center gap-1.5 px-3 py-2 rounded-xl bg-sky-600 text-white text-xs font-bold cursor-pointer">
          <Plus className="w-4 h-4" /> أمانة جديدة
        </button>
      </div>

      {open && (
        <Card title="استلام أمانة">
          <form onSubmit={save} className="space-y-2.5">
            <div className="grid grid-cols-3 gap-1.5">
              {(Object.keys(CUSTODY_KIND_AR) as CustodyKind[]).map((k) => (
                <button
                  type="button"
                  key={k}
                  onClick={() => setKind(k)}
                  className={`py-2 rounded-xl text-[11px] font-bold cursor-pointer ${kind === k ? 'bg-sky-600 text-white' : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300'}`}
                >
                  {CUSTODY_KIND_AR[k]}
                </button>
              ))}
            </div>
            <select className={inputCls} value={guestId} onChange={(e) => pickGuest(e.target.value ? Number(e.target.value) : '')}>
              <option value="">— عميل مسجّل (اختياري) —</option>
              {guests.map((g) => (
                <option key={g.id} value={g.id}>{g.name} — {g.phone}</option>
              ))}
            </select>
            <div className="grid grid-cols-2 gap-2">
              <input className={inputCls} placeholder="اسم العميل" value={name} onChange={(e) => setName(e.target.value)} />
              <input className={inputCls} inputMode="tel" placeholder="الجوال" value={phone} onChange={(e) => setPhone(e.target.value)} />
            </div>
            <div className="grid grid-cols-2 gap-2">
              <input className={inputCls} placeholder="رقم الغرفة (اختياري)" value={room} onChange={(e) => setRoom(e.target.value)} />
              <input className={inputCls} type="number" min={0} placeholder={`القيمة التقديرية (${sym})`} value={value} onChange={(e) => setValue(e.target.value === '' ? '' : Number(e.target.value))} />
            </div>
            <input className={inputCls} placeholder="الأمانة (مثال: ساعة يد، مبلغ نقدي، جواز سفر)" value={title} onChange={(e) => setTitle(e.target.value)} />
            <textarea className={`${inputCls} min-h-[70px]`} placeholder="وصف الأمانة (اللون، الماركة، الحالة…)" value={desc} onChange={(e) => setDesc(e.target.value)} />
            <textarea className={`${inputCls} min-h-[60px]`} placeholder="ملاحظة" value={notes} onChange={(e) => setNotes(e.target.value)} />

            <div className="space-y-1.5">
              <div className="flex flex-wrap gap-2">
                {photos.map((p, i) => (
                  <div key={i} className="relative">
                    <img src={p} alt="" className="w-16 h-16 rounded-lg object-cover border border-slate-200 dark:border-slate-700" />
                    <button type="button" onClick={() => setPhotos((x) => x.filter((_, j) => j !== i))} className="absolute -top-1.5 -left-1.5 bg-rose-600 text-white rounded-full p-0.5 cursor-pointer" aria-label="حذف">
                      <X className="w-3 h-3" />
                    </button>
                  </div>
                ))}
                {photos.length < 6 && (
                  <button type="button" onClick={() => fileRef.current?.click()} className="w-16 h-16 rounded-lg border-2 border-dashed border-slate-300 dark:border-slate-600 flex flex-col items-center justify-center text-slate-400 text-[10px] cursor-pointer">
                    <Camera className="w-5 h-5" /> صورة
                  </button>
                )}
              </div>
              <input ref={fileRef} type="file" accept="image/*" multiple className="hidden" onChange={addPhotos} />
              <p className="text-[10px] text-slate-400">حتى 6 صور (تصوير مباشر أو من المعرض).</p>
            </div>

            <div className="flex gap-2">
              <button disabled={busy} className="flex-1 py-3 rounded-xl bg-emerald-600 text-white font-bold text-sm cursor-pointer disabled:opacity-50">
                {busy ? 'جارٍ الحفظ…' : 'حفظ واستلام الأمانة'}
              </button>
              <button type="button" onClick={() => { reset(); setOpen(false); }} className="px-4 py-3 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 text-sm font-semibold cursor-pointer">إلغاء</button>
            </div>
          </form>
        </Card>
      )}

      <div className="flex gap-2">
        <div className="relative flex-1">
          <Search className="w-4 h-4 text-slate-400 absolute right-3 top-3" />
          <input className={`${inputCls} pr-9`} placeholder="بحث بالاسم أو الرقم أو الأمانة" value={q} onChange={(e) => setQ(e.target.value)} />
        </div>
      </div>
      <div className="grid grid-cols-3 gap-1.5 bg-slate-100 dark:bg-slate-800 p-1 rounded-2xl">
        {([['held', `محفوظة (${custody.filter((c) => c.status === 'held').length})`], ['returned', 'مُسلَّمة'], ['all', 'الكل']] as const).map(([id, label]) => (
          <button key={id} onClick={() => setFilter(id)} className={`py-2 rounded-xl text-xs font-bold cursor-pointer ${filter === id ? 'bg-white dark:bg-slate-900 text-sky-700 dark:text-sky-300 shadow-sm' : 'text-slate-500'}`}>
            {label}
          </button>
        ))}
      </div>

      {list.length === 0 && <p className="text-center text-sm text-slate-400 py-10">لا توجد أمانات.</p>}

      <div className="space-y-3">
        {list.map((c) => (
          <Card key={c.id}>
            <div className="flex items-start justify-between gap-2">
              <div className="min-w-0">
                <div className="font-bold text-sm text-slate-900 dark:text-white truncate">{c.title}</div>
                <div className="text-[11px] text-slate-500 truncate">
                  {c.code} • {CUSTODY_KIND_AR[c.kind]} • {c.guestName}
                  {c.roomNumber ? ` • غرفة ${c.roomNumber}` : ''}
                </div>
              </div>
              <span className={`shrink-0 px-2 py-0.5 rounded-full text-[10px] font-bold ${c.status === 'held' ? 'bg-amber-100 text-amber-800' : 'bg-emerald-100 text-emerald-700'}`}>
                {c.status === 'held' ? 'محفوظة' : 'مُسلَّمة'}
              </span>
            </div>
            {(c.description || c.notes) && <p className="text-xs text-slate-600 dark:text-slate-300">{[c.description, c.notes].filter(Boolean).join(' — ')}</p>}
            <div className="text-[11px] text-slate-400">
              استُلمت {c.receivedAt} بواسطة {c.receivedBy}
              {c.estimatedValue ? ` • القيمة ${money(c.estimatedValue, sym)}` : ''}
              {c.returnedAt ? ` • سُلّمت ${c.returnedAt} إلى ${c.returnedTo}` : ''}
            </div>
            {c.photoIds.length > 0 && (
              <div className="flex flex-wrap gap-2">
                {c.photoIds.map((id) => <Thumb key={id} id={id} onOpen={setView} />)}
              </div>
            )}
            <div className="flex flex-wrap gap-1.5 pt-1">
              <button onClick={() => receipt(c)} className="flex items-center gap-1 px-2.5 py-1.5 rounded-lg bg-rose-50 dark:bg-rose-950/40 text-rose-700 text-[11px] font-semibold cursor-pointer">
                <FileDown className="w-3.5 h-3.5" /> سند PDF
              </button>
              <button onClick={() => notify(c, c.status === 'returned' ? 'custody_return' : c.kind === 'lost_found' ? 'lost_found' : 'custody')} className="flex items-center gap-1 px-2.5 py-1.5 rounded-lg bg-sky-50 dark:bg-sky-950/40 text-sky-700 dark:text-sky-300 text-[11px] font-semibold cursor-pointer">
                <MessageSquare className="w-3.5 h-3.5" /> إشعار SMS
              </button>
              {c.status === 'held' && (
                <button
                  onClick={() => {
                    const who = prompt('تسليم الأمانة إلى (اسم المستلم):', c.guestName);
                    if (who === null) return;
                    returnCustodyItem(c.id, who.trim() || c.guestName);
                    if (c.guestPhone && confirm('هل تريد إرسال رسالة SMS بتأكيد التسليم؟')) notify({ ...c, status: 'returned' }, 'custody_return');
                  }}
                  className="flex items-center gap-1 px-2.5 py-1.5 rounded-lg bg-emerald-50 dark:bg-emerald-950/40 text-emerald-700 text-[11px] font-semibold cursor-pointer"
                >
                  <Undo2 className="w-3.5 h-3.5" /> تسليم
                </button>
              )}
              <button onClick={() => confirm(`حذف الأمانة ${c.code} نهائياً مع صورها؟`) && deleteCustodyItem(c.id)} className="flex items-center gap-1 px-2.5 py-1.5 rounded-lg text-slate-400 text-[11px] cursor-pointer mr-auto">
                <Trash2 className="w-3.5 h-3.5" />
              </button>
            </div>
          </Card>
        ))}
      </div>

      {view && (
        <div className="fixed inset-0 z-[60] bg-black/90 flex items-center justify-center p-4" onClick={() => setView(null)}>
          <img src={view} alt="" className="max-w-full max-h-full rounded-xl" />
        </div>
      )}
    </div>
  );
};
