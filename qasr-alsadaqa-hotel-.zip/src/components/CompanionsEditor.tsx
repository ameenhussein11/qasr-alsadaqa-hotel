import React, { useState } from 'react';
import { UserPlus, X, Users } from 'lucide-react';
import type { Companion } from '../types/hotel';

const RELATIONS = ['زوجة', 'زوج', 'ابن', 'ابنة', 'أب', 'أم', 'أخ', 'أخت', 'صديق', 'زميل', 'أخرى'];
const cls =
  'w-full bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-lg px-3 py-2 text-xs sm:text-sm text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-sky-500';

interface Props {
  companions: Companion[];
  capacity?: number;
  /** return false to keep the form open (e.g. validation failed) */
  onAdd: (c: Omit<Companion, 'id'>) => boolean | void;
  onRemove: (id: string) => void;
}

/** Add / remove people staying in the same room as the main guest. */
export const CompanionsEditor: React.FC<Props> = ({ companions, capacity, onAdd, onRemove }) => {
  const [open, setOpen] = useState(false);
  const [name, setName] = useState('');
  const [relation, setRelation] = useState('زوجة');
  const [nationalId, setNationalId] = useState('');
  const [phone, setPhone] = useState('');
  const [age, setAge] = useState<number | ''>('');

  const total = companions.length + 1;

  const add = () => {
    if (!name.trim()) return alert('اسم المرافق مطلوب.');
    const ok = onAdd({
      name: name.trim(),
      relation,
      nationalId: nationalId.trim() || undefined,
      phone: phone.trim() || undefined,
      age: age === '' ? undefined : Number(age),
    });
    if (ok === false) return;
    setName(''); setNationalId(''); setPhone(''); setAge('');
    setOpen(false);
  };

  return (
    <div className="rounded-xl border border-slate-200 dark:border-slate-700/60 p-3 space-y-2 bg-slate-50/60 dark:bg-slate-800/30" dir="rtl">
      <div className="flex items-center justify-between gap-2">
        <span className="text-xs font-bold text-slate-600 dark:text-slate-300 flex items-center gap-1.5">
          <Users className="w-4 h-4 text-sky-500" />
          المقيمون في الغرفة: {total}
          {capacity ? <span className="text-slate-400 font-normal"> (السعة {capacity})</span> : null}
        </span>
        <button type="button" onClick={() => setOpen((v) => !v)} className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-sky-600 text-white text-[11px] font-bold cursor-pointer">
          <UserPlus className="w-3.5 h-3.5" /> إضافة فرد
        </button>
      </div>

      {companions.length > 0 && (
        <ul className="space-y-1">
          {companions.map((c) => (
            <li key={c.id} className="flex items-center justify-between gap-2 bg-white dark:bg-slate-900 rounded-lg px-2.5 py-1.5 border border-slate-200 dark:border-slate-800 text-xs">
              <span className="min-w-0">
                <strong className="text-slate-800 dark:text-slate-100">{c.name}</strong>
                <span className="text-slate-500"> • {c.relation}{c.age ? ` • ${c.age} سنة` : ''}{c.nationalId ? ` • هوية ${c.nationalId}` : ''}</span>
              </span>
              <button type="button" onClick={() => onRemove(c.id)} className="p-1 text-rose-500 cursor-pointer shrink-0" aria-label="حذف المرافق">
                <X className="w-4 h-4" />
              </button>
            </li>
          ))}
        </ul>
      )}

      {open && (
        <div className="grid grid-cols-2 gap-2 pt-1">
          <input className={`${cls} col-span-2`} placeholder="اسم المرافق" value={name} onChange={(e) => setName(e.target.value)} />
          <select className={cls} value={relation} onChange={(e) => setRelation(e.target.value)}>
            {RELATIONS.map((r) => <option key={r}>{r}</option>)}
          </select>
          <input className={cls} type="number" min={0} max={120} placeholder="العمر (اختياري)" value={age} onChange={(e) => setAge(e.target.value === '' ? '' : Number(e.target.value))} />
          <input className={cls} placeholder="رقم الهوية (اختياري)" value={nationalId} onChange={(e) => setNationalId(e.target.value)} />
          <input className={cls} inputMode="tel" placeholder="الجوال (اختياري)" value={phone} onChange={(e) => setPhone(e.target.value)} />
          <div className="col-span-2 flex gap-2">
            <button type="button" onClick={add} className="flex-1 py-2 rounded-lg bg-emerald-600 text-white text-xs font-bold cursor-pointer">إضافة</button>
            <button type="button" onClick={() => setOpen(false)} className="px-4 py-2 rounded-lg bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 text-xs font-semibold cursor-pointer">إلغاء</button>
          </div>
        </div>
      )}
    </div>
  );
};
