import React, { useEffect, useState } from 'react';
import { Palette, Sun, Moon, MonitorSmartphone, X, Check } from 'lucide-react';
import { getThemeMode, setThemeMode, ThemeMode, PALETTES, getPalette, setPalette, PaletteId } from '../utils/theme';

const MODES: { id: ThemeMode; label: string; Icon: typeof Sun }[] = [
  { id: 'system', label: 'تلقائي', Icon: MonitorSmartphone },
  { id: 'light', label: 'نهاري', Icon: Sun },
  { id: 'dark', label: 'ليلي', Icon: Moon },
];

/** Header button that opens the appearance sheet: day/night/system + colour themes. */
export const ThemeToggle: React.FC = () => {
  const [open, setOpen] = useState(false);
  const [mode, setMode] = useState<ThemeMode>(getThemeMode());
  const [palette, setPal] = useState<PaletteId>(getPalette());

  useEffect(() => {
    const on = () => {
      setMode(getThemeMode());
      setPal(getPalette());
    };
    window.addEventListener('qasr-theme-change', on);
    return () => window.removeEventListener('qasr-theme-change', on);
  }, []);

  return (
    <>
      <button
        type="button"
        onClick={() => setOpen(true)}
        title="المظهر والثيمات"
        aria-label="المظهر والثيمات"
        className="p-2 text-slate-300 hover:text-white bg-slate-800 hover:bg-slate-700 rounded-xl border border-slate-700 transition cursor-pointer flex items-center gap-1.5"
      >
        <Palette className="w-4 h-4 text-amber-300" />
        <span className="hidden lg:inline text-xs">المظهر</span>
      </button>

      {open && (
        <div
          className="fixed inset-0 z-[80] bg-black/60 backdrop-blur-sm flex items-end sm:items-center justify-center"
          onClick={() => setOpen(false)}
          dir="rtl"
        >
          <div
            className="w-full sm:max-w-md bg-white dark:bg-slate-900 rounded-t-3xl sm:rounded-3xl border border-slate-200 dark:border-slate-800 shadow-2xl p-5 space-y-5 max-h-[88vh] overflow-y-auto"
            style={{ paddingBottom: 'calc(1.25rem + env(safe-area-inset-bottom, 0px))' }}
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between">
              <h3 className="font-bold text-slate-900 dark:text-white flex items-center gap-2">
                <Palette className="w-5 h-5 text-sky-500" /> المظهر والثيمات
              </h3>
              <button onClick={() => setOpen(false)} className="p-1.5 text-slate-400 cursor-pointer" aria-label="إغلاق">
                <X className="w-5 h-5" />
              </button>
            </div>

            <section className="space-y-2">
              <div className="text-xs font-semibold text-slate-500">الوضع</div>
              <div className="grid grid-cols-3 gap-2">
                {MODES.map(({ id, label, Icon }) => (
                  <button
                    key={id}
                    onClick={() => setThemeMode(id)}
                    className={`flex flex-col items-center gap-1 py-3 rounded-2xl border text-xs font-semibold cursor-pointer transition ${
                      mode === id
                        ? 'border-sky-500 bg-sky-50 dark:bg-sky-950/40 text-sky-700 dark:text-sky-300'
                        : 'border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300'
                    }`}
                  >
                    <Icon className="w-5 h-5" />
                    {label}
                  </button>
                ))}
              </div>
              <p className="text-[11px] text-slate-400">«تلقائي» يتبع إعداد الهاتف (ليلي/نهاري).</p>
            </section>

            <section className="space-y-2">
              <div className="text-xs font-semibold text-slate-500">لون الواجهة</div>
              <div className="grid grid-cols-1 gap-2">
                {PALETTES.map((p) => (
                  <button
                    key={p.id}
                    onClick={() => setPalette(p.id)}
                    className={`flex items-center justify-between gap-3 p-3 rounded-2xl border cursor-pointer transition ${
                      palette === p.id
                        ? 'border-sky-500 bg-sky-50 dark:bg-sky-950/40'
                        : 'border-slate-200 dark:border-slate-700'
                    }`}
                  >
                    <span className="flex items-center gap-3">
                      <span
                        className="w-10 h-10 rounded-xl border border-white/20 shadow-inner relative overflow-hidden"
                        style={{ background: p.surface }}
                      >
                        <span className="absolute bottom-0 left-0 right-0 h-1/2" style={{ background: p.accent }} />
                      </span>
                      <span className="font-bold text-sm text-slate-800 dark:text-slate-100">{p.name}</span>
                    </span>
                    {palette === p.id && <Check className="w-5 h-5 text-sky-600" />}
                  </button>
                ))}
              </div>
            </section>
          </div>
        </div>
      )}
    </>
  );
};
