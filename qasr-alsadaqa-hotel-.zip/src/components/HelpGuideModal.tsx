import React, { useState } from 'react';
import { useHotel } from '../context/HotelContext';
import {
  HelpCircle,
  BookOpen,
  DoorOpen,
  Calendar,
  UtensilsCrossed,
  Sparkles,
  ArrowLeftRight,
  Database,
  Printer,
  ChevronDown,
  ChevronUp,
  X,
  Mail,
  Phone,
} from 'lucide-react';

export const HelpGuideModal: React.FC = () => {
  const { isHelpModalOpen, setIsHelpModalOpen, settings } = useHotel();
  const [openSection, setOpenSection] = useState<number | null>(0);

  if (!isHelpModalOpen) return null;

  const sections = [
    {
      id: 0,
      icon: <DoorOpen className="w-5 h-5 text-sky-500" />,
      title: '1. تسكين وحجز غرفة لنزيل جديد (Check-in)',
      content:
        'من الشاشة الرئيسية أو بالضغط على زر (+) الأزرق، اختر الغرفة المتاحة، ثم أدخل اسم النزيل ورقم هاتفه ورقم الهوية وعدد الليالي والمبلغ المدفوع، واضغط "تأكيد تسجيل الوصول". سيتم تلقائياً تحديث حالة الغرفة إلى (مشغولة) وإنشاء سجل الحجز وتوثيق سند القبض.',
    },
    {
      id: 1,
      icon: <Calendar className="w-5 h-5 text-sky-500" />,
      title: '2. إدارة الحجوزات وتمديد الإقامة (Reservations)',
      content:
        'في تبويب "الحجز"، يمكنك استعراض جميع الحجوزات النشطة والمنتهية والبحث برقم الحجز أو اسم النزيل. لتمديد الإقامة، اضغط على أيقونة (+) بجانب الحجز وحدد عدد الليالي الإضافية وسيتم احتساب التكلفة وتحديث موعد المغادرة.',
    },
    {
      id: 2,
      icon: <UtensilsCrossed className="w-5 h-5 text-sky-500" />,
      title: '3. طلبات خدمة الغرف والفوترة التلقائية (Room Service)',
      content:
        'في تبويب "خدمة الغرف"، يمكنك إنشاء طلب طعام أو مشروبات للغرفة واختيار الفوترة على حساب الغرفة (Room Bill) ليتم ترحيل المبلغ تلقائياً على فاتورة النزيل النهائية عند المغادرة، أو الدفع عند التسليم كاش/بطاقة.',
    },
    {
      id: 3,
      icon: <Sparkles className="w-5 h-5 text-sky-500" />,
      title: '4. الهاوس كيبينج وتجهيز الغرف (Housekeeping)',
      content:
        'عند تسجيل مغادرة أي نزيل، تتحول الغرفة تلقائياً إلى الحالة (بحاجة لتنظيف) وتُضاف إلى قائمة مهام الهاوس كيبينج. بعد إنهاء تنظيف الحمام والمفارش والتعقيم واكتمال القائمة، تعود الغرفة تلقائياً إلى الحالة (متاحة).',
    },
    {
      id: 4,
      icon: <ArrowLeftRight className="w-5 h-5 text-sky-500" />,
      title: '5. رواتب الموظفين والمصروفات والصندوق (Finance)',
      content:
        'في قسم "الإيرادات والمصروفات الأخرى"، يمكنك صرف رواتب موظفي الفندق الشهرية مع المكافآت والخصومات وطباعة قسائم الرواتب PDF، وتسجيل مصروفات الصيانة والفواتير ومتابعة الرصيد النقدي الفعلي في الدرج (Cash Drawer) وإقفال اليومية.',
    },
    {
      id: 5,
      icon: <Database className="w-5 h-5 text-sky-500" />,
      title: '6. النسخ الاحتياطي وحفظ بيانات SQLite (Backup)',
      content:
        'النظام يعمل بمحرك قاعدة بيانات SQLite محلي مستقل. يمكنك في أي وقت من "إدارة النظام" تصدير نسخة احتياطية بصيغة SQL Dump أو JSON للاحتفاظ بنسخة على جهازك واستعادتها في أي وقت.',
    },
  ];

  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4" dir="rtl">
      <div className="bg-white dark:bg-slate-900 rounded-3xl p-6 w-full max-w-2xl max-h-[90vh] flex flex-col border border-slate-200 dark:border-slate-800 shadow-2xl space-y-4 animate-scaleUp">
        {/* Top Header */}
        <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3 shrink-0">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-sky-500/10 text-sky-500">
              <BookOpen className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base sm:text-lg font-bold text-slate-800 dark:text-slate-100">
                تعليمات ودليل استخدام النظام (Help & Guide)
              </h3>
              <p className="text-xs text-slate-400">إرشادات سريعة لكافة وظائف برنامج {settings.hotelName}</p>
            </div>
          </div>

          <button
            onClick={() => setIsHelpModalOpen(false)}
            className="p-1 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Accordion FAQ content */}
        <div className="flex-1 overflow-y-auto space-y-2.5 pr-1 text-xs sm:text-sm">
          {sections.map((sec) => (
            <div
              key={sec.id}
              className="rounded-2xl border border-slate-200 dark:border-slate-800 overflow-hidden bg-slate-50/50 dark:bg-slate-800/30 transition"
            >
              <button
                onClick={() => setOpenSection(openSection === sec.id ? null : sec.id)}
                className="w-full p-3.5 text-right font-bold text-slate-800 dark:text-slate-100 flex items-center justify-between hover:bg-slate-100/50 dark:hover:bg-slate-800 transition cursor-pointer"
              >
                <div className="flex items-center gap-2.5">
                  {sec.icon}
                  <span>{sec.title}</span>
                </div>
                {openSection === sec.id ? (
                  <ChevronUp className="w-4 h-4 text-slate-400" />
                ) : (
                  <ChevronDown className="w-4 h-4 text-slate-400" />
                )}
              </button>

              {openSection === sec.id && (
                <div className="p-4 pt-1 text-slate-600 dark:text-slate-300 border-t border-slate-100 dark:border-slate-800 text-xs leading-relaxed bg-white dark:bg-slate-900/60">
                  {sec.content}
                </div>
              )}
            </div>
          ))}
        </div>

        {/* Footer Support Info */}
        <div className="p-3.5 rounded-2xl bg-sky-50 dark:bg-sky-950/40 border border-sky-100 dark:border-sky-900/50 flex items-center justify-between text-xs shrink-0">
          <div className="flex items-center gap-2 text-sky-700 dark:text-sky-300">
            <Mail className="w-4 h-4 text-rose-500" />
            <span><strong>فندق قصر الصداقة السياحي</strong></span>
          </div>

          <button
            onClick={() => setIsHelpModalOpen(false)}
            className="px-4 py-1.5 rounded-xl bg-sky-600 hover:bg-sky-500 text-white font-semibold text-xs transition cursor-pointer"
          >
            حسناً، فهمت
          </button>
        </div>
      </div>
    </div>
  );
};
