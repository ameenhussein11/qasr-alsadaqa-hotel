import React, { useMemo, useState } from 'react';
import { Lock, Unlock, FileDown } from 'lucide-react';
import { useHotel } from '../../context/HotelContext';
import type { ClosingType } from '../../types/archive';
import { computeFigures } from '../../utils/closing';
import { periodFor, shiftPeriod, CLOSING_TYPE_AR } from '../../utils/periods';
import { localDate } from '../../utils/dates';
import { exportArabicPdf, money } from '../../utils/arabicPdf';
import { Card, Stat, DateNav, Empty, CATEGORY_AR, METHOD_AR } from './shared';

const TYPES: ClosingType[] = ['daily', 'weekly', 'monthly', 'yearly'];

export const ClosingPanel: React.FC = () => {
  const { rooms, bookings, guests, payments, expenses, otherRevenues, staffSalaries, closings, closePeriod, reopenPeriod, settings } = useHotel();
  const sym = settings.currencySymbol;
  const [type, setType] = useState<ClosingType>('daily');
  const [anchor, setAnchor] = useState(localDate());

  const period = useMemo(() => periodFor(type, anchor), [type, anchor]);
  const closed = closings.find((c) => c.type === type && c.key === period.key);
  const live = useMemo(
    () => computeFigures({ rooms, bookings, guests, payments, expenses, otherRevenues, staffSalaries }, period.from, period.to),
    [rooms, bookings, guests, payments, expenses, otherRevenues, staffSalaries, period]
  );
  const f = closed ? closed.figures : live;
  const history = closings.filter((c) => c.type === type).sort((a, b) => b.from.localeCompare(a.from));
  const ended = period.to <= localDate();

  const doClose = () => {
    if (!confirm(`تأكيد إقفال ${CLOSING_TYPE_AR[type]}: ${period.label}؟\nسيتم تجميد الأرقام، ولن تُقبل مصروفات أو رواتب بتواريخ هذه الفترة إلا بعد إعادة الفتح.`)) return;
    const r = closePeriod(type, anchor);
    if (!r.success) alert(r.error);
  };

  const exportPdf = () => {
    const rows: (string | number)[][] = [
      ['إيرادات الغرف (المدفوعات)', money(f.roomRevenue, sym)],
      ...Object.entries(f.roomRevenueByMethod).map(([m, v]) => [`   • ${METHOD_AR[m] || m}`, money(v, sym)]),
      ['إيرادات أخرى', money(f.otherRevenue, sym)],
      ['إجمالي الإيرادات', money(f.totalRevenue, sym)],
      ...Object.entries(f.expensesByCategory).map(([c, v]) => [`مصروفات: ${CATEGORY_AR[c] || c}`, money(v, sym)]),
      ['إجمالي المصروفات (يشمل الرواتب)', money(f.expenses, sym)],
      [`الرواتب المصروفة (${f.salariesCount} موظف)`, money(f.salariesPaid, sym)],
      ['عدد الوصول / المغادرة', `${f.checkIns} / ${f.checkOuts}`],
      ['نزلاء جدد', f.newGuests],
      ['الليالي المباعة', f.nightsSold],
      ['نسبة الإشغال', `${f.occupancyPercent}%`],
      ['متوسط سعر الليلة', money(f.adr, sym)],
    ];
    exportArabicPdf(
      {
        hotelName: settings.hotelName,
        hotelAddress: settings.address,
        title: `تقرير الإقفال ${CLOSING_TYPE_AR[type]}`,
        metaRight: [['الفترة', period.label], ['من', period.from], ['إلى', period.to]],
        metaLeft: [['الحالة', closed ? 'مقفل' : 'مفتوح (أرقام حالية)'], ['تاريخ الإقفال', closed?.closedAt || '—'], ['أقفله', closed?.closedBy || '—']],
        columns: [{ header: 'البند', width: 6 }, { header: 'القيمة', width: 3, align: 'center' }],
        rows,
        totals: [['صافي الربح', money(f.net, sym)]],
        signatures: ['المحاسب', 'المدير العام'],
      },
      `إقفال-${CLOSING_TYPE_AR[type]}-${period.key}`
    );
  };

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-4 gap-1.5 bg-slate-100 dark:bg-slate-800 p-1 rounded-2xl">
        {TYPES.map((t) => (
          <button
            key={t}
            onClick={() => setType(t)}
            className={`py-2 rounded-xl text-xs sm:text-sm font-bold cursor-pointer transition ${type === t ? 'bg-white dark:bg-slate-900 text-sky-700 dark:text-sky-300 shadow-sm' : 'text-slate-500'}`}
          >
            {CLOSING_TYPE_AR[t]}
          </button>
        ))}
      </div>

      <DateNav value={anchor} onChange={setAnchor} onPrev={() => setAnchor(shiftPeriod(type, anchor, -1))} onNext={() => setAnchor(shiftPeriod(type, anchor, 1))} />

      <Card>
        <div className="flex items-center justify-between gap-2">
          <div>
            <div className="font-bold text-slate-800 dark:text-slate-100">{period.label}</div>
            <div className="text-[11px] text-slate-500">{period.from} ← {period.to}</div>
          </div>
          <span className={`px-3 py-1 rounded-full text-xs font-bold ${closed ? 'bg-emerald-100 text-emerald-700 dark:bg-emerald-950 dark:text-emerald-300' : 'bg-amber-100 text-amber-700 dark:bg-amber-950 dark:text-amber-300'}`}>
            {closed ? '🔒 مقفل' : 'مفتوح'}
          </span>
        </div>
        {closed && <div className="text-[11px] text-slate-500">أُقفل في {closed.closedAt} بواسطة {closed.closedBy}</div>}

        <div className="grid grid-cols-2 gap-2">
          <Stat label="إجمالي الإيرادات" value={money(f.totalRevenue, sym)} tone="good" />
          <Stat label="إجمالي المصروفات" value={money(f.expenses, sym)} tone="bad" hint="يشمل الرواتب" />
          <Stat label="صافي الربح" value={money(f.net, sym)} tone={f.net >= 0 ? 'gold' : 'bad'} />
          <Stat label="الرواتب المصروفة" value={money(f.salariesPaid, sym)} hint={`${f.salariesCount} موظف`} />
          <Stat label="إيرادات الغرف" value={money(f.roomRevenue, sym)} />
          <Stat label="إيرادات أخرى" value={money(f.otherRevenue, sym)} />
          <Stat label="نسبة الإشغال" value={`${f.occupancyPercent}%`} hint={`${f.nightsSold} ليلة مباعة`} />
          <Stat label="متوسط سعر الليلة" value={money(f.adr, sym)} />
          <Stat label="وصول / مغادرة" value={`${f.checkIns} / ${f.checkOuts}`} />
          <Stat label="نزلاء جدد" value={f.newGuests} />
        </div>

        {Object.keys(f.expensesByCategory).length > 0 && (
          <div className="text-xs space-y-1 pt-1">
            <div className="font-semibold text-slate-600 dark:text-slate-300">تفصيل المصروفات</div>
            {Object.entries(f.expensesByCategory).map(([c, v]) => (
              <div key={c} className="flex justify-between text-slate-600 dark:text-slate-400">
                <span>{CATEGORY_AR[c] || c}</span>
                <span className="font-mono">{money(v, sym)}</span>
              </div>
            ))}
          </div>
        )}

        <div className="flex flex-wrap gap-2 pt-1">
          {!closed ? (
            <button
              onClick={doClose}
              disabled={!ended}
              title={ended ? '' : 'لا يمكن إقفال فترة لم تنتهِ'}
              className="flex items-center gap-1.5 px-4 py-2.5 rounded-xl bg-sky-600 hover:bg-sky-500 disabled:opacity-40 text-white text-sm font-bold cursor-pointer"
            >
              <Lock className="w-4 h-4" /> إقفال {CLOSING_TYPE_AR[type]}
            </button>
          ) : (
            <button
              onClick={() => confirm('إعادة فتح الفترة تسمح بالتعديل عليها. متابعة؟') && reopenPeriod(closed.id)}
              className="flex items-center gap-1.5 px-4 py-2.5 rounded-xl bg-amber-100 text-amber-800 text-sm font-bold cursor-pointer"
            >
              <Unlock className="w-4 h-4" /> إعادة فتح
            </button>
          )}
          <button onClick={exportPdf} className="flex items-center gap-1.5 px-4 py-2.5 rounded-xl bg-rose-50 dark:bg-rose-950/40 text-rose-700 dark:text-rose-300 text-sm font-bold cursor-pointer">
            <FileDown className="w-4 h-4" /> تقرير PDF
          </button>
        </div>
        {!ended && !closed && <div className="text-[11px] text-slate-400">الفترة لم تنتهِ بعد، ويمكنك إقفالها بعد نهايتها (اليومي: من اليوم نفسه).</div>}
      </Card>

      <Card title={`سجل الإقفالات ${CLOSING_TYPE_AR[type]}ة`}>
        {history.length === 0 ? (
          <Empty text="لا توجد إقفالات بعد" />
        ) : (
          <ul className="space-y-2">
            {history.map((c) => (
              <li key={c.id}>
                <button onClick={() => setAnchor(c.from)} className="w-full text-right border border-slate-200 dark:border-slate-700 rounded-xl p-3 flex items-center justify-between gap-2 cursor-pointer">
                  <span>
                    <span className="block font-semibold text-sm text-slate-800 dark:text-slate-100">{c.label}</span>
                    <span className="block text-[11px] text-slate-500">أُقفل {c.closedAt}</span>
                  </span>
                  <span className={`font-mono text-sm font-bold ${c.figures.net >= 0 ? 'text-emerald-600' : 'text-rose-600'}`}>{money(c.figures.net, sym)}</span>
                </button>
              </li>
            ))}
          </ul>
        )}
      </Card>
    </div>
  );
};
