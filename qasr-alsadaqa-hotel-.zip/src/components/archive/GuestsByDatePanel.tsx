import React, { useMemo, useState } from 'react';
import { Search, FileDown, Star, Ban } from 'lucide-react';
import { useHotel } from '../../context/HotelContext';
import { localDate, addDaysToDateStr } from '../../utils/dates';
import { exportArabicPdf } from '../../utils/arabicPdf';
import { Card, DateNav, Empty, inputCls } from './shared';
import { useDaySnapshot } from './useDaySnapshot';

export const GuestsByDatePanel: React.FC = () => {
  const { settings } = useHotel();
  const today = localDate();
  const [date, setDate] = useState(today);
  const [q, setQ] = useState('');
  const [onlyStaying, setOnlyStaying] = useState(false);
  const { snap, dates, loading } = useDaySnapshot(date);

  const rows = useMemo(() => {
    if (!snap) return [];
    const t = q.trim().toLowerCase();
    return snap.guests.filter((g) => {
      if (onlyStaying && !g.roomNumber) return false;
      if (!t) return true;
      return [g.name, g.phone, g.nationalId, g.nationality, g.roomNumber].some((v) => (v || '').toLowerCase().includes(t));
    });
  }, [snap, q, onlyStaying]);

  const exportPdf = () => {
    if (!snap) return;
    exportArabicPdf(
      {
        hotelName: settings.hotelName,
        hotelAddress: settings.address,
        title: 'سجل النزلاء (نسخة يومية)',
        landscape: true,
        metaRight: [['تاريخ النسخة', snap.date], ['عدد النزلاء', String(rows.length)]],
        metaLeft: [['وقت الحفظ', snap.savedAt]],
        columns: [
          { header: '#', width: 0.8, align: 'center' },
          { header: 'الاسم', width: 3.2 },
          { header: 'الجوال', width: 2.2, align: 'center' },
          { header: 'الهوية', width: 2.4, align: 'center' },
          { header: 'الجنسية', width: 1.8, align: 'center' },
          { header: 'الغرفة', width: 1.2, align: 'center' },
          { header: 'ليالي الاستضافة', width: 1.8, align: 'center' },
          { header: 'تاريخ الاستضافة', width: 4, align: 'center' },
        ],
        rows: rows.map((g, i) => [
          i + 1,
          g.name,
          g.phone || '—',
          g.nationalId || '—',
          g.nationality || '—',
          g.roomNumber || g.lastStayRoom || '—',
          g.hostedNights,
          g.roomNumber ? `منذ ${g.checkIn}` : g.lastStayFrom ? `${g.lastStayFrom} ← ${g.lastStayTo}` : '—',
        ]),
      },
      `سجل-النزلاء-${snap.date}`
    );
  };

  return (
    <div className="space-y-4">
      <DateNav value={date} max={today} onChange={setDate} onPrev={() => setDate(addDaysToDateStr(date, -1))} onNext={() => date < today && setDate(addDaysToDateStr(date, 1))} />
      {dates.length > 0 && (
        <div className="flex gap-1.5 overflow-x-auto pb-1">
          {dates.slice(0, 14).map((d) => (
            <button key={d} onClick={() => setDate(d)} className={`shrink-0 px-3 py-1.5 rounded-full text-[11px] font-semibold cursor-pointer border ${d === date ? 'bg-sky-600 text-white border-sky-600' : 'border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300'}`}>
              {d.substring(5)}
            </button>
          ))}
        </div>
      )}

      <div className="relative">
        <Search className="w-4 h-4 text-slate-400 absolute right-3 top-1/2 -translate-y-1/2" />
        <input className={`${inputCls} pr-9`} placeholder="بحث: اسم، جوال، هوية، جنسية، رقم غرفة" value={q} onChange={(e) => setQ(e.target.value)} />
      </div>
      <div className="flex items-center justify-between gap-2">
        <label className="flex items-center gap-2 text-xs text-slate-600 dark:text-slate-300 cursor-pointer">
          <input type="checkbox" checked={onlyStaying} onChange={(e) => setOnlyStaying(e.target.checked)} /> المقيمون فقط
        </label>
        <button onClick={exportPdf} disabled={!snap} className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-rose-50 dark:bg-rose-950/40 text-rose-700 dark:text-rose-300 text-xs font-bold disabled:opacity-40 cursor-pointer">
          <FileDown className="w-4 h-4" /> PDF
        </button>
      </div>

      {loading ? <Empty text="جارٍ التحميل…" /> : !snap ? (
        <Card><Empty text="لا توجد نسخة محفوظة من سجل النزلاء لهذا اليوم." /></Card>
      ) : (
        <Card title={`سجل النزلاء بتاريخ ${snap.date} (${rows.length})`}>
          {rows.length === 0 ? <Empty text="لا توجد نتائج" /> : (
            <ul className="space-y-2">
              {rows.map((g) => (
                <li key={g.id} className="border border-slate-200 dark:border-slate-700 rounded-xl p-3 text-xs space-y-0.5">
                  <div className="flex items-center gap-1.5 font-bold text-sm text-slate-800 dark:text-slate-100">
                    {g.name}
                    {g.isVip && <Star className="w-3.5 h-3.5 text-amber-500" />}
                    {g.isBlacklisted && <Ban className="w-3.5 h-3.5 text-rose-500" />}
                  </div>
                  <div className="text-slate-500">{g.phone || '—'} • {g.nationality || '—'} • هوية: {g.nationalId || '—'}</div>
                  <div className="text-slate-600 dark:text-slate-300">
                    {g.roomNumber
                      ? `مقيم في الغرفة ${g.roomNumber} منذ ${g.checkIn}`
                      : g.lastStayFrom
                        ? `آخر استضافة: غرفة ${g.lastStayRoom} من ${g.lastStayFrom} إلى ${g.lastStayTo}`
                        : 'لا توجد استضافة'}
                    {' '}• الإجمالي {g.hostedNights} ليلة
                  </div>
                </li>
              ))}
            </ul>
          )}
        </Card>
      )}
    </div>
  );
};
