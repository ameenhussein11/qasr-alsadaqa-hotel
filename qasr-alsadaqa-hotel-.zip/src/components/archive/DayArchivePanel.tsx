import React, { useMemo, useState } from 'react';
import { Search, Save } from 'lucide-react';
import { useHotel } from '../../context/HotelContext';
import { localDate, addDaysToDateStr } from '../../utils/dates';
import { money } from '../../utils/arabicPdf';
import { Card, Stat, DateNav, Empty, inputCls, CATEGORY_AR, METHOD_AR } from './shared';
import { useDaySnapshot } from './useDaySnapshot';

const STATUS_AR: Record<string, string> = { available: 'متاحة', occupied: 'مشغولة', cleaning: 'تنظيف', maintenance: 'صيانة' };
const STATUS_CLS: Record<string, string> = {
  available: 'bg-emerald-100 text-emerald-700 dark:bg-emerald-950 dark:text-emerald-300',
  occupied: 'bg-rose-100 text-rose-700 dark:bg-rose-950 dark:text-rose-300',
  cleaning: 'bg-amber-100 text-amber-700 dark:bg-amber-950 dark:text-amber-300',
  maintenance: 'bg-slate-200 text-slate-600 dark:bg-slate-800 dark:text-slate-300',
};

export const DayArchivePanel: React.FC = () => {
  const { settings } = useHotel();
  const sym = settings.currencySymbol;
  const today = localDate();
  const [date, setDate] = useState(today);
  const [q, setQ] = useState('');
  const { snap, dates, loading, saveNow } = useDaySnapshot(date);

  const match = (...vals: (string | undefined | null)[]) => !q.trim() || vals.some((v) => (v || '').toLowerCase().includes(q.trim().toLowerCase()));
  const f = snap?.figures;

  const bookings = useMemo(() => (snap ? snap.dayBookings.filter((b) => match(b.guestName, b.roomNumber, b.bookingCode)) : []), [snap, q]);
  const active = useMemo(() => (snap ? snap.activeBookings.filter((b) => match(b.guestName, b.roomNumber, b.bookingCode)) : []), [snap, q]);
  const logs = useMemo(() => (snap ? snap.logs.filter((l) => match(l.action, l.details)) : []), [snap, q]);

  return (
    <div className="space-y-4">
      <DateNav value={date} max={today} onChange={setDate} onPrev={() => setDate(addDaysToDateStr(date, -1))} onNext={() => date < today && setDate(addDaysToDateStr(date, 1))} />

      {dates.length > 0 && (
        <div className="flex gap-1.5 overflow-x-auto pb-1">
          {dates.slice(0, 14).map((d) => (
            <button key={d} onClick={() => setDate(d)} className={`shrink-0 px-3 py-1.5 rounded-full text-[11px] font-semibold cursor-pointer border ${d === date ? 'bg-sky-600 text-white border-sky-600' : 'border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300'}`}>
              {d.substring(5)}
            </button>
          ))}
        </div>
      )}

      <div className="relative">
        <Search className="w-4 h-4 text-slate-400 absolute right-3 top-1/2 -translate-y-1/2" />
        <input className={`${inputCls} pr-9`} placeholder="بحث داخل اليوم: اسم نزيل، رقم غرفة، رقم حجز، إجراء…" value={q} onChange={(e) => setQ(e.target.value)} />
      </div>

      {loading ? (
        <Empty text="جارٍ التحميل…" />
      ) : !snap ? (
        <Card>
          <Empty text={date === today ? 'لم تُحفظ نسخة اليوم بعد.' : 'لا توجد نسخة محفوظة لهذا اليوم (لم يُفتح التطبيق فيه).'} />
          {date === today && (
            <button onClick={saveNow} className="mx-auto flex items-center gap-1.5 px-4 py-2 rounded-xl bg-sky-600 text-white text-sm font-bold cursor-pointer">
              <Save className="w-4 h-4" /> حفظ الآن
            </button>
          )}
        </Card>
      ) : (
        <>
          <Card title={`نسخة ${snap.date} — حُفظت ${snap.savedAt}`}>
            <div className="grid grid-cols-2 gap-2">
              <Stat label="الإشغال" value={`${snap.stats.occupancyPercent}%`} hint={`${snap.stats.occupied} من ${snap.stats.totalRooms} غرفة`} />
              <Stat label="إيرادات اليوم" value={money(f!.totalRevenue, sym)} tone="good" />
              <Stat label="مصروفات اليوم" value={money(f!.expenses, sym)} tone="bad" />
              <Stat label="صافي اليوم" value={money(f!.net, sym)} tone={f!.net >= 0 ? 'gold' : 'bad'} />
              <Stat label="وصول / مغادرة" value={`${f!.checkIns} / ${f!.checkOuts}`} />
              <Stat label="نزلاء مسجلون" value={snap.guests.length} />
            </div>
            {date === today && (
              <button onClick={saveNow} className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-200 text-xs font-bold cursor-pointer">
                <Save className="w-3.5 h-3.5" /> تحديث نسخة اليوم الآن
              </button>
            )}
          </Card>

          <Card title={`حالة الغرف (${snap.rooms.length})`}>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
              {snap.rooms.filter((r) => match(r.roomNumber, r.guestName)).map((r) => (
                <div key={r.roomNumber} className="rounded-xl border border-slate-200 dark:border-slate-700 p-2.5 text-xs">
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-slate-800 dark:text-slate-100">{r.roomNumber}</span>
                    <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${STATUS_CLS[r.status]}`}>{STATUS_AR[r.status]}</span>
                  </div>
                  {r.guestName && <div className="text-slate-500 truncate mt-1">{r.guestName}</div>}
                </div>
              ))}
            </div>
          </Card>

          <Card title={`حركة اليوم (${bookings.length})`}>
            {bookings.length === 0 ? <Empty text="لا توجد حركة وصول أو مغادرة" /> : (
              <ul className="space-y-2">
                {bookings.map((b) => (
                  <li key={b.bookingCode} className="text-xs border border-slate-200 dark:border-slate-700 rounded-xl p-2.5">
                    <div className="font-bold text-slate-800 dark:text-slate-100">{b.guestName} • غرفة {b.roomNumber} <span className="font-mono text-slate-400">{b.bookingCode}</span></div>
                    <div className="text-slate-500">دخول {b.checkInDate}{b.actualCheckOutDate ? ` • خروج ${b.actualCheckOutDate}` : ''}</div>
                    <div className="text-slate-500">الإجمالي {money(b.totalAmount, sym)} • المدفوع {money(b.paidAmount, sym)}</div>
                  </li>
                ))}
              </ul>
            )}
          </Card>

          <Card title={`المقيمون وقت الحفظ (${active.length})`}>
            {active.length === 0 ? <Empty text="لا يوجد مقيمون" /> : (
              <ul className="space-y-1.5 text-xs">
                {active.map((b) => (
                  <li key={b.bookingCode} className="flex justify-between gap-2 border-b border-slate-100 dark:border-slate-800 pb-1.5">
                    <span className="text-slate-800 dark:text-slate-100 font-semibold">{b.guestName}</span>
                    <span className="text-slate-500">غرفة {b.roomNumber} • حتى {b.expectedCheckOutDate.substring(0, 10)}</span>
                  </li>
                ))}
              </ul>
            )}
          </Card>

          <Card title="المدفوعات والمصروفات">
            <div className="space-y-1.5 text-xs">
              {snap.payments.map((p) => (
                <div key={p.id} className="flex justify-between text-emerald-700 dark:text-emerald-400"><span>＋ دفعة {p.receiptNumber} ({METHOD_AR[p.method] || p.method})</span><span className="font-mono">{money(p.amount, sym)}</span></div>
              ))}
              {snap.otherRevenues.map((r) => (
                <div key={r.id} className="flex justify-between text-emerald-700 dark:text-emerald-400"><span>＋ {r.title}</span><span className="font-mono">{money(r.amount, sym)}</span></div>
              ))}
              {snap.expenses.map((e) => (
                <div key={e.id} className="flex justify-between text-rose-600 dark:text-rose-400"><span>－ {e.title} ({CATEGORY_AR[e.category] || e.category})</span><span className="font-mono">{money(e.amount, sym)}</span></div>
              ))}
              {snap.payments.length + snap.otherRevenues.length + snap.expenses.length === 0 && <Empty text="لا توجد حركات مالية" />}
            </div>
          </Card>

          <Card title={`سجل عمليات اليوم (${logs.length})`}>
            {logs.length === 0 ? <Empty text="لا توجد عمليات" /> : (
              <ul className="space-y-1.5 text-xs max-h-80 overflow-y-auto">
                {logs.map((l) => (
                  <li key={l.id} className="border-b border-slate-100 dark:border-slate-800 pb-1.5">
                    <div className="font-semibold text-slate-800 dark:text-slate-100">{l.action}</div>
                    <div className="text-slate-500">{l.timestamp.substring(11)} — {l.details}</div>
                  </li>
                ))}
              </ul>
            )}
          </Card>
        </>
      )}
    </div>
  );
};
