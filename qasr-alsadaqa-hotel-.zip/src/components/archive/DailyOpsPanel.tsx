import React, { useMemo, useState } from 'react';
import { Plus, Trash2, Wallet, CheckCircle2 } from 'lucide-react';
import { useHotel } from '../../context/HotelContext';
import type { ExpenseCategory, PaymentMethod } from '../../types/hotel';
import { localDate } from '../../utils/dates';
import { money } from '../../utils/arabicPdf';
import { Card, inputCls, Empty, CATEGORY_AR } from './shared';

const DAILY_CATEGORIES: ExpenseCategory[] = ['supplies', 'utilities', 'maintenance', 'government', 'other'];

export const DailyOpsPanel: React.FC = () => {
  const { expenses, addExpense, deleteExpense, staffMembers, staffSalaries, recordSalaryPayment, currentUser, findClosedPeriod, settings } = useHotel();
  const sym = settings.currencySymbol;
  const today = localDate();

  const guardClosed = () => {
    const c = findClosedPeriod(today);
    if (c) {
      alert(`اليوم ضمن فترة مقفلة (${c.label}). أعد فتحها من تبويب «الإقفال» أولاً.`);
      return true;
    }
    return false;
  };

  // ---------- daily expense ----------
  const [title, setTitle] = useState('');
  const [category, setCategory] = useState<ExpenseCategory>('supplies');
  const [amount, setAmount] = useState<number | ''>('');
  const [method, setMethod] = useState<PaymentMethod>('cash');
  const [recipient, setRecipient] = useState('');

  const todays = useMemo(() => expenses.filter((e) => e.date.substring(0, 10) === today), [expenses, today]);
  const todaysTotal = todays.reduce((a, e) => a + e.amount, 0);

  const addDaily = (e: React.FormEvent) => {
    e.preventDefault();
    if (guardClosed()) return;
    const amt = Number(amount);
    if (!title.trim() || !Number.isFinite(amt) || amt <= 0) return alert('أدخل البيان ومبلغاً صحيحاً.');
    addExpense({
      title: title.trim(),
      category,
      amount: amt,
      paymentMethod: method,
      date: today,
      recipientName: recipient.trim() || '—',
      recordedBy: currentUser.username,
    });
    setTitle('');
    setAmount('');
    setRecipient('');
  };

  // ---------- monthly salaries ----------
  const [month, setMonth] = useState(today.substring(0, 7));
  const [salaryMethod, setSalaryMethod] = useState<PaymentMethod>('cash');

  const roster = useMemo(
    () =>
      staffMembers
        .filter((s) => s.status !== 'resigned' || (s.leaveDate && s.leaveDate.substring(0, 7) >= month))
        .filter((s) => s.monthlySalary > 0)
        .map((s) => ({ staff: s, paid: staffSalaries.find((r) => r.staffId === s.id && r.month === month && r.status === 'paid') })),
    [staffMembers, staffSalaries, month]
  );
  const unpaid = roster.filter((r) => !r.paid);
  const unpaidTotal = unpaid.reduce((a, r) => a + r.staff.monthlySalary, 0);

  const payOne = (staffId: number) => {
    const r = roster.find((x) => x.staff.id === staffId);
    if (!r || r.paid) return;
    const s = r.staff;
    recordSalaryPayment({
      staffId: s.id,
      staffName: s.name,
      roleTitleAr: s.roleTitleAr,
      month,
      baseSalary: s.monthlySalary,
      bonus: 0,
      deductions: 0,
      netSalary: s.monthlySalary,
      paymentDate: today,
      paymentMethod: salaryMethod,
      status: 'paid',
    });
    // salaries are also counted as expenses (same as the finance screen)
    addExpense({
      title: `صرف راتب شهر ${month} للموظف: ${s.name}`,
      category: 'salaries',
      amount: s.monthlySalary,
      paymentMethod: salaryMethod,
      date: today,
      recipientName: s.name,
      recordedBy: currentUser.username,
      notes: `مسير رواتب - ${s.roleTitleAr}`,
    });
  };

  const payAll = () => {
    if (guardClosed()) return;
    if (unpaid.length === 0) return;
    if (!confirm(`صرف رواتب شهر ${month} لـ ${unpaid.length} موظف بإجمالي ${money(unpaidTotal, sym)}؟`)) return;
    unpaid.forEach((r) => payOne(r.staff.id));
  };

  return (
    <div className="space-y-4">
      <Card title="المصروف اليومي">
        <form onSubmit={addDaily} className="grid grid-cols-1 sm:grid-cols-2 gap-2">
          <input className={inputCls} placeholder="البيان (مثال: شراء مياه ومنظفات)" value={title} onChange={(e) => setTitle(e.target.value)} />
          <input className={inputCls} type="number" min={0} inputMode="decimal" placeholder={`المبلغ (${sym})`} value={amount} onChange={(e) => setAmount(e.target.value === '' ? '' : Number(e.target.value))} />
          <select className={inputCls} value={category} onChange={(e) => setCategory(e.target.value as ExpenseCategory)}>
            {DAILY_CATEGORIES.map((c) => <option key={c} value={c}>{CATEGORY_AR[c]}</option>)}
          </select>
          <select className={inputCls} value={method} onChange={(e) => setMethod(e.target.value as PaymentMethod)}>
            <option value="cash">نقداً</option>
            <option value="card">بطاقة</option>
            <option value="transfer">تحويل</option>
          </select>
          <input className={`${inputCls} sm:col-span-2`} placeholder="المستلم (اختياري)" value={recipient} onChange={(e) => setRecipient(e.target.value)} />
          <button type="submit" className="sm:col-span-2 flex items-center justify-center gap-1.5 px-4 py-2.5 rounded-xl bg-sky-600 hover:bg-sky-500 text-white text-sm font-bold cursor-pointer">
            <Plus className="w-4 h-4" /> تسجيل مصروف اليوم
          </button>
        </form>

        <div className="flex items-center justify-between text-xs pt-1">
          <span className="font-semibold text-slate-600 dark:text-slate-300">مصروفات اليوم ({todays.length})</span>
          <span className="font-mono font-bold text-rose-600">{money(todaysTotal, sym)}</span>
        </div>
        {todays.length === 0 ? <Empty text="لا توجد مصروفات اليوم" /> : (
          <ul className="space-y-1.5">
            {todays.map((e) => (
              <li key={e.id} className="flex items-center justify-between gap-2 text-xs border-b border-slate-100 dark:border-slate-800 pb-1.5">
                <span className="min-w-0">
                  <span className="block font-semibold text-slate-800 dark:text-slate-100 truncate">{e.title}</span>
                  <span className="block text-slate-500">{CATEGORY_AR[e.category] || e.category}</span>
                </span>
                <span className="flex items-center gap-2 shrink-0">
                  <span className="font-mono text-rose-600">{money(e.amount, sym)}</span>
                  <button
                    onClick={() => !guardClosed() && confirm('حذف هذا المصروف؟') && deleteExpense(e.id)}
                    className="p-1.5 rounded-lg text-slate-400 hover:text-rose-600 cursor-pointer"
                    aria-label="حذف"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </span>
              </li>
            ))}
          </ul>
        )}
      </Card>

      <Card title="الرواتب الشهرية للموظفين">
        <div className="grid grid-cols-2 gap-2">
          <input type="month" className={inputCls} value={month} onChange={(e) => e.target.value && setMonth(e.target.value)} />
          <select className={inputCls} value={salaryMethod} onChange={(e) => setSalaryMethod(e.target.value as PaymentMethod)}>
            <option value="cash">نقداً</option>
            <option value="transfer">تحويل</option>
            <option value="card">بطاقة</option>
          </select>
        </div>

        {roster.length === 0 ? <Empty text="لا يوجد موظفون برواتب محددة. أضف الراتب من «معلومات الحساب ← الحسابات والكادر»." /> : (
          <ul className="space-y-2">
            {roster.map(({ staff, paid }) => (
              <li key={staff.id} className="flex items-center justify-between gap-2 border border-slate-200 dark:border-slate-700 rounded-xl p-3">
                <span className="min-w-0">
                  <span className="block font-bold text-sm text-slate-800 dark:text-slate-100 truncate">{staff.name}</span>
                  <span className="block text-[11px] text-slate-500">{staff.roleTitleAr} • {money(staff.monthlySalary, sym)}</span>
                </span>
                {paid ? (
                  <span className="flex items-center gap-1 text-[11px] font-bold text-emerald-600 shrink-0"><CheckCircle2 className="w-4 h-4" /> صُرف {paid.paymentDate}</span>
                ) : (
                  <button
                    onClick={() => !guardClosed() && confirm(`صرف راتب ${staff.name} (${money(staff.monthlySalary, sym)}) عن ${month}؟`) && payOne(staff.id)}
                    className="shrink-0 flex items-center gap-1 px-3 py-1.5 rounded-lg bg-sky-600 text-white text-xs font-bold cursor-pointer"
                  >
                    <Wallet className="w-3.5 h-3.5" /> صرف
                  </button>
                )}
              </li>
            ))}
          </ul>
        )}

        {unpaid.length > 0 && (
          <button onClick={payAll} className="w-full flex items-center justify-center gap-1.5 px-4 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-sm font-bold cursor-pointer">
            <Wallet className="w-4 h-4" /> صرف رواتب الجميع ({unpaid.length}) — {money(unpaidTotal, sym)}
          </button>
        )}
        <p className="text-[11px] text-slate-400">كل راتب مصروف يُسجَّل تلقائياً كمصروف (رواتب)، ويدخل في إقفال اليوم الذي صُرف فيه.</p>
      </Card>
    </div>
  );
};
