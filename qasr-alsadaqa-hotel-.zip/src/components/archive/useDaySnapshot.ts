import { useCallback, useEffect, useState } from 'react';
import type { DaySnapshot } from '../../types/archive';
import { getDay, listDays } from '../../utils/archiveStore';
import { ARCHIVE_SAVED_EVENT, ARCHIVE_SAVE_NOW_EVENT } from '../DailyArchiver';

/** Loads the archived snapshot of a date (and the list of archived dates); refreshes when a new save happens. */
export function useDaySnapshot(date: string) {
  const [snap, setSnap] = useState<DaySnapshot | null>(null);
  const [dates, setDates] = useState<string[]>([]);
  const [loading, setLoading] = useState(true);

  const load = useCallback(async () => {
    const [s, d] = await Promise.all([getDay(date), listDays()]);
    setSnap(s);
    setDates(d);
    setLoading(false);
  }, [date]);

  useEffect(() => {
    setLoading(true);
    load();
    window.addEventListener(ARCHIVE_SAVED_EVENT, load);
    return () => window.removeEventListener(ARCHIVE_SAVED_EVENT, load);
  }, [load]);

  const saveNow = () => window.dispatchEvent(new CustomEvent(ARCHIVE_SAVE_NOW_EVENT));
  return { snap, dates, loading, saveNow };
}
