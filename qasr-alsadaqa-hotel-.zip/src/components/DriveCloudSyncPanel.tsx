import React, { useCallback, useEffect, useRef, useState } from 'react';
import { Cloud, CheckCircle2, AlertCircle, RefreshCw, Copy, ExternalLink, Link2, Link2Off, Mail, ChevronDown, ChevronUp } from 'lucide-react';
import {
  DeviceCode,
  DriveConfig,
  isDriveLinked,
  loadDriveConfig,
  pollDeviceLink,
  saveDriveConfig,
  startDeviceLink,
  unlinkDrive,
} from '../utils/googleDrive';
import { DRIVE_SYNC_NOW_EVENT } from './DriveAutoSync';

const inputCls =
  'w-full bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-lg px-3 py-2 text-sm text-slate-800 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-sky-500';

export const DriveCloudSyncPanel: React.FC = () => {
  const [cfg, setCfg] = useState<DriveConfig>(loadDriveConfig());
  const [busy, setBusy] = useState(false);
  const [device, setDevice] = useState<DeviceCode | null>(null);
  const [linking, setLinking] = useState(false);
  const [error, setError] = useState('');
  const [help, setHelp] = useState(false);
  const [clientId, setClientId] = useState(cfg.clientId);
  const [clientSecret, setClientSecret] = useState(cfg.clientSecret);
  const [notify, setNotify] = useState(cfg.notifyEmail || '');
  const cancelRef = useRef(false);

  useEffect(() => {
    const refresh = () => setCfg(loadDriveConfig());
    const onBusy = (e: Event) => setBusy(!!(e as CustomEvent).detail);
    window.addEventListener('qasr-drive-status', refresh);
    window.addEventListener('qasr-drive-busy', onBusy);
    return () => {
      window.removeEventListener('qasr-drive-status', refresh);
      window.removeEventListener('qasr-drive-busy', onBusy);
      cancelRef.current = true;
    };
  }, []);

  const linked = isDriveLinked(cfg);

  const beginLink = useCallback(async () => {
    setError('');
    if (!clientId.trim() || !clientSecret.trim()) return setError('أدخل معرّف العميل (Client ID) والسرّ (Client Secret).');
    if (!navigator.onLine) return setError('يلزم اتصال بالإنترنت لإتمام الربط لأول مرة.');
    saveDriveConfig({ clientId: clientId.trim(), clientSecret: clientSecret.trim() });
    setLinking(true);
    cancelRef.current = false;
    try {
      const d = await startDeviceLink(clientId);
      setDevice(d);
      let wait = Math.max(5, d.interval || 5) * 1000;
      const deadline = Date.now() + d.expires_in * 1000;
      while (!cancelRef.current && Date.now() < deadline) {
        await new Promise((r) => setTimeout(r, wait));
        if (cancelRef.current) return;
        const res = await pollDeviceLink(d.device_code);
        if (res === 'ok') {
          setDevice(null);
          window.dispatchEvent(new CustomEvent(DRIVE_SYNC_NOW_EVENT));
          return;
        }
        if (res === 'slow') wait += 5000;
        if (res === 'denied') throw new Error('تم رفض الطلب من حساب Google.');
        if (res === 'expired') break;
      }
      if (!cancelRef.current) throw new Error('انتهت مهلة الرمز، حاول من جديد.');
    } catch (e) {
      setError(e instanceof Error ? e.message : 'فشل الربط.');
      setDevice(null);
    } finally {
      setLinking(false);
    }
  }, [clientId, clientSecret]);

  const cancelLink = () => {
    cancelRef.current = true;
    setDevice(null);
    setLinking(false);
  };

  return (
    <div className="rounded-2xl border-2 border-emerald-300 dark:border-emerald-800 bg-emerald-50/40 dark:bg-emerald-950/20 p-4 space-y-3" dir="rtl">
      <div className="flex items-center justify-between gap-2">
        <h3 className="font-bold text-slate-800 dark:text-slate-100 flex items-center gap-2 text-sm sm:text-base">
          <Cloud className="w-5 h-5 text-emerald-600" />
          المزامنة التلقائية مع Google Drive
        </h3>
        {linked ? (
          <span className="px-2 py-0.5 rounded-full bg-emerald-600 text-white text-[11px] font-bold flex items-center gap-1">
            <CheckCircle2 className="w-3.5 h-3.5" /> مرتبط
          </span>
        ) : (
          <span className="px-2 py-0.5 rounded-full bg-slate-200 dark:bg-slate-700 text-slate-600 dark:text-slate-300 text-[11px] font-bold">غير مرتبط</span>
        )}
      </div>

      {error && (
        <div className="p-2.5 rounded-lg bg-rose-50 dark:bg-rose-950/40 text-rose-700 dark:text-rose-300 text-xs flex items-start gap-2" role="alert">
          <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" /> <span>{error}</span>
        </div>
      )}

      {!linked && !device && (
        <div className="space-y-2.5 text-xs">
          <button type="button" onClick={() => setHelp((v) => !v)} className="flex items-center gap-1 text-sky-700 dark:text-sky-300 font-semibold cursor-pointer">
            {help ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />} كيف أحصل على Client ID و Client Secret؟
          </button>
          {help && (
            <ol className="list-decimal pr-5 space-y-1 text-slate-600 dark:text-slate-300 leading-relaxed">
              <li>افتح console.cloud.google.com بحسابك على Gmail وأنشئ مشروعاً جديداً.</li>
              <li>من «APIs &amp; Services ← Library» فعّل <b>Google Drive API</b>.</li>
              <li>من «OAuth consent screen»: اختر External، واملأ الاسم والبريد، ثم اضغط <b>Publish app</b> ليصبح In production (وإلا تنتهي صلاحية الربط بعد 7 أيام).</li>
              <li>من «Credentials ← Create credentials ← OAuth client ID» اختر النوع <b>TVs and Limited Input devices</b>.</li>
              <li>انسخ <b>Client ID</b> و<b>Client secret</b> والصقهما أدناه.</li>
            </ol>
          )}
          <input className={inputCls} placeholder="Client ID" value={clientId} onChange={(e) => setClientId(e.target.value)} dir="ltr" autoComplete="off" />
          <input className={inputCls} placeholder="Client secret" value={clientSecret} onChange={(e) => setClientSecret(e.target.value)} dir="ltr" autoComplete="off" />
          <button
            type="button"
            onClick={beginLink}
            disabled={linking}
            className="w-full flex items-center justify-center gap-2 bg-emerald-600 hover:bg-emerald-500 text-white py-2.5 rounded-xl font-bold text-sm cursor-pointer disabled:opacity-50"
          >
            <Link2 className="w-4 h-4" /> ربط حساب Google
          </button>
        </div>
      )}

      {device && (
        <div className="space-y-3 text-center">
          <p className="text-xs text-slate-600 dark:text-slate-300">١) افتح الرابط التالي وسجّل الدخول بحساب Gmail الخاص بك، ثم أدخل الرمز:</p>
          <a
            href={device.verification_url}
            target="_blank"
            rel="noreferrer"
            className="inline-flex items-center gap-1.5 text-sky-700 dark:text-sky-300 font-bold underline text-sm"
          >
            <ExternalLink className="w-4 h-4" /> {device.verification_url}
          </a>
          <div className="flex items-center justify-center gap-2">
            <div className="font-mono text-2xl sm:text-3xl font-black tracking-widest bg-white dark:bg-slate-900 border-2 border-dashed border-emerald-400 rounded-xl px-4 py-2" dir="ltr">
              {device.user_code}
            </div>
            <button
              type="button"
              onClick={() => navigator.clipboard?.writeText(device.user_code)}
              className="p-2 rounded-lg bg-slate-100 dark:bg-slate-800 cursor-pointer"
              aria-label="نسخ الرمز"
            >
              <Copy className="w-4 h-4" />
            </button>
          </div>
          <p className="text-[11px] text-slate-500 flex items-center justify-center gap-1.5">
            <RefreshCw className="w-3.5 h-3.5 animate-spin" /> بانتظار موافقتك… سيكتمل الربط تلقائياً
          </p>
          <button type="button" onClick={cancelLink} className="text-xs text-slate-500 underline cursor-pointer">
            إلغاء
          </button>
        </div>
      )}

      {linked && (
        <div className="space-y-3 text-xs">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
            <div className="p-2.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800">
              <div className="text-slate-400">الحساب</div>
              <div className="font-bold text-slate-800 dark:text-slate-100 break-all" dir="ltr">{cfg.email || 'حساب Google'}</div>
            </div>
            <div className="p-2.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800">
              <div className="text-slate-400">آخر مزامنة</div>
              <div className="font-bold text-slate-800 dark:text-slate-100">{cfg.lastSyncAt || 'لم تتم بعد'}</div>
            </div>
          </div>

          {cfg.lastError && (
            <div className="p-2.5 rounded-lg bg-amber-50 dark:bg-amber-950/40 text-amber-800 dark:text-amber-300 flex items-start gap-2">
              <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" /> <span>آخر محاولة: {cfg.lastError}</span>
            </div>
          )}

          <label className="flex items-center gap-2 cursor-pointer">
            <input
              type="checkbox"
              className="w-4 h-4 accent-emerald-600"
              checked={cfg.autoSync}
              onChange={(e) => saveDriveConfig({ autoSync: e.target.checked })}
            />
            <span className="font-semibold text-slate-700 dark:text-slate-200">مزامنة تلقائية بعد كل تغيير (عند توفر الإنترنت)</span>
          </label>

          <div>
            <label className="block text-slate-500 mb-1 flex items-center gap-1">
              <Mail className="w-3.5 h-3.5" /> إشعار بريدي يومي بالأرشيف (اختياري — بريد مختلف عن حساب Drive)
            </label>
            <div className="flex gap-2">
              <input className={inputCls} type="email" dir="ltr" placeholder="example@gmail.com" value={notify} onChange={(e) => setNotify(e.target.value)} />
              <button
                type="button"
                onClick={() => saveDriveConfig({ notifyEmail: notify.trim() || undefined })}
                className="px-3 rounded-lg bg-sky-600 text-white font-semibold cursor-pointer"
              >
                حفظ
              </button>
            </div>
          </div>

          <div className="flex flex-wrap gap-2">
            <button
              type="button"
              disabled={busy}
              onClick={() => window.dispatchEvent(new CustomEvent(DRIVE_SYNC_NOW_EVENT))}
              className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold cursor-pointer disabled:opacity-50"
            >
              <RefreshCw className={`w-4 h-4 ${busy ? 'animate-spin' : ''}`} /> {busy ? 'جارٍ المزامنة…' : 'مزامنة الآن'}
            </button>
            <button
              type="button"
              onClick={() => {
                if (confirm('فك ربط حساب Google؟ لن تُحذف الملفات من Drive.')) unlinkDrive();
              }}
              className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-rose-50 dark:bg-rose-950/40 text-rose-700 dark:text-rose-300 font-semibold cursor-pointer"
            >
              <Link2Off className="w-4 h-4" /> فك الربط
            </button>
          </div>

          <p className="text-[11px] text-slate-500 leading-relaxed">
            يُنشأ مجلد «قصر الصداقة - الأرشيف» في Drive يحوي: <b>latest-backup.json</b> (آخر نسخة كاملة)، و<b>system-log.csv</b> (سجل النظام كاملاً)،
            وملف أرشيف يومي <b>archive-التاريخ.json</b>. للاستعادة: حمّل أي ملف JSON واستورده من إعدادات النظام.
          </p>
        </div>
      )}
    </div>
  );
};
