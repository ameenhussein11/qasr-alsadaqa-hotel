import React, { useState } from 'react';
import { useHotel } from '../context/HotelContext';
import { Guest } from '../types/hotel';
import { ImagePicker } from './ImagePicker';
import { guestHosting } from '../utils/hosting';
import {
  Users,
  Search,
  Sparkles,
  Phone,
  Shield,
  Calendar,
  CreditCard,
  Star,
  Download,
  Plus,
  X,
  Clock,
  CheckCircle,
  FileText,
  UserCheck,
  Bed,
  Trash2,
  AlertTriangle,
  Receipt,
  FileDown,
  IdCard,
  MessageSquare,
} from 'lucide-react';

export const GuestList: React.FC = () => {
  const {
    guests,
    bookings,
    settings,
    toggleVipGuest,
    addGuest,
    deleteGuest,
    exportGuestsCsv,
    exportGuestsPdf,
    openSmsComposer,
    updateGuest,
    setSelectedGuestForStatement,
    setIsLinkGuestModalOpen,
    setPreselectedGuestForLink,
  } = useHotel();

  const [guestSearch, setGuestSearch] = useState<string>('');
  const [filterType, setFilterType] = useState<'all' | 'frequent' | 'vip'>('all');
  const [selectedGuestHistory, setSelectedGuestHistory] = useState<Guest | null>(null);
  const [isAddGuestModalOpen, setIsAddGuestModalOpen] = useState<boolean>(false);
  const [deleteConfirmId, setDeleteConfirmId] = useState<number | null>(null);
  const [deleteError, setDeleteError] = useState<string>('');

  // New Guest Form State
  const [newName, setNewName] = useState<string>('');
  const [newPhone, setNewPhone] = useState<string>('');
  const [newNationalId, setNewNationalId] = useState<string>('');
  const [newNationality, setNewNationality] = useState<string>('يمني');
  const [newIsVip, setNewIsVip] = useState<boolean>(false);
  const [newNotes, setNewNotes] = useState<string>('');
  const [newPhoto, setNewPhoto] = useState<string | undefined>();
  const [newIdImage, setNewIdImage] = useState<string | undefined>();
  const [photoEditGuest, setPhotoEditGuest] = useState<Guest | null>(null);
  const [viewImage, setViewImage] = useState<string | null>(null);

  // Filtered Guests
  const filteredGuests = guests.filter((guest) => {
    if (filterType === 'frequent' && !guest.isFrequent) return false;
    if (filterType === 'vip' && !guest.isVip) return false;

    if (guestSearch.trim()) {
      const q = guestSearch.toLowerCase().trim();
      const matchName = guest.name.toLowerCase().includes(q);
      const matchPhone = guest.phone.includes(q);
      const matchId = guest.nationalId.includes(q);
      if (!matchName && !matchPhone && !matchId) return false;
    }
    return true;
  });

  const handleAddGuestSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newName.trim() || !newPhone.trim()) return;

    addGuest({
      name: newName.trim(),
      phone: newPhone.trim(),
      nationalId: newNationalId.trim(),
      nationality: newNationality.trim(),
      isVip: newIsVip,
      notes: newNotes.trim() || undefined,
      photo: newPhoto,
      idImage: newIdImage,
    });

    setNewName('');
    setNewPhone('');
    setNewNationalId('');
    setNewNationality('يمني');
    setNewIsVip(false);
    setNewNotes('');
    setNewPhoto(undefined);
    setNewIdImage(undefined);
    setIsAddGuestModalOpen(false);
  };

  const handleDelete = (guestId: number) => {
    setDeleteError('');
    const res = deleteGuest(guestId);
    if (res.success) {
      setDeleteConfirmId(null);
    } else {
      setDeleteError(res.error || 'تعذر حذف العميل.');
    }
  };

  const getGuestBookings = (guestId: number) => {
    return bookings.filter((b) => b.guestId === guestId);
  };

  return (
    <div className="space-y-4">
      {/* Top Toolbar */}
      <div className="bg-white dark:bg-slate-900 p-4 rounded-xl border border-slate-200 dark:border-slate-800 shadow-sm flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        {/* Search Input */}
        <div className="relative flex-1 max-w-md">
          <input
            type="text"
            placeholder="بحث بالاسم، رقم الهاتف أو الهوية..."
            value={guestSearch}
            onChange={(e) => setGuestSearch(e.target.value)}
            className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs rounded-xl pl-3 pr-9 py-2 text-slate-800 dark:text-slate-200 placeholder-slate-400 focus:outline-none focus:border-emerald-500"
          />
          <Search className="w-4 h-4 text-slate-400 absolute right-3 top-2.5" />
        </div>

        {/* Filter Pills & Actions */}
        <div className="flex items-center gap-2 flex-wrap">
          <div className="flex items-center bg-slate-100 dark:bg-slate-800 p-1 rounded-xl text-xs">
            <button
              onClick={() => setFilterType('all')}
              className={`px-3 py-1.5 rounded-lg font-medium transition cursor-pointer ${
                filterType === 'all'
                  ? 'bg-white dark:bg-slate-700 text-slate-900 dark:text-white shadow-xs'
                  : 'text-slate-500 hover:text-slate-800 dark:hover:text-slate-200'
              }`}
            >
              الكل ({guests.length})
            </button>
            <button
              onClick={() => setFilterType('frequent')}
              className={`px-3 py-1.5 rounded-lg font-medium transition cursor-pointer flex items-center gap-1 ${
                filterType === 'frequent'
                  ? 'bg-amber-500 text-white shadow-xs'
                  : 'text-slate-500 hover:text-slate-800 dark:hover:text-slate-200'
              }`}
            >
              <Sparkles className="w-3.5 h-3.5" />
              <span>عملاء دائمين ({guests.filter((g) => g.isFrequent).length})</span>
            </button>
            <button
              onClick={() => setFilterType('vip')}
              className={`px-3 py-1.5 rounded-lg font-medium transition cursor-pointer flex items-center gap-1 ${
                filterType === 'vip'
                  ? 'bg-indigo-600 text-white shadow-xs'
                  : 'text-slate-500 hover:text-slate-800 dark:hover:text-slate-200'
              }`}
            >
              <Star className="w-3.5 h-3.5" />
              <span>VIP ({guests.filter((g) => g.isVip).length})</span>
            </button>
          </div>

          <button
            onClick={() => exportGuestsPdf()}
            title="تصدير سجل النزلاء PDF بالعربية"
            className="px-3 py-2 bg-rose-50 dark:bg-rose-950/40 hover:bg-rose-100 text-rose-700 dark:text-rose-300 rounded-xl text-xs font-bold flex items-center gap-1.5 transition cursor-pointer"
          >
            <FileDown className="w-3.5 h-3.5" />
            <span className="hidden md:inline">تصدير PDF</span>
          </button>

          <button
            onClick={exportGuestsCsv}
            title="تصدير السجل إلى ملف Excel / CSV"
            className="px-3 py-2 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition cursor-pointer border border-slate-200 dark:border-slate-700"
          >
            <Download className="w-3.5 h-3.5" />
            <span className="hidden md:inline">تصدير CSV</span>
          </button>

          <button
            onClick={() => setIsAddGuestModalOpen(true)}
            className="px-3.5 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 transition cursor-pointer shadow-sm"
          >
            <Plus className="w-4 h-4" />
            <span>+ إضافة عميل</span>
          </button>
        </div>
      </div>

      {deleteError && (
        <div className="p-3 rounded-xl bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-900/60 text-xs text-rose-700 dark:text-rose-300 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <AlertTriangle className="w-4 h-4 shrink-0 text-rose-500" />
            <span>{deleteError}</span>
          </div>
          <button onClick={() => setDeleteError('')} className="text-slate-400 hover:text-slate-600">
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      )}

      {/* Guests Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filteredGuests.map((guest) => {
          const guestBookings = getGuestBookings(guest.id);
          const hasActiveStay = guestBookings.some((b) => b.isActive);
          const isConfirming = deleteConfirmId === guest.id;

          return (
            <div
              key={guest.id}
              className={`bg-white dark:bg-slate-900 border rounded-2xl p-4 shadow-sm hover:shadow-md transition space-y-3 flex flex-col justify-between ${
                guest.isVip
                  ? 'border-indigo-300 dark:border-indigo-900/60 bg-linear-to-b from-indigo-50/20 to-transparent'
                  : guest.isFrequent
                  ? 'border-amber-300 dark:border-amber-900/60 bg-linear-to-b from-amber-50/20 to-transparent'
                  : 'border-slate-200 dark:border-slate-800'
              }`}
            >
              <div>
                {/* Header Row */}
                <div className="flex items-start justify-between gap-2">
                  <div className="flex items-center gap-2.5">
                    <button
                      type="button"
                      onClick={() => setPhotoEditGuest(guest)}
                      title="صورة النزيل والهوية"
                      className={`w-12 h-12 shrink-0 rounded-full overflow-hidden flex items-center justify-center font-bold text-sm shadow-xs cursor-pointer ${
                        guest.isVip
                          ? 'bg-indigo-600 text-white'
                          : guest.isFrequent
                          ? 'bg-amber-500 text-white'
                          : 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300'
                      }`}
                    >
                      {guest.photo ? (
                        <img src={guest.photo} alt={guest.name} className="w-full h-full object-cover" />
                      ) : (
                        guest.name.charAt(0)
                      )}
                    </button>
                    <div>
                      <h3 className="font-bold text-slate-900 dark:text-white text-sm leading-tight flex items-center gap-1.5">
                        {guest.name}
                        {guest.isFrequent && (
                          <span
                            title="عميل مستمر (Loyalty Member)"
                            className="px-1.5 py-0.2 rounded bg-amber-500/20 text-amber-600 dark:text-amber-300 text-[10px] font-bold border border-amber-500/30 inline-flex items-center gap-0.5"
                          >
                            <Sparkles className="w-2.5 h-2.5" />
                            دائم
                          </span>
                        )}
                        {hasActiveStay && (
                          <span className="px-1.5 py-0.2 rounded bg-rose-500/20 text-rose-600 text-[10px] font-bold">
                            مقيم حالياً
                          </span>
                        )}
                      </h3>
                      <span className="text-[11px] text-slate-400">{guest.nationality || 'يمني'}</span>
                    </div>
                  </div>

                  <div className="flex items-center gap-1">
                    <button
                      onClick={() => toggleVipGuest(guest.id)}
                      title={guest.isVip ? 'إلغاء صفة VIP' : 'تعيين كـ VIP'}
                      className={`p-1.5 rounded-lg border transition cursor-pointer ${
                        guest.isVip
                          ? 'bg-indigo-500 text-white border-indigo-500'
                          : 'bg-slate-50 dark:bg-slate-800 text-slate-400 border-slate-200 dark:border-slate-700 hover:text-amber-500'
                      }`}
                    >
                      <Star className="w-3.5 h-3.5 fill-current" />
                    </button>

                    {/* Delete customer button */}
                    {isConfirming ? (
                      <div className="flex items-center gap-1">
                        <button
                          onClick={() => setDeleteConfirmId(null)}
                          className="px-1.5 py-0.5 text-slate-400 hover:bg-slate-100 rounded text-[10px]"
                        >
                          إلغاء
                        </button>
                        <button
                          onClick={() => handleDelete(guest.id)}
                          className="px-2 py-0.5 bg-rose-600 hover:bg-rose-500 text-white rounded text-[10px] font-bold"
                        >
                          حذف
                        </button>
                      </div>
                    ) : (
                      <button
                        onClick={() => {
                          if (hasActiveStay) {
                            setDeleteError(
                              `لا يمكن حذف العميل (${guest.name}) لأنه يقيم حالياً في الفندق.`
                            );
                          } else {
                            setDeleteConfirmId(guest.id);
                          }
                        }}
                        disabled={hasActiveStay}
                        title={hasActiveStay ? 'لا يمكن حذف نزيل مقيم' : 'حذف العميل'}
                        className={`p-1.5 rounded-lg border border-transparent transition cursor-pointer ${
                          hasActiveStay
                            ? 'text-slate-300 dark:text-slate-700 cursor-not-allowed'
                            : 'text-slate-400 hover:text-rose-500 hover:bg-rose-50 dark:hover:bg-rose-950/40'
                        }`}
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    )}
                  </div>
                </div>

                {/* Details Grid */}
                <div className="mt-3 grid grid-cols-2 gap-2 text-xs text-slate-600 dark:text-slate-400 bg-slate-50 dark:bg-slate-800/40 p-2.5 rounded-xl border border-slate-100 dark:border-slate-800">
                  <div className="flex items-center gap-1.5">
                    <Phone className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                    <a
                      href={`tel:${guest.phone}`}
                      className="font-mono text-emerald-600 dark:text-emerald-400 hover:underline truncate"
                    >
                      {guest.phone}
                    </a>
                  </div>

                  <div className="flex items-center gap-1.5">
                    <Shield className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                    <span className="font-mono truncate">{guest.nationalId || '—'}</span>
                  </div>

                  <div className="flex items-center gap-1.5">
                    <Users className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                    <span>
                      الزيارات: <strong>{guest.visitCount}</strong>
                    </span>
                  </div>

                  <div className="flex items-center gap-1.5">
                    <Clock className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                    <span>
                      {(() => {
                        const h = guestHosting(guest.id, bookings);
                        if (h.current) {
                          return (
                            <>
                              مقيم في الغرفة <strong>{h.current.roomNumber}</strong> منذ <strong>{h.current.checkInDate}</strong> ({h.currentDays}{' '}
                              {h.currentDays === 1 ? 'يوم' : 'أيام'}) • الإجمالي <strong>{h.totalNights}</strong> ليلة
                            </>
                          );
                        }
                        if (h.lastStay) {
                          return (
                            <>
                              الغرفة <strong>{h.lastStay.room}</strong> • من <strong>{h.lastStay.from}</strong> إلى <strong>{h.lastStay.to}</strong> (
                              {h.lastStay.nights} ليالٍ) • الإجمالي <strong>{h.totalNights}</strong> ليلة
                            </>
                          );
                        }
                        return <>لا توجد استضافة مسجلة بعد</>;
                      })()}
                    </span>
                  </div>
                </div>

                {/* Loyalty Discount Note */}
                {guest.loyaltyDiscountPercent > 0 && (
                  <div className="mt-2 text-[11px] text-amber-700 dark:text-amber-300 bg-amber-50 dark:bg-amber-950/30 px-2.5 py-1 rounded-lg border border-amber-200 dark:border-amber-900/50 flex items-center justify-between">
                    <span>خصم الولاء التلقائي:</span>
                    <strong className="font-mono">{guest.loyaltyDiscountPercent}%</strong>
                  </div>
                )}

                {/* Notes if any */}
                {guest.notes && (
                  <p className="mt-2 text-[11px] text-slate-500 italic line-clamp-1 bg-slate-100 dark:bg-slate-800/60 px-2 py-0.5 rounded">
                    📌 {guest.notes}
                  </p>
                )}
              </div>

              {/* Action Buttons Row */}
              <div className="pt-3 border-t border-slate-100 dark:border-slate-800 space-y-2">
                <div className="grid grid-cols-2 gap-1.5">
                  {/* SMS to the customer */}
                {guest.phone && (
                  <button
                    onClick={() => openSmsComposer({ guestId: guest.id, templateId: 'general' })}
                    className="col-span-2 py-1.5 px-2 bg-sky-50 dark:bg-sky-950/40 hover:bg-sky-100 text-sky-700 dark:text-sky-300 rounded-lg text-xs font-bold transition flex items-center justify-center gap-1.5 cursor-pointer"
                    title="إرسال رسالة SMS لهذا العميل"
                  >
                    <MessageSquare className="w-3.5 h-3.5" />
                    <span>رسالة SMS</span>
                  </button>
                )}

                {/* Account Statement Button */}
                  <button
                    onClick={() => setSelectedGuestForStatement(guest)}
                    className="py-1.5 px-2 bg-slate-900 dark:bg-slate-800 hover:bg-slate-800 text-white rounded-lg text-xs font-bold transition flex items-center justify-center gap-1 cursor-pointer shadow-xs"
                    title="عرض كشف حساب العميل والمدفوعات والمستحقات"
                  >
                    <FileText className="w-3.5 h-3.5 text-emerald-400" />
                    <span>كشف الحساب</span>
                  </button>

                  {/* Link / Check in to Room Button */}
                  <button
                    onClick={() => {
                      setPreselectedGuestForLink(guest);
                      setIsLinkGuestModalOpen(true);
                    }}
                    className="py-1.5 px-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg text-xs font-bold transition flex items-center justify-center gap-1 cursor-pointer shadow-xs"
                    title="ربط العميل بغرفة متاحة وتسكينه فوراً"
                  >
                    <Bed className="w-3.5 h-3.5" />
                    <span>ربط بغرفة</span>
                  </button>
                </div>

                <div className="flex items-center justify-between text-xs pt-1">
                  <span className="text-[10px] text-slate-400">
                    آخر نشاط: {guest.lastVisitDate || guest.createdAt}
                  </span>

                  <button
                    onClick={() => setSelectedGuestHistory(guest)}
                    className="text-emerald-600 dark:text-emerald-400 font-semibold hover:underline flex items-center gap-1 text-[11px] cursor-pointer"
                  >
                    <Clock className="w-3 h-3" />
                    <span>سجل الإقامات ({guestBookings.length})</span>
                  </button>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Guest Stay History Modal */}
      {selectedGuestHistory && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-xs animate-fadeIn">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl w-full max-w-xl max-h-[85vh] overflow-y-auto shadow-2xl p-5 space-y-4">
            <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3">
              <div>
                <h3 className="font-bold text-slate-900 dark:text-white text-base">
                  سجل إقامات النزيل: {selectedGuestHistory.name}
                </h3>
                <p className="text-xs text-slate-400">
                  إجمالي الزيارات: {selectedGuestHistory.visitCount} • مدة الاستضافة:{' '}
                  {guestHosting(selectedGuestHistory.id, bookings).totalNights} ليلة
                </p>
              </div>
              <button
                onClick={() => setSelectedGuestHistory(null)}
                className="p-1.5 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 rounded-lg hover:bg-slate-100"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-2 text-xs">
              {getGuestBookings(selectedGuestHistory.id).length === 0 ? (
                <div className="p-8 text-center text-slate-400 border border-dashed rounded-xl">
                  لا توجد سجلات سابقة مسجلة لهذا النزيل بعد
                </div>
              ) : (
                getGuestBookings(selectedGuestHistory.id).map((b) => (
                  <div
                    key={b.id}
                    className="p-3 bg-slate-50 dark:bg-slate-800/40 rounded-xl border border-slate-200 dark:border-slate-700/60 space-y-1.5"
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <span className="font-mono font-bold text-emerald-600 dark:text-emerald-400">
                          {b.bookingCode}
                        </span>
                        <span className="font-bold text-slate-800 dark:text-slate-200">
                          غرفة #{b.roomNumber}
                        </span>
                      </div>
                      <span
                        className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                          b.isActive
                            ? 'bg-rose-500/20 text-rose-600 dark:text-rose-400'
                            : 'bg-emerald-500/20 text-emerald-600 dark:text-emerald-400'
                        }`}
                      >
                        {b.isActive ? 'إقامة نشطة حالياً' : 'مكتمل ومغادر'}
                      </span>
                    </div>

                    <div className="flex items-center justify-between text-slate-500 text-[11px]">
                      <span>
                        من {b.checkInDate.substring(0, 10)} إلى {b.expectedCheckOutDate.substring(0, 10)} ({b.nights} ليالي)
                      </span>
                      <span className="font-bold font-mono text-slate-900 dark:text-white">
                        {b.totalAmount} {settings.currencySymbol}
                      </span>
                    </div>
                  </div>
                ))
              )}
            </div>

            <div className="pt-2 flex justify-end gap-2">
              <button
                onClick={() => {
                  setSelectedGuestForStatement(selectedGuestHistory);
                  setSelectedGuestHistory(null);
                }}
                className="px-4 py-2 bg-emerald-600 text-white rounded-xl text-xs font-bold"
              >
                فتح كشف الحساب الكامل
              </button>

              <button
                onClick={() => setSelectedGuestHistory(null)}
                className="px-4 py-2 bg-slate-200 dark:bg-slate-800 text-slate-700 dark:text-slate-300 rounded-xl text-xs font-semibold"
              >
                إغلاق
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Add New Guest Modal */}
      {isAddGuestModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-xs animate-fadeIn">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl w-full max-w-md shadow-2xl p-5 space-y-4">
            <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3">
              <h3 className="font-bold text-slate-900 dark:text-white text-base">إضافة عميل جديد لقاعدة البيانات</h3>
              <button
                onClick={() => setIsAddGuestModalOpen(false)}
                className="p-1.5 text-slate-400 hover:text-slate-600 rounded-lg hover:bg-slate-100"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleAddGuestSubmit} className="space-y-3 text-xs">
              <div>
                <label className="block text-slate-600 dark:text-slate-400 mb-1">
                  اسم العميل: <span className="text-rose-500">*</span>
                </label>
                <input
                  type="text"
                  required
                  value={newName}
                  onChange={(e) => setNewName(e.target.value)}
                  placeholder="الاسم الكامل"
                  className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg px-3 py-2 text-slate-900 dark:text-white focus:outline-none focus:border-emerald-500"
                />
              </div>

              <div>
                <label className="block text-slate-600 dark:text-slate-400 mb-1">
                  رقم الهاتف: <span className="text-rose-500">*</span>
                </label>
                <input
                  type="tel"
                  required
                  value={newPhone}
                  onChange={(e) => setNewPhone(e.target.value)}
                  placeholder="05xxxxxxxx"
                  className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg px-3 py-2 text-slate-900 dark:text-white font-mono focus:outline-none focus:border-emerald-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-slate-600 dark:text-slate-400 mb-1">رقم الهوية / الإقامة:</label>
                  <input
                    type="text"
                    value={newNationalId}
                    onChange={(e) => setNewNationalId(e.target.value)}
                    placeholder="10xxxxxxxx"
                    className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg px-3 py-2 text-slate-900 dark:text-white font-mono focus:outline-none focus:border-emerald-500"
                  />
                </div>

                <div>
                  <label className="block text-slate-600 dark:text-slate-400 mb-1">الجنسية:</label>
                  <input
                    type="text"
                    value={newNationality}
                    onChange={(e) => setNewNationality(e.target.value)}
                    placeholder="يمني"
                    className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg px-3 py-2 text-slate-900 dark:text-white focus:outline-none focus:border-emerald-500"
                  />
                </div>
              </div>

              <div className="flex items-start justify-center gap-6 py-1">
                <ImagePicker label="صورة شخصية" value={newPhoto} onChange={setNewPhoto} round maxSide={320} />
                <ImagePicker label="صورة الهوية" value={newIdImage} onChange={setNewIdImage} maxSide={720} />
              </div>

              <div className="flex items-center gap-2 pt-1">
                <input
                  type="checkbox"
                  id="newIsVipCheck"
                  checked={newIsVip}
                  onChange={(e) => setNewIsVip(e.target.checked)}
                  className="w-4 h-4 accent-amber-500 cursor-pointer"
                />
                <label htmlFor="newIsVipCheck" className="text-slate-700 dark:text-slate-300 font-semibold cursor-pointer">
                  تصنيف النزيل كـ عميل مميز VIP
                </label>
              </div>

              <div>
                <label className="block text-slate-600 dark:text-slate-400 mb-1">ملاحظات العميل:</label>
                <input
                  type="text"
                  value={newNotes}
                  onChange={(e) => setNewNotes(e.target.value)}
                  placeholder="تفضيلات الغرف، ملاحظات خاصة..."
                  className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg px-3 py-2 text-slate-900 dark:text-white focus:outline-none focus:border-emerald-500"
                />
              </div>

              <div className="pt-2 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsAddGuestModalOpen(false)}
                  className="px-3 py-2 text-slate-500 hover:bg-slate-100 rounded-lg"
                >
                  إلغاء
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg font-bold transition"
                >
                  حفظ العميل
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {photoEditGuest && (() => {
        const g = guests.find((x) => x.id === photoEditGuest.id) || photoEditGuest;
        return (
          <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4" dir="rtl">
            <div className="bg-white dark:bg-slate-900 rounded-3xl p-5 w-full max-w-sm border border-slate-200 dark:border-slate-800 shadow-2xl space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="font-bold text-slate-800 dark:text-slate-100 flex items-center gap-2">
                  <IdCard className="w-5 h-5 text-sky-500" /> صور النزيل: {g.name}
                </h3>
                <button onClick={() => setPhotoEditGuest(null)} className="p-1 text-slate-400 cursor-pointer">
                  <X className="w-5 h-5" />
                </button>
              </div>
              <div className="flex items-start justify-center gap-6">
                <ImagePicker label={g.photo ? 'تغيير الصورة' : 'صورة شخصية'} value={g.photo} onChange={(v) => updateGuest(g.id, { photo: v })} round maxSide={320} />
                <ImagePicker label={g.idImage ? 'تغيير الهوية' : 'صورة الهوية'} value={g.idImage} onChange={(v) => updateGuest(g.id, { idImage: v })} maxSide={720} />
              </div>
              {(g.photo || g.idImage) && (
                <div className="flex gap-2 justify-center">
                  {g.idImage && (
                    <button onClick={() => setViewImage(g.idImage!)} className="px-3 py-1.5 rounded-lg bg-sky-50 dark:bg-sky-950/40 text-sky-700 dark:text-sky-300 text-xs font-semibold cursor-pointer">
                      عرض الهوية بالحجم الكامل
                    </button>
                  )}
                  {g.photo && (
                    <button onClick={() => setViewImage(g.photo!)} className="px-3 py-1.5 rounded-lg bg-sky-50 dark:bg-sky-950/40 text-sky-700 dark:text-sky-300 text-xs font-semibold cursor-pointer">
                      عرض الصورة
                    </button>
                  )}
                </div>
              )}
            </div>
          </div>
        );
      })()}

      {viewImage && (
        <div className="fixed inset-0 z-[60] bg-black/90 flex items-center justify-center p-4" onClick={() => setViewImage(null)}>
          <img src={viewImage} alt="" className="max-w-full max-h-full rounded-xl" />
        </div>
      )}
    </div>
  );
};
