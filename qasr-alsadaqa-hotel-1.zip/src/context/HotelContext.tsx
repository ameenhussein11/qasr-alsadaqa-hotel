import React, { createContext, useContext, useState, useEffect, useCallback, useMemo, useRef } from 'react';
import {
  Room,
  Guest,
  Booking,
  HousekeepingTask,
  Payment,
  ActivityLog,
  HotelSettings,
  HotelNotification,
  RoomStatus,
  CleaningPriority,
  PaymentMethod,
  RoomServiceItem,
  RoomServiceOrder,
  RoomServiceOrderStatus,
  ActiveTab,
  ExpenseRecord,
  OtherRevenueRecord,
  StaffMember,
  StaffSalaryRecord,
  SystemUser,
  GoogleAccountLink,
  AutoBackupConfig,
  BackupSnapshot,
  FutureReservation,
  Companion,
} from '../types/hotel';
import { SqliteEngine, QueryResult } from '../db/sqliteEngine';
import {
  initialRooms,
  initialGuests,
  initialBookings,
  initialHousekeeping,
  initialSettings,
  initialPayments,
  initialLogs,
  initialRoomServiceMenu,
  initialRoomServiceOrders,
  initialStaffMembers,
  initialStaffSalaries,
  initialExpenses,
  initialOtherRevenues,
  initialSystemUser,
  initialGoogleAccounts,
  initialAutoBackupConfig,
  initialBackupSnapshots,
} from '../db/initialData';
import confetti from 'canvas-confetti';
import { saveText } from '../utils/saveFile';
import { exportArabicPdf, money, paymentMethodAr, loadImg } from '../utils/arabicPdf';
import { guestHosting } from '../utils/hosting';
import { saveImage, deleteImage } from '../utils/imageStore';
import type { CustodyItem, SmsLogEntry, SmsDraft } from '../types/custody';
import { computeFigures } from '../utils/closing';
import { periodFor, CLOSING_TYPE_AR } from '../utils/periods';
import type { ClosingRecord, ClosingType } from '../types/archive';
import { hasPin } from '../utils/pin';
import { localDate, localDateTime, localDateTimeSec, addDaysToDateStr, uid, generateBookingCode } from '../utils/dates';

interface CheckInData {
  roomId: number;
  guestName: string;
  guestPhone: string;
  guestNationalId: string;
  nationality: string;
  nights: number;
  pricePerNight: number;
  discountPercent: number;
  paidAmount: number;
  paymentMethod: PaymentMethod;
  notes?: string;
  companions?: Companion[];
  /** set when converting an advance reservation, so it does not conflict with itself */
  ignoreReservationId?: number;
}

export interface NewReservationInput {
  roomId: number;
  guestName: string;
  guestPhone: string;
  guestNationalId?: string;
  nationality?: string;
  arrivalDate: string;
  nights: number;
  pricePerNight: number;
  discountPercent: number;
  depositPaid: number;
  paymentMethod: PaymentMethod;
  notes?: string;
}

export interface LinkGuestParams {
  guestId: number;
  roomId: number;
  nights: number;
  pricePerNight?: number;
  discountPercent?: number;
  paidAmount?: number;
  paymentMethod?: PaymentMethod;
  notes?: string;
}

export interface GuestPaymentParams {
  guestId: number;
  bookingId?: number;
  amount: number;
  method: PaymentMethod;
  receiptNumber?: string;
  notes?: string;
}

interface HotelContextType {
  // Data
  rooms: Room[];
  guests: Guest[];
  bookings: Booking[];
  housekeeping: HousekeepingTask[];
  payments: Payment[];
  logs: ActivityLog[];
  settings: HotelSettings;
  notifications: HotelNotification[];
  unreadNotificationCount: number;
  roomServiceMenu: RoomServiceItem[];
  roomServiceOrders: RoomServiceOrder[];
  staffMembers: StaffMember[];
  staffSalaries: StaffSalaryRecord[];
  expenses: ExpenseRecord[];
  otherRevenues: OtherRevenueRecord[];
  currentUser: SystemUser;
  systemProfiles: { admin: SystemUser; reception: SystemUser };
  updateSystemProfile: (
    kind: 'admin' | 'reception',
    updates: Partial<Pick<SystemUser, 'name' | 'roleAr' | 'phone' | 'email' | 'shift'>>
  ) => void;

  // View state
  activeTab: ActiveTab;
  setActiveTab: (tab: ActiveTab) => void;
  goBack: () => boolean;
  canGoBack: boolean;
  isDrawerOpen: boolean;
  setIsDrawerOpen: (open: boolean) => void;
  selectedRoom: Room | null;
  setSelectedRoom: (room: Room | null) => void;
  isCheckInModalOpen: boolean;
  setIsCheckInModalOpen: (open: boolean) => void;
  isSqlConsoleOpen: boolean;
  setIsSqlConsoleOpen: (open: boolean) => void;
  isSettingsOpen: boolean;
  setIsSettingsOpen: (open: boolean) => void;
  isNotificationsOpen: boolean;
  setIsNotificationsOpen: (open: boolean) => void;
  isAndroidView: boolean;
  setIsAndroidView: (isAndroid: boolean) => void;
  searchQuery: string;
  setSearchQuery: (query: string) => void;
  statusFilter: string;
  setStatusFilter: (filter: string) => void;
  floorFilter: number | null;
  setFloorFilter: (floor: number | null) => void;

  // New Modals
  isAccountModalOpen: boolean;
  setIsAccountModalOpen: (open: boolean) => void;
  isHelpModalOpen: boolean;
  setIsHelpModalOpen: (open: boolean) => void;
  isLanguageModalOpen: boolean;
  setIsLanguageModalOpen: (open: boolean) => void;
  isLogoutModalOpen: boolean;
  setIsLogoutModalOpen: (open: boolean) => void;
  isLocked: boolean;
  setIsLocked: (locked: boolean) => void;

  // Modals for guests and rooms
  selectedGuestForStatement: Guest | null;
  setSelectedGuestForStatement: (guest: Guest | null) => void;
  isLinkGuestModalOpen: boolean;
  setIsLinkGuestModalOpen: (open: boolean) => void;
  preselectedGuestForLink: Guest | null;
  setPreselectedGuestForLink: (guest: Guest | null) => void;
  preselectedRoomForLink: Room | null;
  setPreselectedRoomForLink: (room: Room | null) => void;
  isAddRoomModalOpen: boolean;
  setIsAddRoomModalOpen: (open: boolean) => void;

  // Room Service Modals & Selection
  isNewRoomServiceModalOpen: boolean;
  setIsNewRoomServiceModalOpen: (open: boolean) => void;
  isRoomServiceMenuModalOpen: boolean;
  setIsRoomServiceMenuModalOpen: (open: boolean) => void;
  preselectedRoomForRoomService: Room | null;
  setPreselectedRoomForRoomService: (room: Room | null) => void;
  selectedOrderForDetail: RoomServiceOrder | null;
  setSelectedOrderForDetail: (order: RoomServiceOrder | null) => void;

  // Finance Modals & Action
  isNewExpenseModalOpen: boolean;
  setIsNewExpenseModalOpen: (open: boolean) => void;
  isNewOtherRevenueModalOpen: boolean;
  setIsNewOtherRevenueModalOpen: (open: boolean) => void;
  isPaySalaryModalOpen: boolean;
  setIsPaySalaryModalOpen: (open: boolean) => void;

  // Room Service Core Actions
  createRoomServiceOrder: (
    data: Omit<RoomServiceOrder, 'id' | 'orderCode' | 'createdAt'>
  ) => { success: boolean; order?: RoomServiceOrder; error?: string };
  updateRoomServiceOrderStatus: (
    orderId: number,
    newStatus: RoomServiceOrderStatus,
    staffName?: string
  ) => void;
  addRoomServiceMenuItem: (
    item: Omit<RoomServiceItem, 'id'>
  ) => { success: boolean; item?: RoomServiceItem };
  updateRoomServiceMenuItem: (
    itemId: number,
    updates: Partial<RoomServiceItem>
  ) => void;
  deleteRoomServiceMenuItem: (itemId: number) => { success: boolean };
  toggleRoomServiceItemAvailability: (itemId: number) => void;
  printRoomServiceOrderTicket: (order: RoomServiceOrder) => void;

  // Core Actions
  checkIn: (data: CheckInData) => Promise<boolean>;
  custody: CustodyItem[];
  addCustodyItem: (
    data: Omit<CustodyItem, 'id' | 'code' | 'receivedAt' | 'receivedBy' | 'status' | 'photoIds'>,
    photos: string[]
  ) => Promise<CustodyItem>;
  returnCustodyItem: (id: number, returnedTo: string) => void;
  deleteCustodyItem: (id: number) => void;
  smsLog: SmsLogEntry[];
  logSms: (entry: Omit<SmsLogEntry, 'id' | 'at' | 'by'>) => void;
  clearSmsLog: () => void;
  smsDraft: SmsDraft | null;
  setSmsDraft: (d: SmsDraft | null) => void;
  openSmsComposer: (draft: SmsDraft) => void;
  addCompanion: (bookingId: number, companion: Omit<Companion, 'id'>) => boolean;
  removeCompanion: (bookingId: number, companionId: string) => void;
  closings: ClosingRecord[];
  closePeriod: (type: ClosingType, anchorDate: string) => { success: boolean; error?: string; record?: ClosingRecord };
  reopenPeriod: (id: number) => void;
  findClosedPeriod: (date: string) => ClosingRecord | undefined;
  reservations: FutureReservation[];
  addReservation: (data: NewReservationInput) => { success: boolean; error?: string; reservation?: FutureReservation };
  cancelReservation: (id: number, asNoShow?: boolean) => boolean;
  convertReservationToStay: (id: number) => Promise<boolean>;
  checkOut: (roomId: number, balancePaid?: number, paymentMethod?: PaymentMethod) => Promise<boolean>;
  completeHousekeeping: (roomId: number) => Promise<void>;
  updateHousekeepingStatus: (taskId: number, status: 'dirty' | 'in_progress' | 'inspected' | 'clean') => void;
  toggleHousekeepingChecklist: (taskId: number, item: keyof HousekeepingTask['checklist']) => void;
  assignHousekeeper: (taskId: number, name: string) => void;
  updateRoomStatus: (roomId: number, status: RoomStatus, notes?: string) => void;
  addAdditionalCharge: (bookingId: number, description: string, amount: number) => void;
  extendBookingNights: (bookingId: number, extraNights: number) => void;
  cancelBooking: (bookingId: number) => boolean;

  // Room Management Actions
  addRoom: (roomData: Omit<Room, 'id'>) => { success: boolean; room?: Room; error?: string };
  deleteRoom: (roomId: number) => { success: boolean; error?: string };
  updateRoom: (roomId: number, updates: Partial<Room>) => Room | undefined;

  // Guest Actions
  addOrUpdateGuest: (guest: Partial<Guest>) => Guest;
  addGuest: (guest: Partial<Guest>) => { success: boolean; guest?: Guest; error?: string };
  deleteGuest: (guestId: number) => { success: boolean; error?: string };
  updateGuest: (guestId: number, updates: Partial<Guest>) => Guest | undefined;
  getGuestByPhone: (phone: string) => Guest | undefined;
  toggleVipGuest: (guestId: number) => void;
  linkGuestToRoom: (params: LinkGuestParams) => Promise<boolean>;

  // Customer Account & Payment Actions
  recordGuestPayment: (params: GuestPaymentParams) => Payment;
  generateGuestStatementPdf: (guest: Guest) => void;
  exportGuestsPdf: () => Promise<void>;

  // Finance Actions (Expenses, Salaries, Revenues)
  addExpense: (expense: Omit<ExpenseRecord, 'id' | 'expenseCode'>) => ExpenseRecord;
  deleteExpense: (id: number) => void;
  addOtherRevenue: (revenue: Omit<OtherRevenueRecord, 'id' | 'revenueCode'>) => OtherRevenueRecord;
  deleteOtherRevenue: (id: number) => void;
  recordSalaryPayment: (salary: Omit<StaffSalaryRecord, 'id' | 'slipCode'>) => StaffSalaryRecord;
  addStaffMember: (staff: Omit<StaffMember, 'id'>) => StaffMember;
  updateStaffMember: (id: number, updates: Partial<StaffMember>) => void;
  deleteStaffMember: (id: number) => void;
  switchUser: (username: string) => void;

  // Google Drive & Cloud Backup
  googleAccounts: GoogleAccountLink[];
  selectedGoogleAccount: GoogleAccountLink | null;
  selectedGoogleAccountId: string;
  setSelectedGoogleAccountId: (id: string) => void;
  linkGoogleAccountManually: (accountData: { email: string; displayName?: string; folderName?: string }) => void;
  unlinkGoogleAccount: (accountId: string) => void;
  selectActiveGoogleAccount: (accountId: string) => void;
  updateGoogleAccountSyncSettings: (accountId: string, autoSync: boolean) => void;

  // Automatic Backup State & Actions
  autoBackupConfig: AutoBackupConfig;
  updateAutoBackupConfig: (config: Partial<AutoBackupConfig>) => void;
  backupSnapshots: BackupSnapshot[];
  createBackupSnapshot: (type?: 'auto' | 'manual' | 'cloud_sync') => Promise<BackupSnapshot>;
  restoreBackupSnapshot: (snapshotId: string) => Promise<boolean>;
  deleteBackupSnapshot: (snapshotId: string) => void;
  syncSnapshotToGoogleDrive: (snapshotId: string) => Promise<{ success: boolean; message: string }>;
  syncAllToGoogleDriveNow: () => Promise<{ success: boolean; count: number; message: string }>;
  isSyncingToGoogleDrive: boolean;
  lastSyncMessage: string | null;

  // Dialog Toggles
  isGoogleDriveLinkModalOpen: boolean;
  setIsGoogleDriveLinkModalOpen: (open: boolean) => void;
  isAutoBackupModalOpen: boolean;
  setIsAutoBackupModalOpen: (open: boolean) => void;

  // SQLite Engine & DB Actions
  executeSql: (sql: string) => QueryResult;
  exportDatabaseSql: () => void;
  exportDatabaseJson: () => void;
  importDatabaseJson: (file: File) => Promise<boolean>;
  resetToDemoData: () => void;
  updateSettings: (newSettings: Partial<HotelSettings>) => void;

  // Utilities
  generatePdfInvoice: (booking: Booking) => void;
  generateSalarySlipPdf: (slip: StaffSalaryRecord) => void;
  exportRoomsCsv: () => void;
  exportGuestsCsv: () => void;
  playAlertSound: (type?: 'success' | 'alert' | 'ding') => void;
  markNotificationRead: (id: string) => void;
  clearAllNotifications: () => void;
}

/**
 * useState whose setter also updates a ref synchronously. Actions read the ref via
 * getLatest(), so two actions fired in the same tick no longer overwrite each other
 * with stale closure values.
 */
function useRefState<T>(init: T | (() => T)) {
  const [state, setState] = useState<T>(init);
  const ref = useRef<T>(state);
  const set = useCallback((v: T | ((prev: T) => T)) => {
    const next = typeof v === 'function' ? (v as (prev: T) => T)(ref.current) : v;
    ref.current = next;
    setState(next);
  }, []);
  return [state, set, ref] as const;
}

const FINANCE_STORAGE_KEY = 'qasr_finance_v1';
const RESERVATIONS_STORAGE_KEY = 'qasr_reservations_v1';
const PROFILES_STORAGE_KEY = 'qasr_profiles_v1';
const CUSTODY_STORAGE_KEY = 'qasr_custody_v1';
const SMS_STORAGE_KEY = 'qasr_sms_v1';
function loadList<T>(key: string): T[] {
  try {
    const raw = localStorage.getItem(key);
    const parsed = raw ? JSON.parse(raw) : [];
    return Array.isArray(parsed) ? (parsed as T[]) : [];
  } catch {
    return [];
  }
}
const CLOSINGS_STORAGE_KEY = 'qasr_closings_v1';

const defaultReceptionUser: SystemUser = {
  id: 2,
  username: 'reception',
  name: 'موظف الاستقبال',
  role: 'reception',
  roleAr: 'الاستقبال',
  email: '',
  phone: '',
  shift: 'شفت الاستقبال',
  lastLogin: '',
  permissions: ['تسكين وحجز الغرف', 'طلبات خدمة الغرف', 'إصدار الفواتير والسندات'],
};

type SystemProfiles = { admin: SystemUser; reception: SystemUser };
const loadProfiles = (): SystemProfiles => {
  try {
    const raw = localStorage.getItem(PROFILES_STORAGE_KEY);
    if (raw) {
      const p = JSON.parse(raw);
      if (p && p.admin && p.reception) return p as SystemProfiles;
    }
  } catch {
    /* ignore */
  }
  return { admin: initialSystemUser, reception: defaultReceptionUser };
};
function loadFinanceSlice<T>(key: string, fallback: T): T {
  try {
    const raw = localStorage.getItem(FINANCE_STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (parsed && Array.isArray(parsed[key])) return parsed[key] as T;
    }
  } catch {
    /* ignore corrupt storage */
  }
  return fallback;
}

// ---- Pure helpers (no React state, safe against stale closures) ----
const digitsOnly = (v: string) => (v || '').replace(/\D/g, '');

/** Match a guest by phone: exact digits, or same last 9 digits (country-code tolerant). */
const findGuestByPhone = (list: Guest[], phone: string): Guest | undefined => {
  const digits = digitsOnly(phone);
  if (!digits) return undefined;
  return list.find((g) => {
    const gd = digitsOnly(g.phone);
    if (!gd) return false;
    return gd === digits || (digits.length >= 9 && gd.length >= 9 && gd.slice(-9) === digits.slice(-9));
  });
};

/** Returns an Arabic error message if the stay cannot be created, otherwise null. */
const validateStay = (room: Room, nights: number, price: number, discount: number): string | null => {
  if (room.status === 'occupied' || room.currentBookingId) return `الغرفة ${room.roomNumber} مشغولة حالياً.`;
  if (room.status === 'maintenance') return `الغرفة ${room.roomNumber} تحت الصيانة ولا يمكن تسكينها.`;
  if (room.status === 'cleaning') return `الغرفة ${room.roomNumber} قيد التنظيف، أكمل الهاوس كيبينج أولاً.`;
  if (!Number.isFinite(nights) || nights < 1 || nights > 365) return 'عدد الليالي يجب أن يكون بين 1 و 365.';
  if (!Number.isFinite(price) || price <= 0) return 'سعر الليلة غير صالح.';
  if (!Number.isFinite(discount) || discount < 0 || discount > 100) return 'نسبة الخصم يجب أن تكون بين 0 و 100.';
  return null;
};

const HotelContext = createContext<HotelContextType | undefined>(undefined);

export const HotelProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const engine = useMemo(() => SqliteEngine.getInstance(), []);
  const initialDb = engine.getDatabase();

  const [rooms, setRooms, roomsRef] = useRefState<Room[]>(initialDb.rooms || initialRooms);
  const [guests, setGuests, guestsRef] = useRefState<Guest[]>(initialDb.guests || initialGuests);
  const [bookings, setBookings, bookingsRef] = useRefState<Booking[]>(initialDb.bookings || initialBookings);
  const [housekeeping, setHousekeeping, housekeepingRef] = useRefState<HousekeepingTask[]>(initialDb.housekeeping || initialHousekeeping);
  const [payments, setPayments, paymentsRef] = useRefState<Payment[]>(initialDb.payments || initialPayments);
  const [logs, setLogs, logsRef] = useRefState<ActivityLog[]>(initialDb.logs || initialLogs);
  const [settings, setSettings, settingsRef] = useRefState<HotelSettings>(initialDb.settings || initialSettings);

  // Financial & Staff states
  // These slices were never persisted before (lost on every reload) — now saved separately.
  const [staffMembers, setStaffMembers, staffMembersRef] = useRefState<StaffMember[]>(() => loadFinanceSlice('staffMembers', initialStaffMembers));
  const [staffSalaries, setStaffSalaries, staffSalariesRef] = useRefState<StaffSalaryRecord[]>(() => loadFinanceSlice('staffSalaries', initialStaffSalaries));
  const [expenses, setExpenses, expensesRef] = useRefState<ExpenseRecord[]>(() => loadFinanceSlice('expenses', initialExpenses));
  const [otherRevenues, setOtherRevenues, otherRevenuesRef] = useRefState<OtherRevenueRecord[]>(() => loadFinanceSlice('otherRevenues', initialOtherRevenues));

  const [reservations, setReservations, reservationsRef] = useRefState<FutureReservation[]>(() => {
    try {
      const raw = localStorage.getItem(RESERVATIONS_STORAGE_KEY);
      const parsed = raw ? JSON.parse(raw) : [];
      return Array.isArray(parsed) ? parsed : [];
    } catch {
      return [];
    }
  });

  const [closings, setClosings, closingsRef] = useRefState<ClosingRecord[]>(() => {
    try {
      const raw = localStorage.getItem(CLOSINGS_STORAGE_KEY);
      const parsed = raw ? JSON.parse(raw) : [];
      return Array.isArray(parsed) ? parsed : [];
    } catch {
      return [];
    }
  });

  useEffect(() => {
    try {
      localStorage.setItem(CLOSINGS_STORAGE_KEY, JSON.stringify(closings));
    } catch (err) {
      console.error('Could not persist closings', err);
    }
  }, [closings]);

  // ---- Custody (أمانات) and SMS log ----
  const [custody, setCustody, custodyRef] = useRefState<CustodyItem[]>(() => loadList<CustodyItem>(CUSTODY_STORAGE_KEY));
  const [smsLog, setSmsLog, smsLogRef] = useRefState<SmsLogEntry[]>(() => loadList<SmsLogEntry>(SMS_STORAGE_KEY));
  const [smsDraft, setSmsDraft] = useState<SmsDraft | null>(null);

  useEffect(() => {
    try {
      localStorage.setItem(CUSTODY_STORAGE_KEY, JSON.stringify(custody));
    } catch (err) {
      console.error('Could not persist custody', err);
    }
  }, [custody]);
  useEffect(() => {
    try {
      localStorage.setItem(SMS_STORAGE_KEY, JSON.stringify(smsLog));
    } catch (err) {
      console.error('Could not persist sms log', err);
    }
  }, [smsLog]);

  useEffect(() => {
    try {
      localStorage.setItem(RESERVATIONS_STORAGE_KEY, JSON.stringify(reservations));
    } catch (err) {
      console.error('Could not persist reservations', err);
    }
  }, [reservations]);

  useEffect(() => {
    try {
      localStorage.setItem(FINANCE_STORAGE_KEY, JSON.stringify({ staffMembers, staffSalaries, expenses, otherRevenues }));
    } catch (err) {
      console.error('Could not persist finance data', err);
    }
  }, [staffMembers, staffSalaries, expenses, otherRevenues]);
  const [systemProfiles, setSystemProfiles] = useState<SystemProfiles>(loadProfiles);
  const [currentUser, setCurrentUser] = useState<SystemUser>(() => loadProfiles().admin);

  useEffect(() => {
    try {
      localStorage.setItem(PROFILES_STORAGE_KEY, JSON.stringify(systemProfiles));
    } catch (err) {
      console.error('Could not persist profiles', err);
    }
  }, [systemProfiles]);

  const updateSystemProfile = useCallback(
    (kind: 'admin' | 'reception', updates: Partial<Pick<SystemUser, 'name' | 'roleAr' | 'phone' | 'email' | 'shift'>>) => {
      const username = kind;
      setSystemProfiles((prev) => ({ ...prev, [kind]: { ...prev[kind], ...updates, username } }));
      setCurrentUser((cur) => (cur.username === username ? { ...cur, ...updates } : cur));
    },
    []
  );

  // UI state
  const [activeTab, setActiveTabRaw] = useState<ActiveTab>('rooms');
  const activeTabRef = useRef<ActiveTab>('rooms');
  activeTabRef.current = activeTab;
  const tabHistory = useRef<ActiveTab[]>([]);

  /** Tab navigation that remembers where the user came from, for the back button. */
  const setActiveTab = useCallback((tab: ActiveTab) => {
    const cur = activeTabRef.current;
    if (tab !== cur) {
      tabHistory.current.push(cur);
      if (tabHistory.current.length > 20) tabHistory.current.shift();
    }
    setActiveTabRaw(tab);
  }, []);
  const [isDrawerOpen, setIsDrawerOpen] = useState<boolean>(false);
  const [selectedRoom, setSelectedRoom] = useState<Room | null>(null);
  const [isCheckInModalOpen, setIsCheckInModalOpen] = useState<boolean>(false);
  const [isSqlConsoleOpen, setIsSqlConsoleOpen] = useState<boolean>(false);
  const [isSettingsOpen, setIsSettingsOpen] = useState<boolean>(false);
  const [isNotificationsOpen, setIsNotificationsOpen] = useState<boolean>(false);
  const [isAndroidView, setIsAndroidView] = useState<boolean>(false);
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [floorFilter, setFloorFilter] = useState<number | null>(null);
  const [notifications, setNotifications] = useState<HotelNotification[]>([]);

  // Drawer action modals
  const [isAccountModalOpen, setIsAccountModalOpen] = useState<boolean>(false);
  const [isHelpModalOpen, setIsHelpModalOpen] = useState<boolean>(false);
  const [isLanguageModalOpen, setIsLanguageModalOpen] = useState<boolean>(false);
  const [isLogoutModalOpen, setIsLogoutModalOpen] = useState<boolean>(false);
  const [isLocked, setIsLocked] = useState<boolean>(() => hasPin());

  // Modals for guests and rooms
  const [selectedGuestForStatement, setSelectedGuestForStatement] = useState<Guest | null>(null);
  const [isLinkGuestModalOpen, setIsLinkGuestModalOpen] = useState<boolean>(false);
  const [preselectedGuestForLink, setPreselectedGuestForLink] = useState<Guest | null>(null);
  const [preselectedRoomForLink, setPreselectedRoomForLink] = useState<Room | null>(null);
  const [isAddRoomModalOpen, setIsAddRoomModalOpen] = useState<boolean>(false);

  // Room Service states
  const [roomServiceMenu, setRoomServiceMenu, roomServiceMenuRef] = useRefState<RoomServiceItem[]>(
    initialDb.roomServiceMenu || initialRoomServiceMenu
  );
  const [roomServiceOrders, setRoomServiceOrders, roomServiceOrdersRef] = useRefState<RoomServiceOrder[]>(
    initialDb.roomServiceOrders || initialRoomServiceOrders
  );

  // Always-fresh snapshot of data state (see useRefState)
  const getLatest = () => ({
    rooms: roomsRef.current,
    guests: guestsRef.current,
    bookings: bookingsRef.current,
    housekeeping: housekeepingRef.current,
    payments: paymentsRef.current,
    logs: logsRef.current,
    settings: settingsRef.current,
    roomServiceMenu: roomServiceMenuRef.current,
    roomServiceOrders: roomServiceOrdersRef.current,
    staffMembers: staffMembersRef.current,
    staffSalaries: staffSalariesRef.current,
    expenses: expensesRef.current,
    otherRevenues: otherRevenuesRef.current,
    reservations: reservationsRef.current,
    closings: closingsRef.current,
  });
  const [isNewRoomServiceModalOpen, setIsNewRoomServiceModalOpen] = useState<boolean>(false);
  const [isRoomServiceMenuModalOpen, setIsRoomServiceMenuModalOpen] = useState<boolean>(false);
  const [preselectedRoomForRoomService, setPreselectedRoomForRoomService] = useState<Room | null>(null);
  const [selectedOrderForDetail, setSelectedOrderForDetail] = useState<RoomServiceOrder | null>(null);

  // Finance Modals
  const [isNewExpenseModalOpen, setIsNewExpenseModalOpen] = useState<boolean>(false);
  const [isNewOtherRevenueModalOpen, setIsNewOtherRevenueModalOpen] = useState<boolean>(false);
  const [isPaySalaryModalOpen, setIsPaySalaryModalOpen] = useState<boolean>(false);

  // Google Drive & Cloud Backup States
  const [googleAccounts, setGoogleAccounts] = useState<GoogleAccountLink[]>(() => {
    try {
      const saved = localStorage.getItem('qasr_google_accounts_v1');
      if (saved) return JSON.parse(saved);
    } catch (e) {
      console.warn('Failed to load saved google accounts', e);
    }
    return initialGoogleAccounts;
  });

  const [selectedGoogleAccountId, setSelectedGoogleAccountId] = useState<string>(() => {
    try {
      const savedId = localStorage.getItem('qasr_selected_google_account_id_v1');
      if (savedId) return savedId;
    } catch (e) {
      console.warn('Failed to load selected google account id', e);
    }
    return 'g-acc-1';
  });

  const [autoBackupConfig, setAutoBackupConfig] = useState<AutoBackupConfig>(() => {
    try {
      const saved = localStorage.getItem('qasr_auto_backup_config_v1');
      if (saved) return JSON.parse(saved);
    } catch (e) {
      console.warn('Failed to load auto backup config', e);
    }
    return initialAutoBackupConfig;
  });

  const [backupSnapshots, setBackupSnapshots] = useState<BackupSnapshot[]>(() => {
    try {
      const saved = localStorage.getItem('qasr_backup_snapshots_v1');
      if (saved) return JSON.parse(saved);
    } catch (e) {
      console.warn('Failed to load backup snapshots', e);
    }
    return initialBackupSnapshots;
  });

  const [isSyncingToGoogleDrive, setIsSyncingToGoogleDrive] = useState<boolean>(false);
  const [lastSyncMessage, setLastSyncMessage] = useState<string | null>(null);
  const [isGoogleDriveLinkModalOpen, setIsGoogleDriveLinkModalOpen] = useState<boolean>(false);
  const [isAutoBackupModalOpen, setIsAutoBackupModalOpen] = useState<boolean>(false);

  // ---- Back navigation (header button + Android hardware/gesture back) ----
  const overlays: [boolean, () => void][] = [
    [isSettingsOpen, () => setIsSettingsOpen(false)],
    [isNotificationsOpen, () => setIsNotificationsOpen(false)],
    [isAccountModalOpen, () => setIsAccountModalOpen(false)],
    [isHelpModalOpen, () => setIsHelpModalOpen(false)],
    [isLanguageModalOpen, () => setIsLanguageModalOpen(false)],
    [isLinkGuestModalOpen, () => setIsLinkGuestModalOpen(false)],
    [isAddRoomModalOpen, () => setIsAddRoomModalOpen(false)],
    [isNewRoomServiceModalOpen, () => setIsNewRoomServiceModalOpen(false)],
    [isRoomServiceMenuModalOpen, () => setIsRoomServiceMenuModalOpen(false)],
    [isNewExpenseModalOpen, () => setIsNewExpenseModalOpen(false)],
    [isNewOtherRevenueModalOpen, () => setIsNewOtherRevenueModalOpen(false)],
    [isPaySalaryModalOpen, () => setIsPaySalaryModalOpen(false)],
    [isGoogleDriveLinkModalOpen, () => setIsGoogleDriveLinkModalOpen(false)],
    [isAutoBackupModalOpen, () => setIsAutoBackupModalOpen(false)],
    [isCheckInModalOpen, () => setIsCheckInModalOpen(false)],
    [isSqlConsoleOpen, () => setIsSqlConsoleOpen(false)],
    [!!selectedGuestForStatement, () => setSelectedGuestForStatement(null)],
    [!!selectedRoom, () => setSelectedRoom(null)],
    [isDrawerOpen, () => setIsDrawerOpen(false)],
  ];
  const canGoBack = !isLocked && (overlays.some(([open]) => open) || activeTab !== 'rooms');

  /** Closes the top-most overlay, otherwise goes to the previous screen. Returns false at the home screen. */
  const goBack = (): boolean => {
    if (isLocked) return true; // lock screen: back must not reveal anything
    const open = overlays.find(([isOpen]) => isOpen);
    if (open) {
      open[1]();
      return true;
    }
    const prev = tabHistory.current.pop();
    if (prev && prev !== activeTab) {
      setActiveTabRaw(prev);
      return true;
    }
    if (activeTab !== 'rooms') {
      setActiveTabRaw('rooms');
      return true;
    }
    return false;
  };

  // Selected Google Account Helper
  const selectedGoogleAccount = useMemo(() => {
    const found = googleAccounts.find((acc) => acc.id === selectedGoogleAccountId);
    return found || googleAccounts[0] || null;
  }, [googleAccounts, selectedGoogleAccountId]);

  // Persist Google Accounts
  useEffect(() => {
    try {
      localStorage.setItem('qasr_google_accounts_v1', JSON.stringify(googleAccounts));
    } catch (e) {
      console.error(e);
    }
  }, [googleAccounts]);

  // Persist Selected Account ID
  useEffect(() => {
    try {
      localStorage.setItem('qasr_selected_google_account_id_v1', selectedGoogleAccountId);
    } catch (e) {
      console.error(e);
    }
  }, [selectedGoogleAccountId]);

  // Persist Auto Backup Config
  useEffect(() => {
    try {
      localStorage.setItem('qasr_auto_backup_config_v1', JSON.stringify(autoBackupConfig));
    } catch (e) {
      console.error(e);
    }
  }, [autoBackupConfig]);

  // Persist Backup Snapshots
  useEffect(() => {
    try {
      localStorage.setItem('qasr_backup_snapshots_v1', JSON.stringify(backupSnapshots));
    } catch (e) {
      console.error(e);
    }
  }, [backupSnapshots]);


  // Synchronize state with SQLite Storage
  const persistChanges = useCallback(
    (
      newRooms = roomsRef.current,
      newGuests = guestsRef.current,
      newBookings = bookingsRef.current,
      newHousekeeping = housekeepingRef.current,
      newPayments = paymentsRef.current,
      newLogs = logsRef.current,
      newSettings = settingsRef.current,
      newMenu = roomServiceMenuRef.current,
      newOrders = roomServiceOrdersRef.current
    ) => {
      engine.saveToStorage({
        version: 1,
        lastUpdated: new Date().toISOString(),
        settings: newSettings,
        rooms: newRooms,
        guests: newGuests,
        bookings: newBookings,
        housekeeping: newHousekeeping,
        payments: newPayments,
        logs: newLogs,
        roomServiceMenu: newMenu,
        roomServiceOrders: newOrders,
      });
    },
    [engine, rooms, guests, bookings, housekeeping, payments, logs, settings, roomServiceMenu, roomServiceOrders]
  );

  // Sound Synthesizer via Web Audio API
  const playAlertSound = useCallback(
    (type: 'success' | 'alert' | 'ding' = 'ding') => {
      if (!settings.enableAudioAlerts) return;
      try {
        const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
        if (!AudioCtx) return;
        const ctx = new AudioCtx();
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.connect(gain);
        gain.connect(ctx.destination);

        const now = ctx.currentTime;
        if (type === 'success') {
          osc.type = 'sine';
          osc.frequency.setValueAtTime(523.25, now);
          osc.frequency.setValueAtTime(659.25, now + 0.1);
          osc.frequency.setValueAtTime(783.99, now + 0.2);
          gain.gain.setValueAtTime(0.15, now);
          gain.gain.exponentialRampToValueAtTime(0.001, now + 0.5);
          osc.start(now);
          osc.stop(now + 0.5);
        } else if (type === 'alert') {
          osc.type = 'triangle';
          osc.frequency.setValueAtTime(880, now);
          osc.frequency.setValueAtTime(440, now + 0.15);
          gain.gain.setValueAtTime(0.2, now);
          gain.gain.exponentialRampToValueAtTime(0.001, now + 0.4);
          osc.start(now);
          osc.stop(now + 0.4);
        } else {
          osc.type = 'sine';
          osc.frequency.setValueAtTime(659.25, now);
          gain.gain.setValueAtTime(0.12, now);
          gain.gain.exponentialRampToValueAtTime(0.001, now + 0.3);
          osc.start(now);
          osc.stop(now + 0.3);
        }
      } catch {
        // Ignore audio errors
      }
    },
    [settings.enableAudioAlerts]
  );

  // ---- Custody (الأمانات) & SMS log — defined here because they use currentUser / playAlertSound / setActiveTab ----
  const addCustodyItem = useCallback(
    async (
      data: Omit<CustodyItem, 'id' | 'code' | 'receivedAt' | 'receivedBy' | 'status' | 'photoIds'>,
      photos: string[]
    ): Promise<CustodyItem> => {
      const id = uid();
      const photoIds: string[] = [];
      for (let i = 0; i < photos.length; i++) {
        const key = `custody-${id}-${i}`;
        await saveImage(key, photos[i]);
        photoIds.push(key);
      }
      const list = custodyRef.current;
      const item: CustodyItem = {
        ...data,
        id,
        code: `AMN-${String(list.length + 1).padStart(4, '0')}`,
        receivedAt: localDateTime(),
        receivedBy: currentUser.name,
        status: 'held',
        photoIds,
      };
      setCustody([item, ...list]);
      const newLog: ActivityLog = {
        id: uid(),
        timestamp: localDateTime(),
        action: `استلام أمانة: ${item.code}`,
        details: `${item.title} — ${item.guestName}${item.roomNumber ? ` (غرفة ${item.roomNumber})` : ''}`,
        category: 'booking',
      };
      setLogs([newLog, ...logsRef.current]);
      playAlertSound('success');
      return item;
    },
    [currentUser, playAlertSound]
  );

  const returnCustodyItem = useCallback(
    (id: number, returnedTo: string) => {
      const item = custodyRef.current.find((c) => c.id === id);
      if (!item || item.status === 'returned') return;
      setCustody(custodyRef.current.map((c) => (c.id === id ? { ...c, status: 'returned', returnedAt: localDateTime(), returnedTo } : c)));
      setLogs([
        { id: uid(), timestamp: localDateTime(), action: `تسليم أمانة: ${item.code}`, details: `${item.title} سُلّمت إلى ${returnedTo}`, category: 'booking' } as ActivityLog,
        ...logsRef.current,
      ]);
      playAlertSound('success');
    },
    [playAlertSound]
  );

  const deleteCustodyItem = useCallback((id: number) => {
    const item = custodyRef.current.find((c) => c.id === id);
    if (!item) return;
    item.photoIds.forEach((k) => deleteImage(k));
    setCustody(custodyRef.current.filter((c) => c.id !== id));
  }, []);

  const logSms = useCallback(
    (entry: Omit<SmsLogEntry, 'id' | 'at' | 'by'>) => {
      setSmsLog([{ ...entry, id: uid(), at: localDateTime(), by: currentUser.name }, ...smsLogRef.current].slice(0, 2000));
    },
    [currentUser]
  );
  const clearSmsLog = useCallback(() => setSmsLog([]), []);

  const openSmsComposer = useCallback(
    (draft: SmsDraft) => {
      setSmsDraft(draft);
      setActiveTab('messages');
    },
    [setActiveTab]
  );


  // Calculate Real-Time Smart Hotel Notifications
  useEffect(() => {
    const alerts: HotelNotification[] = [];
    const todayStr = localDate();

    // 1. Overdue checkouts
    bookings
      .filter((b) => b.isActive)
      .forEach((b) => {
        if (b.expectedCheckOutDate.substring(0, 10) < todayStr) {
          alerts.push({
            id: `overdue-${b.id}`,
            type: 'overdue_checkout',
            title: `تأخر مغادرة في الغرفة ${b.roomNumber}`,
            message: `النزيل ${b.guestName} تجاوز موعد المغادرة (${b.expectedCheckOutDate}).`,
            roomId: b.roomId,
            roomNumber: b.roomNumber,
            bookingId: b.id,
            timestamp: 'الآن',
            isRead: false,
            severity: 'danger',
          });
        } else if (b.expectedCheckOutDate.substring(0, 10) === todayStr) {
          alerts.push({
            id: `checkout-today-${b.id}`,
            type: 'checkout_today',
            title: `مغادرة متوقعة اليوم: الغرفة ${b.roomNumber}`,
            message: `النزيل ${b.guestName} موعد خروجه اليوم الساعة ${settings.checkOutTime}.`,
            roomId: b.roomId,
            roomNumber: b.roomNumber,
            bookingId: b.id,
            timestamp: 'اليوم',
            isRead: false,
            severity: 'warning',
          });
        }
      });

    // 2. Cleaning / Housekeeping alerts
    const dirtyRooms = rooms.filter((r) => r.status === 'cleaning');
    if (dirtyRooms.length > 0) {
      alerts.push({
        id: 'cleaning-alert-batch',
        type: 'cleaning_needed',
        title: `هناك ${dirtyRooms.length} غرف بحاجة إلى تنظيف (Housekeeping)`,
        message: `الغرف: ${dirtyRooms.map((r) => r.roomNumber).join(', ')} تنتظر التنظيف لتصبح متاحة للحجز.`,
        timestamp: 'مستمر',
        isRead: false,
        severity: 'info',
      });
    }

    // 3. Occupancy calculation alert
    const occupiedCount = rooms.filter((r) => r.status === 'occupied').length;
    const occupancyRate = rooms.length > 0 ? Math.round((occupiedCount / rooms.length) * 100) : 0;
    if (occupancyRate >= 70) {
      alerts.push({
        id: 'high-occupancy-alert',
        type: 'occupancy_alert',
        title: `نسبة إشغال عالية (${occupancyRate}%) 🏨`,
        message: `تم حجز ${occupiedCount} من أصل ${rooms.length} غرفة في الفندق حالياً.`,
        timestamp: 'إحصائية اليوم',
        isRead: true,
        severity: 'success',
      });
    }

    setNotifications(alerts);
  }, [rooms, bookings, settings.checkOutTime]);

  const unreadNotificationCount = useMemo(() => {
    return notifications.filter((n) => !n.isRead).length;
  }, [notifications]);

  const markNotificationRead = (id: string) => {
    setNotifications((prev) => prev.map((n) => (n.id === id ? { ...n, isRead: true } : n)));
  };

  const clearAllNotifications = () => {
    setNotifications((prev) => prev.map((n) => ({ ...n, isRead: true })));
  };

  // Guest Helpers
  const getGuestByPhone = useCallback((phone: string) => findGuestByPhone(guests, phone), [guests]);

  /** Pure upsert: returns the guest and the new list without touching React state. */
  const upsertGuestPure = useCallback(
    (list: Guest[], guestData: Partial<Guest>): { guest: Guest; list: Guest[] } => {
      const { settings } = getLatest();
      const now = localDate();
      const existing = guestData.phone ? findGuestByPhone(list, guestData.phone) : undefined;
      // Drop undefined / empty values so they never overwrite stored data
      const clean = Object.fromEntries(
        Object.entries(guestData).filter(([, v]) => v !== undefined && v !== '')
      ) as Partial<Guest>;

      if (existing) {
        const updatedVisits = existing.visitCount + 1;
        const isNowFrequent = updatedVisits >= settings.frequentGuestThreshold;
        const updated: Guest = {
          ...existing,
          ...clean,
          id: existing.id,
          visitCount: updatedVisits,
          isFrequent: isNowFrequent,
          isVip: existing.isVip || (guestData.isVip ?? false),
          loyaltyDiscountPercent: isNowFrequent
            ? Math.max(existing.loyaltyDiscountPercent, settings.defaultLoyaltyDiscount)
            : existing.loyaltyDiscountPercent,
          lastVisitDate: now,
        };
        return { guest: updated, list: list.map((g) => (g.id === existing.id ? updated : g)) };
      }

      const newGuest: Guest = {
        id: uid(),
        name: guestData.name || 'عميل جديد',
        phone: guestData.phone || '',
        nationalId: guestData.nationalId || '',
        nationality: guestData.nationality || 'يمني',
        email: guestData.email,
        visitCount: 1,
        isFrequent: false,
        loyaltyDiscountPercent: 0,
        totalSpent: 0,
        isVip: guestData.isVip || false,
        notes: guestData.notes,
        createdAt: now,
        lastVisitDate: now,
      };
      return { guest: newGuest, list: [newGuest, ...list] };
    },
    [settings.frequentGuestThreshold, settings.defaultLoyaltyDiscount]
  );

  const addOrUpdateGuest = useCallback(
    (guestData: Partial<Guest>): Guest => {
      const { rooms, guests, bookings, housekeeping, payments, logs, settings } = getLatest();
      const { guest, list } = upsertGuestPure(guests, guestData);
      setGuests(list);
      persistChanges(rooms, list, bookings, housekeeping, payments, logs, settings);
      return guest;
    },
    [guests, upsertGuestPure, rooms, bookings, housekeeping, payments, logs, settings, persistChanges]
  );

  const toggleVipGuest = useCallback(
    (guestId: number) => {
      const { rooms, guests, bookings, housekeeping, payments, logs, settings } = getLatest();
      const updated = guests.map((g) => (g.id === guestId ? { ...g, isVip: !g.isVip } : g));
      setGuests(updated);
      persistChanges(rooms, updated, bookings, housekeeping, payments, logs, settings);
    },
    [guests, rooms, bookings, housekeeping, payments, logs, settings, persistChanges]
  );

  // Check-In Action
  const checkIn = useCallback(
    async (data: CheckInData): Promise<boolean> => {
      const { rooms, guests, bookings, housekeeping, payments, logs, settings, reservations } = getLatest();
      const targetRoom = rooms.find((r) => r.id === data.roomId);
      if (!targetRoom) return false;

      const nights = Math.floor(Number(data.nights));
      const pricePerNight = Number(data.pricePerNight);
      const discountPercent = Number(data.discountPercent) || 0;
      const paidAmount = Math.max(0, Number(data.paidAmount) || 0);

      const validationError = validateStay(targetRoom, nights, pricePerNight, discountPercent);
      if (validationError) {
        alert(validationError);
        return false;
      }

      const knownGuest = findGuestByPhone(guests, data.guestPhone);
      if (knownGuest?.isBlacklisted) {
        alert(`النزيل ${knownGuest.name} مدرج في القائمة السوداء ولا يمكن تسكينه.`);
        return false;
      }

      // A walk-in must not overlap a confirmed advance reservation on the same room
      const stayEnd = addDaysToDateStr(localDate(), nights);
      const clash = reservations.find(
        (r) =>
          r.status === 'confirmed' &&
          r.roomId === targetRoom.id &&
          r.id !== data.ignoreReservationId &&
          r.arrivalDate < stayEnd &&
          r.departureDate > localDate()
      );
      if (clash) {
        alert(`الغرفة ${targetRoom.roomNumber} محجوزة مسبقاً للنزيل ${clash.guestName} بدءاً من ${clash.arrivalDate}. قلّل عدد الليالي أو اختر غرفة أخرى.`);
        return false;
      }

      // One single, consistent guest update (previously the later `guests.map` overwrote it)
      const { guest, list: guestsWithUpsert } = upsertGuestPure(guests, {
        name: data.guestName,
        phone: data.guestPhone,
        nationalId: data.guestNationalId,
        nationality: data.nationality,
      });

      const today = new Date();
      const checkInStr = localDateTime(today);
      const checkOutStr = `${addDaysToDateStr(localDate(today), nights)} ${settings.checkOutTime}`;

      const roomTotal = Math.round(pricePerNight * nights * (1 - discountPercent / 100));
      const bookingId = uid();
      const bookingCode = generateBookingCode(bookings.map((b) => b.bookingCode));
      const effectivePaid = Math.min(paidAmount, roomTotal);

      const newBooking: Booking = {
        id: bookingId,
        bookingCode,
        roomId: targetRoom.id,
        roomNumber: targetRoom.roomNumber,
        guestId: guest.id,
        guestName: guest.name,
        guestPhone: guest.phone,
        guestNationalId: guest.nationalId,
        checkInDate: checkInStr,
        expectedCheckOutDate: checkOutStr,
        nights,
        pricePerNight,
        discountPercent,
        roomTotal,
        additionalCharges: [],
        totalAmount: roomTotal,
        paidAmount: effectivePaid,
        paymentStatus: effectivePaid >= roomTotal ? 'paid' : effectivePaid > 0 ? 'partial' : 'pending',
        paymentMethod: data.paymentMethod,
        isActive: true,
        notes: data.notes,
        companions: data.companions && data.companions.length ? data.companions : undefined,
        createdAt: localDateTime(),
      };

      const updatedRooms = rooms.map((r) =>
        r.id === targetRoom.id
          ? {
              ...r,
              status: 'occupied' as RoomStatus,
              currentBookingId: bookingId,
              currentGuestName: guest.name,
              currentGuestPhone: guest.phone,
              checkInDate: checkInStr.substring(0, 10),
              checkOutDate: checkOutStr.substring(0, 10),
              notes: data.notes || r.notes,
            }
          : r
      );

      let updatedPayments = payments;
      if (effectivePaid > 0) {
        const newPayment: Payment = {
          id: uid(),
          bookingId,
          guestId: guest.id,
          amount: effectivePaid,
          method: data.paymentMethod,
          date: checkInStr,
          receiptNumber: `REC-${uid().toString().slice(-6)}`,
          notes: 'دفعة عند تسجيل الوصول',
        };
        updatedPayments = [newPayment, ...payments];
      }

      const updatedGuests = guestsWithUpsert.map((g) =>
        g.id === guest.id ? { ...g, totalSpent: g.totalSpent + effectivePaid } : g
      );

      const newLog: ActivityLog = {
        id: uid(),
        timestamp: localDateTime(),
        action: `تسجيل وصول: الغرفة ${targetRoom.roomNumber}`,
        details: `تم تسكين النزيل ${guest.name} لمدة ${nights} ليالي بمبلغ ${roomTotal} ر.ي`,
        category: 'booking',
      };

      const updatedBookings = [newBooking, ...bookings];
      const updatedLogs = [newLog, ...logs];

      setRooms(updatedRooms);
      setBookings(updatedBookings);
      setPayments(updatedPayments);
      setGuests(updatedGuests);
      setLogs(updatedLogs);

      persistChanges(updatedRooms, updatedGuests, updatedBookings, housekeeping, updatedPayments, updatedLogs, settings);

      playAlertSound('success');
      confetti({ particleCount: 50, spread: 60, origin: { y: 0.7 } });

      return true;
    },
    [rooms, guests, bookings, housekeeping, payments, logs, settings, reservations, upsertGuestPure, playAlertSound, persistChanges]
  );

  // ---- Advance reservations ----
  const findReservationConflict = useCallback(
    (roomId: number, arrival: string, departure: string, ignoreId?: number): string | null => {
      const { bookings, reservations } = getLatest();
      const activeStay = bookings.find((b) => b.isActive && b.roomId === roomId);
      if (activeStay) {
        const leaves = activeStay.expectedCheckOutDate.substring(0, 10);
        if (arrival < leaves) return `الغرفة مشغولة حتى ${leaves} (النزيل ${activeStay.guestName}).`;
      }
      const other = reservations.find(
        (r) => r.status === 'confirmed' && r.roomId === roomId && r.id !== ignoreId && arrival < r.departureDate && departure > r.arrivalDate
      );
      if (other) return `الغرفة محجوزة للنزيل ${other.guestName} من ${other.arrivalDate} إلى ${other.departureDate}.`;
      return null;
    },
    [bookings, reservations]
  );

  const addReservation = useCallback(
    (data: NewReservationInput): { success: boolean; error?: string; reservation?: FutureReservation } => {
      const { rooms, guests, bookings, housekeeping, payments, logs, settings, reservations } = getLatest();
      const room = rooms.find((r) => r.id === data.roomId);
      if (!room) return { success: false, error: 'اختر غرفة صالحة.' };
      if (!data.guestName.trim() || !digitsOnly(data.guestPhone)) return { success: false, error: 'اسم النزيل ورقم الجوال مطلوبان.' };
      if (!/^\d{4}-\d{2}-\d{2}$/.test(data.arrivalDate) || data.arrivalDate < localDate()) {
        return { success: false, error: 'تاريخ الوصول يجب أن يكون اليوم أو بعده.' };
      }
      const nights = Math.floor(Number(data.nights));
      const price = Number(data.pricePerNight);
      const discount = Number(data.discountPercent) || 0;
      if (!Number.isFinite(nights) || nights < 1 || nights > 365) return { success: false, error: 'عدد الليالي بين 1 و 365.' };
      if (!Number.isFinite(price) || price <= 0) return { success: false, error: 'سعر الليلة غير صالح.' };
      if (discount < 0 || discount > 100) return { success: false, error: 'الخصم بين 0 و 100.' };
      if (room.status === 'maintenance' && data.arrivalDate <= localDate()) {
        return { success: false, error: 'الغرفة تحت الصيانة حالياً.' };
      }

      const known = findGuestByPhone(guests, data.guestPhone);
      if (known?.isBlacklisted) return { success: false, error: `النزيل ${known.name} مدرج في القائمة السوداء.` };

      const departureDate = addDaysToDateStr(data.arrivalDate, nights);
      const conflict = findReservationConflict(room.id, data.arrivalDate, departureDate);
      if (conflict) return { success: false, error: conflict };

      const totalAmount = Math.round(price * nights * (1 - discount / 100));
      const deposit = Math.min(Math.max(0, Number(data.depositPaid) || 0), totalAmount);
      const reservation: FutureReservation = {
        id: uid(),
        code: `RSV-${generateBookingCode(reservations.map((r) => r.code.replace('RSV-', 'AZ-'))).slice(3)}`,
        roomId: room.id,
        roomNumber: room.roomNumber,
        guestName: data.guestName.trim(),
        guestPhone: data.guestPhone.trim(),
        guestNationalId: (data.guestNationalId || '').trim(),
        nationality: (data.nationality || 'يمني').trim(),
        arrivalDate: data.arrivalDate,
        nights,
        departureDate,
        pricePerNight: price,
        discountPercent: discount,
        totalAmount,
        depositPaid: deposit,
        paymentMethod: data.paymentMethod,
        status: 'confirmed',
        notes: data.notes?.trim() || undefined,
        createdAt: localDateTime(),
      };

      const newLog: ActivityLog = {
        id: uid(),
        timestamp: localDateTime(),
        action: `حجز مسبق: الغرفة ${room.roomNumber}`,
        details: `${reservation.code} للنزيل ${reservation.guestName} من ${reservation.arrivalDate} لمدة ${nights} ليالٍ${deposit > 0 ? ` — عربون ${deposit} ر.ي` : ''}`,
        category: 'booking',
      };
      setReservations((prev) => [reservation, ...prev]);
      setLogs([newLog, ...logs]);
      persistChanges(rooms, guests, bookings, housekeeping, payments, [newLog, ...logs], settings);
      playAlertSound('success');
      return { success: true, reservation };
    },
    [rooms, guests, bookings, housekeeping, payments, logs, settings, reservations, findReservationConflict, persistChanges, playAlertSound]
  );

  const cancelReservation = useCallback(
    (id: number, asNoShow: boolean = false): boolean => {
      const { rooms, guests, bookings, housekeeping, payments, logs, settings, reservations } = getLatest();
      const target = reservations.find((r) => r.id === id);
      if (!target || target.status !== 'confirmed') return false;
      setReservations((prev) => prev.map((r) => (r.id === id ? { ...r, status: (asNoShow ? 'no_show' : 'cancelled') as FutureReservation['status'] } : r)));
      const newLog: ActivityLog = {
        id: uid(),
        timestamp: localDateTime(),
        action: `${asNoShow ? 'عدم حضور' : 'إلغاء حجز مسبق'}: ${target.code}`,
        details: `الغرفة ${target.roomNumber} — ${target.guestName}${target.depositPaid > 0 ? ` (العربون ${target.depositPaid} ر.ي يُعالَج يدوياً)` : ''}`,
        category: 'booking',
      };
      setLogs([newLog, ...logs]);
      persistChanges(rooms, guests, bookings, housekeeping, payments, [newLog, ...logs], settings);
      playAlertSound('ding');
      return true;
    },
    [reservations, rooms, guests, bookings, housekeeping, payments, logs, settings, persistChanges, playAlertSound]
  );

  const convertReservationToStay = useCallback(
    async (id: number): Promise<boolean> => {
      const { reservations } = getLatest();
      const r = reservations.find((x) => x.id === id);
      if (!r || r.status !== 'confirmed') return false;
      if (r.arrivalDate > localDate()) {
        alert(`موعد الوصول ${r.arrivalDate} لم يحن بعد.`);
        return false;
      }
      const ok = await checkIn({
        roomId: r.roomId,
        guestName: r.guestName,
        guestPhone: r.guestPhone,
        guestNationalId: r.guestNationalId,
        nationality: r.nationality,
        nights: r.nights,
        pricePerNight: r.pricePerNight,
        discountPercent: r.discountPercent,
        paidAmount: r.depositPaid,
        paymentMethod: r.paymentMethod,
        notes: r.notes,
        ignoreReservationId: r.id,
      });
      if (ok) setReservations((prev) => prev.map((x) => (x.id === id ? { ...x, status: 'checked_in' as const } : x)));
      return ok;
    },
    [reservations, checkIn]
  );

  // ---- Companions staying in the same room ----
  const addCompanion = useCallback(
    (bookingId: number, companion: Omit<Companion, 'id'>): boolean => {
      const { bookings, rooms, housekeeping, guests, payments, logs, settings } = getLatest();
      const booking = bookings.find((b) => b.id === bookingId);
      if (!booking || !booking.isActive) return false;
      if (!companion.name.trim()) {
        alert('اسم المرافق مطلوب.');
        return false;
      }
      const room = rooms.find((r) => r.id === booking.roomId);
      const current = (booking.companions?.length || 0) + 1; // + main guest
      if (room && current + 1 > room.capacity) {
        if (!confirm(`سعة الغرفة ${room.capacity} أشخاص، وسيصبح عدد المقيمين ${current + 1}. هل تريد المتابعة؟`)) return false;
      }
      const newC: Companion = { ...companion, name: companion.name.trim(), id: `cmp-${uid()}` };
      const updatedBookings = bookings.map((b) => (b.id === bookingId ? { ...b, companions: [...(b.companions || []), newC] } : b));
      const newLog: ActivityLog = {
        id: uid(),
        timestamp: localDateTime(),
        action: `إضافة مرافق: الغرفة ${booking.roomNumber}`,
        details: `${newC.name} (${newC.relation}) مع النزيل ${booking.guestName}`,
        category: 'booking',
      };
      setBookings(updatedBookings);
      setLogs([newLog, ...logs]);
      persistChanges(rooms, guests, updatedBookings, housekeeping, payments, [newLog, ...logs], settings);
      return true;
    },
    [persistChanges]
  );

  const removeCompanion = useCallback(
    (bookingId: number, companionId: string) => {
      const { bookings, rooms, housekeeping, guests, payments, logs, settings } = getLatest();
      const updatedBookings = bookings.map((b) =>
        b.id === bookingId ? { ...b, companions: (b.companions || []).filter((c) => c.id !== companionId) } : b
      );
      setBookings(updatedBookings);
      persistChanges(rooms, guests, updatedBookings, housekeeping, payments, logs, settings);
    },
    [persistChanges]
  );

  // ---- Period closings (daily / weekly / monthly / yearly) ----
  /** The closed period (any type) that contains this date, if any. */
  const findClosedPeriod = useCallback((date: string): ClosingRecord | undefined => {
    const d = date.substring(0, 10);
    return closings.find((c) => d >= c.from && d <= c.to);
  }, [closings]);

  const closePeriod = useCallback(
    (type: ClosingType, anchorDate: string): { success: boolean; error?: string; record?: ClosingRecord } => {
      const { rooms, bookings, guests, payments, expenses, otherRevenues, staffSalaries, logs, closings } = getLatest();
      const period = periodFor(type, anchorDate);
      if (period.to > localDate()) return { success: false, error: 'لا يمكن إقفال فترة لم تنتهِ بعد.' };
      if (closings.some((c) => c.type === type && c.key === period.key)) {
        return { success: false, error: 'هذه الفترة مقفلة مسبقاً.' };
      }
      const record: ClosingRecord = {
        id: uid(),
        type,
        key: period.key,
        label: period.label,
        from: period.from,
        to: period.to,
        closedAt: localDateTime(),
        closedBy: currentUser.name,
        figures: computeFigures({ rooms, bookings, guests, payments, expenses, otherRevenues, staffSalaries }, period.from, period.to),
      };
      const newLog: ActivityLog = {
        id: uid(),
        timestamp: localDateTime(),
        action: `إقفال ${CLOSING_TYPE_AR[type]}: ${period.label}`,
        details: `الإيرادات ${record.figures.totalRevenue} • المصروفات ${record.figures.expenses} • الصافي ${record.figures.net}`,
        category: 'finance',
      };
      setClosings([record, ...closings]);
      setLogs([newLog, ...logs]);
      playAlertSound('success');
      return { success: true, record };
    },
    [currentUser, playAlertSound]
  );

  const reopenPeriod = useCallback(
    (id: number) => {
      const { closings, logs } = getLatest();
      const target = closings.find((c) => c.id === id);
      if (!target) return;
      setClosings(closings.filter((c) => c.id !== id));
      const newLog: ActivityLog = {
        id: uid(),
        timestamp: localDateTime(),
        action: `إعادة فتح ${CLOSING_TYPE_AR[target.type]}: ${target.label}`,
        details: `أعاد ${currentUser.name} فتح الفترة المقفلة`,
        category: 'finance',
      };
      setLogs([newLog, ...logs]);
      playAlertSound('ding');
    },
    [currentUser, playAlertSound]
  );

  // Check-Out Action
  const checkOut = useCallback(
    async (roomId: number, balancePaid: number = 0, paymentMethod: PaymentMethod = 'card'): Promise<boolean> => {
      const { rooms, guests, bookings, housekeeping, payments, logs, settings } = getLatest();
      const room = rooms.find((r) => r.id === roomId);
      if (!room || !room.currentBookingId) return false;

      const activeBooking = bookings.find((b) => b.id === room.currentBookingId);
      const checkOutTime = localDateTime();
      const paidNow = Math.max(0, Number(balancePaid) || 0);
      const totalPaid = (activeBooking?.paidAmount ?? 0) + paidNow;
      const outstanding = activeBooking ? Math.max(0, activeBooking.totalAmount - totalPaid) : 0;

      const updatedBookings = bookings.map((b) =>
        b.id === room.currentBookingId
          ? {
              ...b,
              isActive: false,
              actualCheckOutDate: checkOutTime,
              paidAmount: totalPaid,
              paymentStatus: (outstanding > 0 ? (totalPaid > 0 ? 'partial' : 'pending') : 'paid') as Booking['paymentStatus'],
            }
          : b
      );

      let updatedPayments = payments;
      if (paidNow > 0 && activeBooking) {
        const newPayment: Payment = {
          id: uid(),
          bookingId: activeBooking.id,
          guestId: activeBooking.guestId,
          amount: paidNow,
          method: paymentMethod,
          date: checkOutTime,
          receiptNumber: `REC-${uid().toString().slice(-6)}`,
          notes: 'تسوية رصيد المغادرة',
        };
        updatedPayments = [newPayment, ...payments];
      }

      const updatedRooms = rooms.map((r) =>
        r.id === roomId
          ? {
              ...r,
              status: 'cleaning' as RoomStatus,
              currentBookingId: null,
              currentGuestName: null,
              currentGuestPhone: null,
              checkInDate: null,
              checkOutDate: null,
              notes: `تم الخروج في ${checkOutTime} - بانتظار الهاوس كيبينج`,
            }
          : r
      );

      const updatedGuests = paidNow > 0 && activeBooking
        ? guests.map((g) => (g.id === activeBooking.guestId ? { ...g, totalSpent: g.totalSpent + paidNow } : g))
        : guests;

      const newTask: HousekeepingTask = {
        id: uid(),
        roomId: room.id,
        roomNumber: room.roomNumber,
        assignedTo: 'فريق النظافة العام',
        priority: 'urgent',
        status: 'dirty',
        checklist: {
          linensChanged: false,
          bathroomCleaned: false,
          roomDisinfected: false,
          amenitiesRestocked: false,
          floorCleaned: false,
        },
        notes: `مغادرة النزيل ${room.currentGuestName || ''} - مطلوب تجهيز الغرفة`,
        reportedAt: checkOutTime,
      };
      const updatedHousekeeping = [newTask, ...housekeeping.filter((h) => h.roomId !== room.id)];

      const newLog: ActivityLog = {
        id: uid(),
        timestamp: checkOutTime,
        action: `تسجيل مغادرة: الغرفة ${room.roomNumber}`,
        details: `تمت المغادرة للنزيل ${room.currentGuestName || ''} وتم تحويل الغرفة إلى الهاوس كيبينج${outstanding > 0 ? ` — رصيد غير مسدد: ${outstanding} ر.ي` : ''}`,
        category: 'booking',
      };
      const updatedLogs = [newLog, ...logs];

      setRooms(updatedRooms);
      setBookings(updatedBookings);
      setPayments(updatedPayments);
      setGuests(updatedGuests);
      setHousekeeping(updatedHousekeeping);
      setLogs(updatedLogs);

      if (selectedRoom?.id === roomId) {
        setSelectedRoom(updatedRooms.find((r) => r.id === roomId) || null);
      }

      persistChanges(updatedRooms, updatedGuests, updatedBookings, updatedHousekeeping, updatedPayments, updatedLogs, settings);
      playAlertSound('ding');
      return true;
    },
    [rooms, bookings, housekeeping, payments, logs, guests, settings, selectedRoom, playAlertSound, persistChanges]
  );

  const cancelBooking = useCallback(
    (bookingId: number): boolean => {
      const { rooms, guests, bookings, housekeeping, payments, logs, settings } = getLatest();
      const booking = bookings.find((b) => b.id === bookingId);
      if (!booking) return false;
      if (!booking.isActive) {
        alert('لا يمكن إلغاء حجز منتهٍ أو ملغى مسبقاً.');
        return false;
      }

      const updatedBookings = bookings.map((b) =>
        b.id === bookingId ? { ...b, isActive: false, notes: `${b.notes || ''} [ملغي]`.trim() } : b
      );

      // If room is occupied by this booking, free it
      const updatedRooms = rooms.map((r) =>
        r.currentBookingId === bookingId
          ? {
              ...r,
              status: 'available' as RoomStatus,
              currentBookingId: null,
              currentGuestName: null,
              currentGuestPhone: null,
              checkInDate: null,
              checkOutDate: null,
            }
          : r
      );

      const newLog: ActivityLog = {
        id: uid(),
        timestamp: localDateTime(),
        action: `إلغاء حجز #${booking.bookingCode}`,
        details: `تم إلغاء الحجز للغرفة ${booking.roomNumber} للنزيل ${booking.guestName}`,
        category: 'booking',
      };

      setBookings(updatedBookings);
      setRooms(updatedRooms);
      setLogs([newLog, ...logs]);
      persistChanges(updatedRooms, guests, updatedBookings, housekeeping, payments, [newLog, ...logs], settings);
      playAlertSound('ding');
      return true;
    },
    [bookings, rooms, logs, guests, housekeeping, payments, settings, persistChanges, playAlertSound]
  );

  // Complete Housekeeping
  const completeHousekeeping = useCallback(
    async (roomId: number) => {
      const { rooms, guests, bookings, housekeeping, payments, logs, settings } = getLatest();
      const room = rooms.find((r) => r.id === roomId);
      if (!room) return;

      const canRelease = room.status === 'cleaning';
      const updatedRooms = rooms.map((r) =>
        r.id === roomId && canRelease
          ? {
              ...r,
              status: 'available' as RoomStatus,
              notes: 'الغرفة نظيفة وجاهزة للحجز الفوري',
            }
          : r
      );

      const completedTime = localDateTime();
      const updatedHousekeeping = housekeeping.map((h) =>
        h.roomId === roomId
          ? {
              ...h,
              status: 'clean' as const,
              completedAt: completedTime,
              checklist: {
                linensChanged: true,
                bathroomCleaned: true,
                roomDisinfected: true,
                amenitiesRestocked: true,
                floorCleaned: true,
              },
            }
          : h
      );

      const newLog: ActivityLog = {
        id: uid(),
        timestamp: completedTime,
        action: `اكتمال تنظيف الغرفة ${room.roomNumber}`,
        details: 'تم إنهاء الهاوس كيبينج بنجاح وعادت الغرفة إلى الحالة (متاحة)',
        category: 'housekeeping',
      };
      const updatedLogs = [newLog, ...logs];

      setRooms(updatedRooms);
      setHousekeeping(updatedHousekeeping);
      setLogs(updatedLogs);

      if (selectedRoom?.id === roomId) {
        setSelectedRoom(updatedRooms.find((r) => r.id === roomId) || null);
      }

      persistChanges(updatedRooms, guests, bookings, updatedHousekeeping, payments, updatedLogs, settings);
      playAlertSound('success');
    },
    [rooms, housekeeping, logs, guests, bookings, payments, settings, selectedRoom, playAlertSound, persistChanges]
  );

  const updateHousekeepingStatus = (taskId: number, status: 'dirty' | 'in_progress' | 'inspected' | 'clean') => {
    const { rooms, guests, bookings, housekeeping, payments, logs, settings } = getLatest();
    const updated = housekeeping.map((h) => (h.id === taskId ? { ...h, status } : h));
    setHousekeeping(updated);
    if (status === 'clean') {
      const task = housekeeping.find((h) => h.id === taskId);
      if (task) {
        completeHousekeeping(task.roomId);
      }
    } else {
      persistChanges(rooms, guests, bookings, updated, payments, logs, settings);
    }
  };

  const toggleHousekeepingChecklist = (taskId: number, item: keyof HousekeepingTask['checklist']) => {
    const { rooms, guests, bookings, housekeeping, payments, logs, settings } = getLatest();
    const updated = housekeeping.map((h) => {
      if (h.id === taskId) {
        const nextChecklist = {
          ...h.checklist,
          [item]: !h.checklist[item],
        };
        const allDone = Object.values(nextChecklist).every(Boolean);
        return {
          ...h,
          checklist: nextChecklist,
          status: allDone ? ('clean' as const) : ('in_progress' as const),
        };
      }
      return h;
    });
    const target = updated.find((h) => h.id === taskId);
    if (target && target.status === 'clean') {
      // keep room status in sync with the finished task
      completeHousekeeping(target.roomId);
      return;
    }
    setHousekeeping(updated);
    persistChanges(rooms, guests, bookings, updated, payments, logs, settings);
  };

  const assignHousekeeper = (taskId: number, name: string) => {
    const { rooms, guests, bookings, housekeeping, payments, logs, settings } = getLatest();
    const updated = housekeeping.map((h) => (h.id === taskId ? { ...h, assignedTo: name } : h));
    setHousekeeping(updated);
    persistChanges(rooms, guests, bookings, updated, payments, logs, settings);
  };

  const updateRoomStatus = (roomId: number, status: RoomStatus, notes?: string) => {
    const { rooms, guests, bookings, housekeeping, payments, logs, settings } = getLatest();
    const updated = rooms.map((r) => (r.id === roomId ? { ...r, status, notes: notes !== undefined ? notes : r.notes } : r));
    setRooms(updated);
    if (selectedRoom?.id === roomId) {
      setSelectedRoom(updated.find((r) => r.id === roomId) || null);
    }
    persistChanges(updated, guests, bookings, housekeeping, payments, logs, settings);
  };

  const addAdditionalCharge = (bookingId: number, description: string, amount: number) => {
    const { rooms, guests, bookings, housekeeping, payments, logs, settings } = getLatest();
    if (!description.trim() || !Number.isFinite(amount) || amount <= 0) {
      alert('أدخل وصفاً ومبلغاً صحيحاً أكبر من صفر.');
      return;
    }
    const updatedBookings = bookings.map((b) => {
      if (b.id === bookingId) {
        const newCharges = [
          ...b.additionalCharges,
          {
            id: `ch-${uid()}`,
            description,
            amount,
            date: localDate(),
          },
        ];
        const newTotal = b.roomTotal + newCharges.reduce((sum, ch) => sum + ch.amount, 0);
        return {
          ...b,
          additionalCharges: newCharges,
          totalAmount: newTotal,
          paymentStatus: (b.paidAmount >= newTotal ? 'paid' : 'partial') as any,
        };
      }
      return b;
    });
    setBookings(updatedBookings);
    persistChanges(rooms, guests, updatedBookings, housekeeping, payments, logs, settings);
    playAlertSound('ding');
  };

  const extendBookingNights = (bookingId: number, extraNights: number) => {
    const { rooms, guests, bookings, housekeeping, payments, logs, settings } = getLatest();
    extraNights = Math.floor(Number(extraNights));
    if (!Number.isFinite(extraNights) || extraNights < 1 || extraNights > 365) {
      alert('عدد ليالي التمديد يجب أن يكون بين 1 و 365.');
      return;
    }
    let newRoomCheckout = null as string | null;
    const updatedBookings = bookings.map((b) => {
      if (b.id === bookingId) {
        const newNights = b.nights + extraNights;
        const extraRoomPrice = Math.round(b.pricePerNight * extraNights * (1 - b.discountPercent / 100));
        const newRoomTotal = b.roomTotal + extraRoomPrice;
        const newTotal = newRoomTotal + b.additionalCharges.reduce((sum, ch) => sum + ch.amount, 0);

        const [dPart] = b.expectedCheckOutDate.split(' ');
        const newCheckoutDate = addDaysToDateStr(dPart, extraNights);
        const newCheckoutStr = `${newCheckoutDate} ${settings.checkOutTime}`;
        newRoomCheckout = newCheckoutDate;

        return {
          ...b,
          nights: newNights,
          roomTotal: newRoomTotal,
          totalAmount: newTotal,
          expectedCheckOutDate: newCheckoutStr,
          paymentStatus: (b.paidAmount >= newTotal ? 'paid' : 'partial') as any,
        };
      }
      return b;
    });

    const updatedRooms = newRoomCheckout
      ? rooms.map((r) => (r.currentBookingId === bookingId ? { ...r, checkOutDate: newRoomCheckout } : r))
      : rooms;
    setBookings(updatedBookings);
    setRooms(updatedRooms);
    if (selectedRoom?.currentBookingId === bookingId) {
      setSelectedRoom(updatedRooms.find((r) => r.id === selectedRoom.id) || selectedRoom);
    }
    persistChanges(updatedRooms, guests, updatedBookings, housekeeping, payments, logs, settings);
    playAlertSound('success');
  };

  // Room CRUD Operations
  const addRoom = useCallback(
    (roomData: Omit<Room, 'id'>): { success: boolean; room?: Room; error?: string } => {
      const { rooms, guests, bookings, housekeeping, payments, logs, settings } = getLatest();
      const cleanNumber = roomData.roomNumber.trim();
      if (!cleanNumber) {
        return { success: false, error: 'يرجى إدخال رقم الغرفة' };
      }

      const exists = rooms.some((r) => r.roomNumber.toLowerCase() === cleanNumber.toLowerCase());
      if (exists) {
        return { success: false, error: `الغرفة رقم ${cleanNumber} مسجلة مسبقاً في النظام.` };
      }

      const newRoom: Room = {
        ...roomData,
        id: uid(),
        roomNumber: cleanNumber,
        features: roomData.features && roomData.features.length > 0
          ? roomData.features
          : ['واي فاي فائق السرعة', 'تكييف هواء', 'شاشة ذكية', 'ثلاجة وميني بار'],
      };

      const newRoomsList = [...rooms, newRoom].sort((a, b) => {
        const numA = parseInt(a.roomNumber, 10) || 0;
        const numB = parseInt(b.roomNumber, 10) || 0;
        return numA - numB;
      });

      const newLog: ActivityLog = {
        id: uid(),
        timestamp: localDateTime(),
        action: `إضافة غرفة جديدة: #${cleanNumber}`,
        details: `تمت إضافة الغرفة بنجاح في الطابق ${newRoom.floor} بسعر ${newRoom.pricePerNight} ر.ي/ليلة`,
        category: 'room',
      };

      setRooms(newRoomsList);
      setLogs([newLog, ...logs]);
      persistChanges(newRoomsList, guests, bookings, housekeeping, payments, [newLog, ...logs], settings);
      playAlertSound('success');
      return { success: true, room: newRoom };
    },
    [rooms, guests, bookings, housekeeping, payments, logs, settings, persistChanges, playAlertSound]
  );

  const deleteRoom = useCallback(
    (roomId: number): { success: boolean; error?: string } => {
      const { rooms, guests, bookings, housekeeping, payments, logs, settings } = getLatest();
      const targetRoom = rooms.find((r) => r.id === roomId);
      if (!targetRoom) {
        return { success: false, error: 'الغرفة غير موجودة.' };
      }

      if (targetRoom.status === 'occupied' || targetRoom.currentBookingId) {
        return {
          success: false,
          error: `لا يمكن حذف الغرفة #${targetRoom.roomNumber} لأنها مشغولة بحجز نشط. يرجى تسجيل المغادرة أولاً.`,
        };
      }

      const updatedRooms = rooms.filter((r) => r.id !== roomId);
      const updatedHousekeeping = housekeeping.filter((h) => h.roomId !== roomId);

      const newLog: ActivityLog = {
        id: uid(),
        timestamp: localDateTime(),
        action: `حذف غرفة: #${targetRoom.roomNumber}`,
        details: `تم حذف الغرفة رقم ${targetRoom.roomNumber} من قاعدة البيانات نهائياً`,
        category: 'room',
      };

      setRooms(updatedRooms);
      setHousekeeping(updatedHousekeeping);
      setLogs([newLog, ...logs]);
      if (selectedRoom?.id === roomId) {
        setSelectedRoom(null);
      }

      persistChanges(updatedRooms, guests, bookings, updatedHousekeeping, payments, [newLog, ...logs], settings);
      playAlertSound('ding');
      return { success: true };
    },
    [rooms, housekeeping, logs, guests, bookings, payments, settings, selectedRoom, persistChanges, playAlertSound]
  );

  const updateRoom = useCallback(
    (roomId: number, updates: Partial<Room>): Room | undefined => {
      const { rooms, guests, bookings, housekeeping, payments, logs, settings } = getLatest();
      let updatedRoom: Room | undefined;
      const updatedRooms = rooms.map((r) => {
        if (r.id === roomId) {
          updatedRoom = { ...r, ...updates };
          return updatedRoom;
        }
        return r;
      });

      if (updatedRoom) {
        setRooms(updatedRooms);
        persistChanges(updatedRooms, guests, bookings, housekeeping, payments, logs, settings);
      }
      return updatedRoom;
    },
    [rooms, guests, bookings, housekeeping, payments, logs, settings, persistChanges]
  );

  // Guest CRUD Operations
  const addGuest = useCallback(
    (guestData: Partial<Guest>): { success: boolean; guest?: Guest; error?: string } => {
      const { rooms, guests, bookings, housekeeping, payments, logs, settings } = getLatest();
      const cleanPhone = (guestData.phone || '').trim();
      const cleanName = (guestData.name || '').trim();

      if (!cleanName) return { success: false, error: 'يرجى إدخال اسم العميل.' };
      if (!cleanPhone) return { success: false, error: 'يرجى إدخال رقم هاتف العميل.' };

      const existing = guests.find((g) => g.phone === cleanPhone);
      if (existing) {
        return { success: false, error: `العميل (${existing.name}) مسجل مسبقاً بهذا الرقم: ${cleanPhone}` };
      }

      const now = localDate();
      const newGuest: Guest = {
        id: uid(),
        name: cleanName,
        phone: cleanPhone,
        nationalId: (guestData.nationalId || '').trim(),
        nationality: guestData.nationality || 'يمني',
        email: guestData.email?.trim(),
        visitCount: guestData.visitCount || 1,
        isFrequent: guestData.isFrequent || (guestData.visitCount ? guestData.visitCount >= settings.frequentGuestThreshold : false),
        loyaltyDiscountPercent: guestData.loyaltyDiscountPercent || (guestData.isFrequent ? settings.defaultLoyaltyDiscount : 0),
        totalSpent: guestData.totalSpent || 0,
        isVip: guestData.isVip || false,
        notes: guestData.notes,
        photo: guestData.photo,
        idImage: guestData.idImage,
        createdAt: now,
        lastVisitDate: now,
      };

      const newGuestsList = [newGuest, ...guests];
      const newLog: ActivityLog = {
        id: uid(),
        timestamp: localDateTime(),
        action: `إضافة عميل جديد: ${cleanName}`,
        details: `تم تسجيل العميل بنجاح بهاتف ${cleanPhone}`,
        category: 'guest',
      };

      setGuests(newGuestsList);
      setLogs([newLog, ...logs]);
      persistChanges(rooms, newGuestsList, bookings, housekeeping, payments, [newLog, ...logs], settings);
      playAlertSound('success');
      return { success: true, guest: newGuest };
    },
    [guests, rooms, bookings, housekeeping, payments, logs, settings, persistChanges, playAlertSound]
  );

  const deleteGuest = useCallback(
    (guestId: number): { success: boolean; error?: string } => {
      const { rooms, guests, bookings, housekeeping, payments, logs, settings } = getLatest();
      const target = guests.find((g) => g.id === guestId);
      if (!target) return { success: false, error: 'العميل غير موجود.' };

      const hasActiveStay = bookings.some((b) => b.guestId === guestId && b.isActive);
      const isOccupyingRoom = rooms.some(
        (r) => r.status === 'occupied' && (r.currentGuestPhone === target.phone || r.currentGuestName === target.name)
      );

      if (hasActiveStay || isOccupyingRoom) {
        return {
          success: false,
          error: `لا يمكن حذف العميل (${target.name}) لأنه مسجل حالياً في إقامة نشطة بالفندق. يرجى تسجيل المغادرة أولاً.`,
        };
      }

      const updatedGuests = guests.filter((g) => g.id !== guestId);
      const newLog: ActivityLog = {
        id: uid(),
        timestamp: localDateTime(),
        action: `حذف عميل: ${target.name}`,
        details: `تم حذف بيانات العميل (${target.name}) من قاعدة البيانات`,
        category: 'guest',
      };

      setGuests(updatedGuests);
      setLogs([newLog, ...logs]);
      persistChanges(rooms, updatedGuests, bookings, housekeeping, payments, [newLog, ...logs], settings);
      playAlertSound('ding');
      return { success: true };
    },
    [guests, bookings, rooms, housekeeping, payments, logs, settings, persistChanges, playAlertSound]
  );

  const updateGuest = useCallback(
    (guestId: number, updates: Partial<Guest>): Guest | undefined => {
      const { rooms, guests, bookings, housekeeping, payments, logs, settings } = getLatest();
      let updatedGuest: Guest | undefined;
      const updatedGuests = guests.map((g) => {
        if (g.id === guestId) {
          const visitCount = updates.visitCount !== undefined ? updates.visitCount : g.visitCount;
          const isFrequent = updates.isFrequent !== undefined ? updates.isFrequent : visitCount >= settings.frequentGuestThreshold;
          const loyaltyDiscountPercent =
            updates.loyaltyDiscountPercent !== undefined
              ? updates.loyaltyDiscountPercent
              : isFrequent
              ? Math.max(g.loyaltyDiscountPercent, settings.defaultLoyaltyDiscount)
              : g.loyaltyDiscountPercent;

          updatedGuest = {
            ...g,
            ...updates,
            visitCount,
            isFrequent,
            loyaltyDiscountPercent,
          };
          return updatedGuest;
        }
        return g;
      });

      if (updatedGuest) {
        setGuests(updatedGuests);
        persistChanges(rooms, updatedGuests, bookings, housekeeping, payments, logs, settings);
      }
      return updatedGuest;
    },
    [guests, rooms, bookings, housekeeping, payments, logs, settings, persistChanges]
  );

  // Link Customer to Room
  const linkGuestToRoom = useCallback(
    async (params: LinkGuestParams): Promise<boolean> => {
      const { rooms, guests, bookings, housekeeping, payments, logs, settings } = getLatest();
      const targetRoom = rooms.find((r) => r.id === params.roomId);
      const targetGuest = guests.find((g) => g.id === params.guestId);

      if (!targetRoom || !targetGuest) return false;

      if (targetGuest.isBlacklisted) {
        alert(`النزيل ${targetGuest.name} مدرج في القائمة السوداء ولا يمكن تسكينه.`);
        return false;
      }

      const pricePerNight = Number(params.pricePerNight || targetRoom.pricePerNight);
      const nights = Math.floor(Number(params.nights || 1));
      const stayError = validateStay(targetRoom, nights, pricePerNight, Number(params.discountPercent) || 0);
      if (stayError) {
        alert(stayError);
        return false;
      }
      const discountPercent =
        params.discountPercent !== undefined
          ? params.discountPercent
          : targetGuest.isFrequent
          ? targetGuest.loyaltyDiscountPercent || settings.defaultLoyaltyDiscount
          : 0;

      const roomTotal = Math.round(pricePerNight * nights * (1 - discountPercent / 100));
      const paidAmount = Math.min(Math.max(0, Number(params.paidAmount ?? roomTotal) || 0), roomTotal);
      const paymentMethod = params.paymentMethod || 'card';

      const today = new Date();
      const checkInStr = localDateTime(today);
      const checkOutStr = `${addDaysToDateStr(localDate(today), nights)} ${settings.checkOutTime}`;

      const bookingId = uid();
      const bookingCode = generateBookingCode(bookings.map((b) => b.bookingCode));

      const newBooking: Booking = {
        id: bookingId,
        bookingCode,
        roomId: targetRoom.id,
        roomNumber: targetRoom.roomNumber,
        guestId: targetGuest.id,
        guestName: targetGuest.name,
        guestPhone: targetGuest.phone,
        guestNationalId: targetGuest.nationalId,
        checkInDate: checkInStr,
        expectedCheckOutDate: checkOutStr,
        nights,
        pricePerNight,
        discountPercent,
        roomTotal,
        additionalCharges: [],
        totalAmount: roomTotal,
        paidAmount,
        paymentStatus: paidAmount >= roomTotal ? 'paid' : paidAmount > 0 ? 'partial' : 'pending',
        paymentMethod,
        isActive: true,
        notes: params.notes,
        createdAt: localDateTime(),
      };

      const updatedRooms = rooms.map((r) =>
        r.id === targetRoom.id
          ? {
              ...r,
              status: 'occupied' as RoomStatus,
              currentBookingId: bookingId,
              currentGuestName: targetGuest.name,
              currentGuestPhone: targetGuest.phone,
              checkInDate: checkInStr.substring(0, 10),
              checkOutDate: checkOutStr.substring(0, 10),
              notes: params.notes || r.notes,
            }
          : r
      );

      let updatedPayments = payments;
      if (paidAmount > 0) {
        const newPayment: Payment = {
          id: uid(),
          bookingId,
          guestId: targetGuest.id,
          amount: paidAmount,
          method: paymentMethod,
          date: checkInStr,
          receiptNumber: `REC-${uid().toString().slice(-6)}`,
          notes: 'تسديد إقامة عند الربط والتسكين',
        };
        updatedPayments = [newPayment, ...payments];
      }

      const updatedGuests = guests.map((g) =>
        g.id === targetGuest.id
          ? {
              ...g,
              visitCount: g.visitCount + 1,
              isFrequent: g.visitCount + 1 >= settings.frequentGuestThreshold,
              totalSpent: g.totalSpent + paidAmount,
              lastVisitDate: localDate(today),
            }
          : g
      );

      const newLog: ActivityLog = {
        id: uid(),
        timestamp: localDateTime(),
        action: `ربط وتسكين العميل: ${targetGuest.name}`,
        details: `تم تسكين العميل في الغرفة ${targetRoom.roomNumber} لمدة ${nights} ليال بمبلغ ${roomTotal} ر.ي`,
        category: 'booking',
      };

      setRooms(updatedRooms);
      setBookings([newBooking, ...bookings]);
      setPayments(updatedPayments);
      setGuests(updatedGuests);
      setLogs([newLog, ...logs]);

      persistChanges(updatedRooms, updatedGuests, [newBooking, ...bookings], housekeeping, updatedPayments, [newLog, ...logs], settings);
      playAlertSound('success');
      return true;
    },
    [rooms, guests, bookings, housekeeping, payments, logs, settings, persistChanges, playAlertSound]
  );

  // Financial Actions (Expenses, Other Revenues, Staff Salaries)
  const addExpense = useCallback(
    (expenseData: Omit<ExpenseRecord, 'id' | 'expenseCode'>): ExpenseRecord => {
      const { logs, expenses } = getLatest();
      const id = uid();
      const expenseCode = `EXP-${new Date().getFullYear()}-${String(expenses.length + 1).padStart(3, '0')}`;
      const newExpense: ExpenseRecord = {
        ...expenseData,
        id,
        expenseCode,
      };

      const updatedExpenses = [newExpense, ...expenses];
      const newLog: ActivityLog = {
        id: uid(),
        timestamp: localDateTime(),
        action: `تسجيل مصروف: ${newExpense.title}`,
        details: `مبلغ ${newExpense.amount} ر.ي (${newExpense.category}) - المستلم: ${newExpense.recipientName}`,
        category: 'finance',
      };

      setExpenses(updatedExpenses);
      setLogs([newLog, ...logs]);
      playAlertSound('ding');
      return newExpense;
    },
    [expenses, logs, playAlertSound]
  );

  const deleteExpense = useCallback(
    (id: number) => {
      setExpenses((prev) => prev.filter((e) => e.id !== id));
      playAlertSound('ding');
    },
    [playAlertSound]
  );

  const addOtherRevenue = useCallback(
    (revData: Omit<OtherRevenueRecord, 'id' | 'revenueCode'>): OtherRevenueRecord => {
      const { logs, otherRevenues } = getLatest();
      const id = uid();
      const revenueCode = `REV-${new Date().getFullYear()}-${String(otherRevenues.length + 1).padStart(3, '0')}`;
      const newRev: OtherRevenueRecord = {
        ...revData,
        id,
        revenueCode,
      };

      const updated = [newRev, ...otherRevenues];
      const newLog: ActivityLog = {
        id: uid(),
        timestamp: localDateTime(),
        action: `تسجيل إيراد إضافي: ${newRev.title}`,
        details: `مبلغ ${newRev.amount} ر.ي (${newRev.category}) - سند: ${newRev.receiptNumber}`,
        category: 'finance',
      };

      setOtherRevenues(updated);
      setLogs([newLog, ...logs]);
      playAlertSound('success');
      return newRev;
    },
    [otherRevenues, logs, playAlertSound]
  );

  const deleteOtherRevenue = useCallback(
    (id: number) => {
      setOtherRevenues((prev) => prev.filter((r) => r.id !== id));
      playAlertSound('ding');
    },
    [playAlertSound]
  );

  const recordSalaryPayment = useCallback(
    (salaryData: Omit<StaffSalaryRecord, 'id' | 'slipCode'>): StaffSalaryRecord => {
      const { logs, staffSalaries } = getLatest();
      const id = uid();
      const slipCode = `SAL-${salaryData.month.replace('-', '')}-${String(staffSalaries.length + 1).padStart(2, '0')}`;
      const newSalary: StaffSalaryRecord = {
        ...salaryData,
        id,
        slipCode,
      };

      const updated = [newSalary, ...staffSalaries];
      const newLog: ActivityLog = {
        id: uid(),
        timestamp: localDateTime(),
        action: `صرف راتب موظف: ${salaryData.staffName}`,
        details: `صافي الراتب ${salaryData.netSalary} ر.ي لشهر ${salaryData.month} (${salaryData.roleTitleAr})`,
        category: 'staff',
      };

      setStaffSalaries(updated);
      setLogs([newLog, ...logs]);
      playAlertSound('success');
      return newSalary;
    },
    [staffSalaries, logs, playAlertSound]
  );

  const addStaffMember = useCallback(
    (staffData: Omit<StaffMember, 'id'>): StaffMember => {
      const newStaff: StaffMember = {
        ...staffData,
        id: uid(),
      };
      setStaffMembers((prev) => [...prev, newStaff]);
      playAlertSound('success');
      return newStaff;
    },
    [playAlertSound]
  );

  const updateStaffMember = useCallback(
    (id: number, updates: Partial<StaffMember>) => {
      setStaffMembers((prev) => prev.map((s) => (s.id === id ? { ...s, ...updates } : s)));
    },
    []
  );

  const deleteStaffMember = useCallback(
    (id: number) => {
      setStaffMembers((prev) => prev.filter((s) => s.id !== id));
      playAlertSound('ding');
    },
    [playAlertSound]
  );

  const switchUser = useCallback(
    (username: string) => {
      const { staffMembers } = getLatest();
      if (username === 'admin' || username === 'reception') {
        setCurrentUser({ ...systemProfiles[username], lastLogin: localDateTimeSec() });
      } else {
        const found = username.trim()
          ? staffMembers.find((s) => s.status !== 'resigned' && (s.username === username || s.name.includes(username)))
          : undefined;
        if (found) {
          setCurrentUser({
            id: found.id,
            username: found.username || 'user',
            name: found.name,
            role: found.role,
            roleAr: found.roleTitleAr,
            email: '',
            phone: found.phone,
            shift: 'شفت الاستقبال',
            lastLogin: localDateTimeSec(),
            permissions: ['تسكين وحجز الغرف', 'طلبات خدمة الغرف', 'إصدار الفواتير'],
          });
        }
      }
      playAlertSound('success');
    },
    [staffMembers, systemProfiles, playAlertSound]
  );

  // Customer Account Payments
  const recordGuestPayment = useCallback(
    (params: GuestPaymentParams): Payment => {
      const { rooms, guests, bookings, housekeeping, payments, logs, settings } = getLatest();
      const receiptNumber = params.receiptNumber || `REC-${uid().toString().slice(-6)}`;
      const dateStr = localDateTime();

      const newPayment: Payment = {
        id: uid(),
        bookingId: params.bookingId || 0,
        guestId: params.guestId,
        amount: params.amount,
        method: params.method,
        date: dateStr,
        receiptNumber,
        notes: params.notes || 'سند قبض ودفع رصيد للعميل',
      };

      const updatedPayments = [newPayment, ...payments];
      const updatedGuests = guests.map((g) =>
        g.id === params.guestId ? { ...g, totalSpent: g.totalSpent + params.amount } : g
      );

      const newLog: ActivityLog = {
        id: uid(),
        timestamp: dateStr,
        action: `سند قبض لعميل`,
        details: `تم استلام مبلغ ${params.amount} ر.ي بالسند ${receiptNumber}`,
        category: 'payment',
      };

      setPayments(updatedPayments);
      setGuests(updatedGuests);
      setLogs([newLog, ...logs]);

      persistChanges(rooms, updatedGuests, bookings, housekeeping, updatedPayments, [newLog, ...logs], settings);
      playAlertSound('success');
      return newPayment;
    },
    [payments, guests, logs, rooms, bookings, housekeeping, settings, persistChanges, playAlertSound]
  );

  // Room Service Core Operations
  const createRoomServiceOrder = useCallback(
    (orderData: Omit<RoomServiceOrder, 'id' | 'orderCode' | 'createdAt'>) => {
      const { rooms, guests, bookings, housekeeping, payments, logs, settings, roomServiceMenu, roomServiceOrders } = getLatest();
      const orderId = uid();
      const orderCode = `RSO-${orderData.roomNumber}-${uid().toString().slice(-5)}`;
      const createdAt = localDateTime();

      const newOrder: RoomServiceOrder = {
        ...orderData,
        id: orderId,
        orderCode,
        createdAt,
      };

      const updatedOrders = [newOrder, ...roomServiceOrders];
      let finalBookings = bookings;

      if (orderData.chargeTo === 'room_bill' && orderData.bookingId) {
        const targetBooking = bookings.find((b) => b.id === orderData.bookingId);
        if (targetBooking) {
          const newCharge = {
            id: `ch-rs-${orderId}`,
            description: `خدمة غرف: طلب #${orderCode}`,
            amount: newOrder.totalAmount,
            date: createdAt.substring(0, 10),
          };
          const updatedBookings = bookings.map((b) => {
            if (b.id === orderData.bookingId) {
              const updatedCharges = [...b.additionalCharges, newCharge];
              const totalAmount = b.roomTotal + updatedCharges.reduce((sum, ch) => sum + ch.amount, 0);
              return {
                ...b,
                additionalCharges: updatedCharges,
                totalAmount,
                paymentStatus: (b.paidAmount >= totalAmount ? 'paid' : 'partial') as any,
              };
            }
            return b;
          });
          finalBookings = updatedBookings;
          setBookings(updatedBookings);
        }
      }

      const newLog: ActivityLog = {
        id: uid(),
        timestamp: createdAt,
        action: `طلب خدمة غرف جديد: الغرفة ${newOrder.roomNumber}`,
        details: `طلب #${orderCode} بقيمة ${newOrder.totalAmount} ر.ي (${newOrder.items.length} أصناف)`,
        category: 'room_service',
      };

      setRoomServiceOrders(updatedOrders);
      setLogs([newLog, ...logs]);
      persistChanges(rooms, guests, finalBookings, housekeeping, payments, [newLog, ...logs], settings, roomServiceMenu, updatedOrders);
      playAlertSound('success');
      return { success: true, order: newOrder };
    },
    [roomServiceOrders, bookings, logs, rooms, guests, housekeeping, payments, settings, roomServiceMenu, persistChanges, playAlertSound]
  );

  const updateRoomServiceOrderStatus = useCallback(
    (orderId: number, newStatus: RoomServiceOrderStatus, staffName?: string) => {
      const { rooms, guests, bookings, housekeeping, payments, logs, settings, roomServiceMenu, roomServiceOrders } = getLatest();
      const now = localDateTime();
      const updatedOrders = roomServiceOrders.map((o) => {
        if (o.id === orderId) {
          return {
            ...o,
            status: newStatus,
            assignedStaff: staffName || o.assignedStaff,
            completedAt: newStatus === 'delivered' ? now : o.completedAt,
            isPaid: newStatus === 'delivered' && o.chargeTo !== 'room_bill' ? true : o.isPaid,
          };
        }
        return o;
      });

      setRoomServiceOrders(updatedOrders);
      persistChanges(rooms, guests, bookings, housekeeping, payments, logs, settings, roomServiceMenu, updatedOrders);
      playAlertSound('ding');
    },
    [roomServiceOrders, rooms, guests, bookings, housekeeping, payments, logs, settings, roomServiceMenu, persistChanges, playAlertSound]
  );

  const addRoomServiceMenuItem = useCallback(
    (itemData: Omit<RoomServiceItem, 'id'>) => {
      const { rooms, guests, bookings, housekeeping, payments, logs, settings, roomServiceMenu, roomServiceOrders } = getLatest();
      const newItem: RoomServiceItem = {
        ...itemData,
        id: uid(),
      };
      const updatedMenu = [...roomServiceMenu, newItem];
      setRoomServiceMenu(updatedMenu);
      persistChanges(rooms, guests, bookings, housekeeping, payments, logs, settings, updatedMenu, roomServiceOrders);
      playAlertSound('success');
      return { success: true, item: newItem };
    },
    [roomServiceMenu, rooms, guests, bookings, housekeeping, payments, logs, settings, roomServiceOrders, persistChanges, playAlertSound]
  );

  const updateRoomServiceMenuItem = useCallback(
    (itemId: number, updates: Partial<RoomServiceItem>) => {
      const { rooms, guests, bookings, housekeeping, payments, logs, settings, roomServiceMenu, roomServiceOrders } = getLatest();
      const updatedMenu = roomServiceMenu.map((m) => (m.id === itemId ? { ...m, ...updates } : m));
      setRoomServiceMenu(updatedMenu);
      persistChanges(rooms, guests, bookings, housekeeping, payments, logs, settings, updatedMenu, roomServiceOrders);
    },
    [roomServiceMenu, rooms, guests, bookings, housekeeping, payments, logs, settings, roomServiceOrders, persistChanges]
  );

  const deleteRoomServiceMenuItem = useCallback(
    (itemId: number) => {
      const { rooms, guests, bookings, housekeeping, payments, logs, settings, roomServiceMenu, roomServiceOrders } = getLatest();
      const updatedMenu = roomServiceMenu.filter((m) => m.id !== itemId);
      setRoomServiceMenu(updatedMenu);
      persistChanges(rooms, guests, bookings, housekeeping, payments, logs, settings, updatedMenu, roomServiceOrders);
      return { success: true };
    },
    [roomServiceMenu, rooms, guests, bookings, housekeeping, payments, logs, settings, roomServiceOrders, persistChanges]
  );

  const toggleRoomServiceItemAvailability = useCallback(
    (itemId: number) => {
      const { rooms, guests, bookings, housekeeping, payments, logs, settings, roomServiceMenu, roomServiceOrders } = getLatest();
      const updatedMenu = roomServiceMenu.map((m) => (m.id === itemId ? { ...m, isAvailable: !m.isAvailable } : m));
      setRoomServiceMenu(updatedMenu);
      persistChanges(rooms, guests, bookings, housekeeping, payments, logs, settings, updatedMenu, roomServiceOrders);
    },
    [roomServiceMenu, rooms, guests, bookings, housekeeping, payments, logs, settings, roomServiceOrders, persistChanges]
  );

  const printRoomServiceOrderTicket = useCallback(
    (order: RoomServiceOrder) => {
      const { settings } = getLatest();
      const sym = settings.currencySymbol;
      exportArabicPdf(
        {
          hotelName: settings.hotelName,
          hotelAddress: settings.address,
          title: 'تذكرة طلب خدمة الغرف',
          metaRight: [
            ['رقم الطلب', order.orderCode],
            ['الغرفة', order.roomNumber],
            ['النزيل', order.guestName],
          ],
          metaLeft: [
            ['التاريخ', order.createdAt],
            ['طريقة المحاسبة', order.chargeTo === 'room_bill' ? 'على حساب الغرفة' : 'دفع مباشر'],
          ],
          columns: [
            { header: '#', width: 1, align: 'center' },
            { header: 'الصنف / الخدمة', width: 5 },
            { header: 'الكمية', width: 1.6, align: 'center' },
            { header: 'سعر الوحدة', width: 2.2, align: 'center' },
            { header: 'الإجمالي', width: 2.2, align: 'center' },
          ],
          rows: order.items.map((it, idx) => [idx + 1, it.name, it.quantity, money(it.price, sym), money(it.price * it.quantity, sym)]),
          totals: [
            ['المجموع الفرعي', money(order.subtotal, sym)],
            ['ضريبة القيمة المضافة', money(order.tax, sym)],
            ['الإجمالي الكلي', money(order.totalAmount, sym)],
          ],
          note: order.notes ? `ملاحظات: ${order.notes}` : undefined,
        },
        `تذكرة-طلب-${order.orderCode}`
      );
    },
    [settings]
  );

  // SQLite Engine Database Tools
  const executeSql = useCallback(
    (sql: string): QueryResult => {
      const res = engine.executeSql(sql);
      const updatedDb = engine.getDatabase();
      setRooms([...updatedDb.rooms]);
      setGuests([...updatedDb.guests]);
      setBookings([...updatedDb.bookings]);
      setHousekeeping([...updatedDb.housekeeping]);
      setPayments([...updatedDb.payments]);
      return res;
    },
    [engine]
  );

  const exportDatabaseSql = useCallback(() => {
    const dump = engine.exportSqlDump();
    saveText(`qasr_alsadaqa_backup_${localDate()}.sql`, dump, 'application/sql;charset=utf-8');
    playAlertSound('success');
  }, [engine, playAlertSound]);

  const exportDatabaseJson = useCallback(() => {
    const { staffMembers, staffSalaries, expenses, otherRevenues, reservations, closings } = getLatest();
    const data = {
      ...engine.getDatabase(),
      extras: { staffMembers, staffSalaries, expenses, otherRevenues, reservations, closings, custody: custodyRef.current, smsLog: smsLogRef.current },
    };
    saveText(`qasr_alsadaqa_backup_${localDate()}.json`, JSON.stringify(data, null, 2), 'application/json;charset=utf-8');
    playAlertSound('success');
  }, [engine, playAlertSound]);

  const importDatabaseJson = useCallback(
    async (file: File): Promise<boolean> => {
      try {
        const rawText = await file.text();
        let text = rawText;
        let extras: Record<string, unknown> = {};
        try {
          const raw = JSON.parse(rawText);
          if (raw && typeof raw === 'object') {
            // snapshot format {meta, database} or plain export {..., extras}
            const db = raw.database ?? raw;
            extras = raw.database ? raw.database : raw.extras ?? {};
            text = JSON.stringify(db);
          }
        } catch {
          /* SQL dump: keep the raw text */
        }
        const restored = engine.importFromDumpOrJson(text);
        if (restored) {
          const arr = (v: unknown) => (Array.isArray(v) ? v : null);
          const sm = arr(extras.staffMembers); if (sm && sm.length) setStaffMembers(sm as StaffMember[]);
          const ss = arr(extras.staffSalaries); if (ss) setStaffSalaries(ss as StaffSalaryRecord[]);
          const ex = arr(extras.expenses); if (ex) setExpenses(ex as ExpenseRecord[]);
          const orv = arr(extras.otherRevenues); if (orv) setOtherRevenues(orv as OtherRevenueRecord[]);
          const rs = arr(extras.reservations); if (rs) setReservations(rs as FutureReservation[]);
          const cl = arr(extras.closings); if (cl) setClosings(cl as ClosingRecord[]);
          const cu = arr(extras.custody); if (cu) setCustody(cu as CustodyItem[]);
          const sl = arr(extras.smsLog); if (sl) setSmsLog(sl as SmsLogEntry[]);
          setRooms(restored.rooms);
          setGuests(restored.guests);
          setBookings(restored.bookings);
          setHousekeeping(restored.housekeeping);
          setPayments(restored.payments);
          setSettings(restored.settings);
          setLogs(restored.logs || []);
          if (restored.roomServiceMenu) setRoomServiceMenu(restored.roomServiceMenu);
          if (restored.roomServiceOrders) setRoomServiceOrders(restored.roomServiceOrders);
          playAlertSound('success');
          return true;
        }
        return false;
      } catch (err) {
        console.error('Error importing backup', err);
        return false;
      }
    },
    [engine, playAlertSound]
  );

  const resetToDemoData = useCallback(() => {
    const restored = engine.resetDatabase();
    setRooms(restored.rooms);
    setGuests(restored.guests);
    setBookings(restored.bookings);
    setHousekeeping(restored.housekeeping);
    setPayments(restored.payments);
    setSettings(restored.settings);
    setRoomServiceMenu(initialRoomServiceMenu);
    setRoomServiceOrders(initialRoomServiceOrders);
    setStaffMembers(initialStaffMembers);
    setStaffSalaries(initialStaffSalaries);
    setExpenses(initialExpenses);
    setOtherRevenues(initialOtherRevenues);
    setReservations([]);
    setClosings([]);
    playAlertSound('success');
  }, [engine, playAlertSound]);

  const updateSettings = useCallback(
    (newSettings: Partial<HotelSettings>) => {
      const { rooms, guests, bookings, housekeeping, payments, logs, settings } = getLatest();
      const merged = { ...settings, ...newSettings };
      setSettings(merged);
      persistChanges(rooms, guests, bookings, housekeeping, payments, logs, merged);
      playAlertSound('ding');
    },
    [settings, rooms, guests, bookings, housekeeping, payments, logs, persistChanges, playAlertSound]
  );

  // PDF Generator for Invoice
  const generatePdfInvoice = useCallback(
    (booking: Booking) => {
      const { settings } = getLatest();
      const sym = settings.currencySymbol;
      const balance = booking.totalAmount - booking.paidAmount;
      const rows: (string | number)[][] = [
        [1, `إقامة الغرفة ${booking.roomNumber} (${booking.nights} ليالٍ)`, money(booking.pricePerNight, sym), money(booking.roomTotal, sym)],
      ];
      booking.additionalCharges.forEach((ch, idx) =>
        rows.push([idx + 2, ch.description, money(ch.amount, sym), money(ch.amount, sym)])
      );
      exportArabicPdf(
        {
          hotelName: settings.hotelName,
          hotelAddress: settings.address,
          title: 'سند وفاتورة إقامة',
          metaRight: [
            ['رقم الحجز', booking.bookingCode],
            ['اسم النزيل', booking.guestName],
            ['رقم الهوية', booking.guestNationalId || '—'],
            ['رقم الغرفة', booking.roomNumber],
            ...((booking.companions || []).length ? ([['المرافقون', (booking.companions || []).map((c) => c.name).join('، ')]] as [string, string][]) : []),
          ],
          metaLeft: [
            ['تاريخ الدخول', booking.checkInDate],
            ['تاريخ المغادرة', booking.actualCheckOutDate || booking.expectedCheckOutDate],
            ['عدد الليالي', String(booking.nights)],
            ['طريقة الدفع', paymentMethodAr(booking.paymentMethod)],
          ],
          columns: [
            { header: '#', width: 1, align: 'center' },
            { header: 'البيان', width: 6 },
            { header: 'السعر', width: 2.4, align: 'center' },
            { header: 'الإجمالي', width: 2.4, align: 'center' },
          ],
          rows,
          totals: [
            ['الإجمالي الكلي', money(booking.totalAmount, sym)],
            ['المدفوع', money(booking.paidAmount, sym)],
            ['المتبقي', money(Math.max(0, balance), sym)],
          ],
          signatures: ['توقيع المستلم', 'توقيع النزيل'],
        },
        `سند-${booking.bookingCode}`
      );
      playAlertSound('success');
    },
    [settings, playAlertSound]
  );

  const generateSalarySlipPdf = useCallback(
    (slip: StaffSalaryRecord) => {
      const { settings } = getLatest();
      const sym = settings.currencySymbol;
      exportArabicPdf(
        {
          hotelName: settings.hotelName,
          hotelAddress: settings.address,
          title: 'قسيمة راتب موظف',
          metaRight: [
            ['رقم القسيمة', slip.slipCode],
            ['اسم الموظف', slip.staffName],
            ['المسمى الوظيفي', slip.roleTitleAr],
            ['شهر الاستحقاق', slip.month],
          ],
          metaLeft: [
            ['تاريخ الصرف', slip.paymentDate],
            ['طريقة الصرف', paymentMethodAr(slip.paymentMethod)],
            ['الحالة', slip.status === 'paid' ? 'تم الصرف' : 'معلّق'],
          ],
          columns: [
            { header: 'البند', width: 6 },
            { header: 'المبلغ', width: 3, align: 'center' },
          ],
          rows: [
            ['الراتب الأساسي', money(slip.baseSalary, sym)],
            ['البدلات والمكافآت', `+${money(slip.bonus, sym)}`],
            ['الخصومات', `-${money(slip.deductions, sym)}`],
          ],
          totals: [['صافي الراتب المستحق', money(slip.netSalary, sym)]],
          signatures: ['توقيع الموظف', 'توقيع المدير'],
        },
        `قسيمة-راتب-${slip.slipCode}`
      );
      playAlertSound('success');
    },
    [settings, playAlertSound]
  );

  const generateGuestStatementPdf = useCallback(
    (guest: Guest) => {
      const { bookings, settings } = getLatest();
      const sym = settings.currencySymbol;
      const guestBookings = bookings.filter((b) => b.guestId === guest.id);
      const totalAll = guestBookings.reduce((a, b) => a + b.totalAmount, 0);
      const paidAll = guestBookings.reduce((a, b) => a + b.paidAmount, 0);
      exportArabicPdf(
        {
          hotelName: settings.hotelName,
          hotelAddress: settings.address,
          title: 'كشف حساب النزيل',
          metaRight: [
            ['اسم النزيل', guest.name],
            ['رقم الهاتف', guest.phone],
            ['الهوية / الإقامة', guest.nationalId || '—'],
          ],
          metaLeft: [
            ['الجنسية', guest.nationality || '—'],
            ['عدد الزيارات', String(guest.visitCount)],
          ],
          columns: [
            { header: 'رقم الحجز', width: 2.2, align: 'center' },
            { header: 'الغرفة', width: 1.3, align: 'center' },
            { header: 'الدخول', width: 2, align: 'center' },
            { header: 'الخروج', width: 2, align: 'center' },
            { header: 'الإجمالي', width: 2, align: 'center' },
            { header: 'المدفوع', width: 2, align: 'center' },
            { header: 'الحالة', width: 1.6, align: 'center' },
          ],
          rows: guestBookings.map((b) => [
            b.bookingCode,
            b.roomNumber,
            b.checkInDate.substring(0, 10),
            (b.actualCheckOutDate || b.expectedCheckOutDate).substring(0, 10),
            money(b.totalAmount, sym),
            money(b.paidAmount, sym),
            b.paymentStatus === 'paid' ? 'مسدد' : 'متبقي',
          ]),
          totals: [
            ['إجمالي الحجوزات', money(totalAll, sym)],
            ['إجمالي المدفوع', money(paidAll, sym)],
            ['الرصيد المتبقي', money(Math.max(0, totalAll - paidAll), sym)],
          ],
        },
        `كشف-حساب-${guest.name}`
      );
      playAlertSound('success');
    },
    [bookings, settings, playAlertSound]
  );

  /** Arabic PDF of the whole guest register, with each guest's photo when available. */
  const exportGuestsPdf = useCallback(async () => {
    const { guests, bookings, settings } = getLatest();
    const photos = await Promise.all(guests.map((g) => (g.photo ? loadImg(g.photo) : Promise.resolve(null))));
    await exportArabicPdf(
      {
        hotelName: settings.hotelName,
        hotelAddress: settings.address,
        title: 'سجل النزلاء',
        landscape: true,
        metaRight: [['عدد النزلاء', String(guests.length)]],
        metaLeft: [['تاريخ التقرير', localDate()]],
        columns: [
          { header: '#', width: 0.8, align: 'center' },
          { header: 'الصورة', width: 1.4, align: 'center' },
          { header: 'الاسم', width: 3.4 },
          { header: 'الجوال', width: 2.2, align: 'center' },
          { header: 'الهوية', width: 2.4, align: 'center' },
          { header: 'الجنسية', width: 1.8, align: 'center' },
          { header: 'الزيارات', width: 1.3, align: 'center' },
          { header: 'مدة الاستضافة', width: 1.8, align: 'center' },
          { header: 'الغرفة', width: 1.2, align: 'center' },
          { header: 'تاريخ الاستضافة', width: 3.6, align: 'center' },
          { header: 'آخر زيارة', width: 2, align: 'center' },
          { header: 'ملاحظات', width: 2.4 },
        ],
        rows: guests.map((g, i) => [
          i + 1,
          photos[i] || '—',
          `${g.name}${g.isVip ? ' ⭐' : ''}${g.isBlacklisted ? ' 🚫' : ''}`,
          g.phone || '—',
          g.nationalId || '—',
          g.nationality || '—',
          g.visitCount,
          `${guestHosting(g.id, bookings).totalNights} ليلة`,
          (() => {
            const h = guestHosting(g.id, bookings);
            return h.current ? h.current.roomNumber : h.lastStay ? h.lastStay.room : '—';
          })(),
          (() => {
            const h = guestHosting(g.id, bookings);
            if (h.current) return `منذ ${h.current.checkInDate}`;
            return h.lastStay ? `${h.lastStay.from} ← ${h.lastStay.to}` : '—';
          })(),
          g.lastVisitDate || '—',
          g.notes || '',
        ]),
      },
      `سجل-النزلاء-${localDate()}`
    );
  }, []);

  const exportRoomsCsv = useCallback(() => {
    const headers = ['id', 'roomNumber', 'floor', 'type', 'pricePerNight', 'status', 'capacity', 'currentGuestName'];
    const rows = rooms.map((r) => [r.id, r.roomNumber, r.floor, r.type, r.pricePerNight, r.status, r.capacity, r.currentGuestName || '']);
    const csvContent = '\uFEFF' + [headers.join(','), ...rows.map((e) => e.join(','))].join('\n');
    saveText(`hotel_rooms_${localDate()}.csv`, csvContent, 'text/csv;charset=utf-8');
  }, [rooms]);

  const exportGuestsCsv = useCallback(() => {
    const { guests, bookings } = getLatest();
    const headers = ['id', 'name', 'phone', 'nationalId', 'nationality', 'visitCount', 'isFrequent', 'hostedNights', 'lastStayRoom', 'lastStayFrom', 'lastStayTo'];
    const rows = guests.map((g) => [g.id, `"${g.name}"`, g.phone, g.nationalId, g.nationality, g.visitCount, g.isFrequent, guestHosting(g.id, bookings).totalNights, guestHosting(g.id, bookings).current?.roomNumber ?? guestHosting(g.id, bookings).lastStay?.room ?? '', guestHosting(g.id, bookings).lastStay?.from ?? '', guestHosting(g.id, bookings).lastStay?.to ?? '']);
    const csvContent = '\uFEFF' + [headers.join(','), ...rows.map((e) => e.join(','))].join('\n');
    saveText(`hotel_guests_${localDate()}.csv`, csvContent, 'text/csv;charset=utf-8');
  }, [guests]);

  // ==========================================
  // Google Drive & Cloud Backup Actions
  // ==========================================
  const linkGoogleAccountManually = useCallback(
    (accountData: { email: string; displayName?: string; folderName?: string }) => {
      const email = accountData.email.trim();
      if (!email) return;

      const existingIndex = googleAccounts.findIndex((a) => a.email.toLowerCase() === email.toLowerCase());
      const now = localDateTime();
      const newFolder = accountData.folderName || 'QasrAlSadaqa_Backups';
      const newName = accountData.displayName || email.split('@')[0];

      let updatedAccounts: GoogleAccountLink[] = [];
      let targetId = '';

      if (existingIndex >= 0) {
        targetId = googleAccounts[existingIndex].id;
        updatedAccounts = googleAccounts.map((acc, idx) =>
          idx === existingIndex
            ? {
                ...acc,
                displayName: newName,
                folderName: newFolder,
                isLinked: true,
                linkedAt: now,
                syncStatus: 'synced',
                lastSyncAt: now,
              }
            : acc
        );
      } else {
        targetId = `g-acc-${Date.now()}`;
        const newAccount: GoogleAccountLink = {
          id: targetId,
          email,
          displayName: newName,
          folderName: newFolder,
          folderId: `drv-fld-${Date.now()}`,
          isLinked: true,
          linkedAt: now,
          storageUsedMb: 1200,
          storageTotalMb: 15360,
          authMethod: 'manual_selection',
          syncStatus: 'synced',
          lastSyncAt: now,
          autoSyncEnabled: true,
        };
        updatedAccounts = [newAccount, ...googleAccounts];
      }

      setGoogleAccounts(updatedAccounts);
      setSelectedGoogleAccountId(targetId);

      const newLog: ActivityLog = {
        id: uid(),
        timestamp: now,
        action: 'ربط يدوي لحساب Google Drive',
        details: `تم ربط حساب Google يدويًا: [${email}] وتعيينه كحساب النسخ الاحتياطي النشط`,
        category: 'database',
      };
      setLogs((prev) => [newLog, ...prev]);

      playAlertSound('success');
      confetti({ particleCount: 40, spread: 60, origin: { y: 0.7 } });
    },
    [googleAccounts, playAlertSound]
  );

  const unlinkGoogleAccount = useCallback(
    (accountId: string) => {
      const target = googleAccounts.find((a) => a.id === accountId);
      if (!target) return;

      const updated = googleAccounts.map((acc) =>
        acc.id === accountId ? { ...acc, isLinked: false, syncStatus: 'idle' as const } : acc
      );
      setGoogleAccounts(updated);

      if (selectedGoogleAccountId === accountId) {
        const nextLinked = updated.find((a) => a.isLinked && a.id !== accountId);
        if (nextLinked) {
          setSelectedGoogleAccountId(nextLinked.id);
        }
      }

      playAlertSound('ding');
    },
    [googleAccounts, selectedGoogleAccountId, playAlertSound]
  );

  const selectActiveGoogleAccount = useCallback(
    (accountId: string) => {
      const target = googleAccounts.find((a) => a.id === accountId);
      if (!target) return;

      setSelectedGoogleAccountId(accountId);
      playAlertSound('ding');

      setGoogleAccounts((prev) =>
        prev.map((acc) => (acc.id === accountId ? { ...acc, isLinked: true } : acc))
      );
    },
    [googleAccounts, playAlertSound]
  );

  const updateGoogleAccountSyncSettings = useCallback(
    (accountId: string, autoSync: boolean) => {
      setGoogleAccounts((prev) =>
        prev.map((acc) => (acc.id === accountId ? { ...acc, autoSyncEnabled: autoSync } : acc))
      );
    },
    []
  );

  // ==========================================
  // Automatic Backup Engine Actions
  // ==========================================
  const updateAutoBackupConfig = useCallback(
    (newConfig: Partial<AutoBackupConfig>) => {
      setAutoBackupConfig((prev) => {
        const merged = { ...prev, ...newConfig };
        return merged;
      });
      playAlertSound('ding');
    },
    [playAlertSound]
  );

  const createBackupSnapshot = useCallback(
    async (type: 'auto' | 'manual' | 'cloud_sync' = 'manual'): Promise<BackupSnapshot> => {
      const { rooms, guests, bookings, housekeeping, payments, logs, settings, roomServiceMenu, roomServiceOrders, staffMembers, staffSalaries, expenses, otherRevenues, reservations, closings } = getLatest();
      const now = new Date();
      const nowReadable = localDateTimeSec(now);

      const targetAccount = googleAccounts.find((a) => a.id === selectedGoogleAccountId) || googleAccounts[0];
      const willSyncToDrive = autoBackupConfig.syncToGoogleDrive && targetAccount && targetAccount.isLinked;

      const payload = {
        meta: {
          app: 'Qasr Al-Sadaqa Hotel PMS',
          version: 2,
          createdAt: nowReadable,
          type,
          googleAccount: targetAccount?.email || 'unlinked',
          hotelName: settings.hotelName,
        },
        database: {
          reservations,
          custody,
        addCustodyItem,
        returnCustodyItem,
        deleteCustodyItem,
        smsLog,
        logSms,
        clearSmsLog,
        smsDraft,
        setSmsDraft,
        openSmsComposer,
        addCompanion,
        removeCompanion,
        closings,
          settings,
          rooms,
          guests,
          bookings,
          housekeeping,
          payments,
          logs,
          roomServiceMenu,
          roomServiceOrders,
          staffMembers,
          staffSalaries,
          expenses,
          otherRevenues,
        },
      };

      const rawJson = JSON.stringify(payload, null, 2);
      const sizeKb = Math.max(1, Math.round(new Blob([rawJson]).size / 1024));

      const filename = `QasrAlSadaqa_Backup_${type.toUpperCase()}_${localDate(now)}_${now.getHours().toString().padStart(2, '0')}-${now.getMinutes().toString().padStart(2, '0')}.sqlite.json`;

      const newSnapshot: BackupSnapshot = {
        id: `snap-${Date.now()}`,
        filename,
        createdAt: nowReadable,
        sizeKb,
        type,
        googleAccountEmail: targetAccount?.email,
        googleDriveFileId: undefined,
        isSyncedToGoogleDrive: false,
        recordsCount: {
          rooms: rooms.length,
          guests: guests.length,
          bookings: bookings.length,
          payments: payments.length,
          expenses: expenses.length,
          salaries: staffSalaries.length,
          roomService: roomServiceOrders.length,
          logs: logs.length,
        },
        rawJson,
      };

      setBackupSnapshots((prev) => {
        const next = [newSnapshot, ...prev];
        const retention = autoBackupConfig.retentionCount || 10;
        return next.slice(0, retention);
      });

      // Update Auto Backup config last & next times
      setAutoBackupConfig((prev) => {
        const freqHours =
          prev.frequency === '1h'
            ? 1
            : prev.frequency === '3h'
            ? 3
            : prev.frequency === '6h'
            ? 6
            : prev.frequency === '12h'
            ? 12
            : prev.frequency === '24h'
            ? 24
            : prev.frequency === 'weekly'
            ? 168
            : 6;

        const nextDate = new Date(now.getTime() + freqHours * 60 * 60 * 1000);
        return {
          ...prev,
          lastBackupTime: nowReadable.substring(0, 16),
          nextBackupTime: localDateTime(nextDate),
        };
      });

      const newLog: ActivityLog = {
        id: uid(),
        timestamp: nowReadable,
        action: type === 'auto' ? 'نسخ احتياطي تلقائي' : 'إنشاء نسخة احتياطية محلية',
        details: `تم حفظ نسخة احتياطية محلية (${sizeKb} KB)`,
        category: 'database',
      };
      setLogs((prev) => [newLog, ...prev]);

      if (type !== 'auto') {
        playAlertSound('success');
      }

      return newSnapshot;
    },
    [
      googleAccounts,
      selectedGoogleAccountId,
      autoBackupConfig,
      settings,
      rooms,
      guests,
      bookings,
      housekeeping,
      payments,
      logs,
      roomServiceMenu,
      roomServiceOrders,
      staffMembers,
      staffSalaries,
      expenses,
      otherRevenues,
      playAlertSound,
    ]
  );

  const restoreBackupSnapshot = useCallback(
    async (snapshotId: string): Promise<boolean> => {
      const { rooms, guests, bookings, housekeeping, payments, logs, settings, roomServiceMenu, roomServiceOrders } = getLatest();
      const snapshot = backupSnapshots.find((s) => s.id === snapshotId);
      if (!snapshot) return false;

      try {
        let db: any = null;
        if (snapshot.rawJson) {
          const parsed = JSON.parse(snapshot.rawJson);
          db = parsed.database || parsed;
        } else {
          // If empty demo rawJson, use current engine state
          db = engine.getDatabase();
        }

        if (db.rooms) setRooms(db.rooms);
        if (db.guests) setGuests(db.guests);
        if (db.bookings) setBookings(db.bookings);
        if (db.housekeeping) setHousekeeping(db.housekeeping);
        if (db.payments) setPayments(db.payments);
        if (db.settings) setSettings(db.settings);
        if (db.roomServiceMenu) setRoomServiceMenu(db.roomServiceMenu);
        if (db.roomServiceOrders) setRoomServiceOrders(db.roomServiceOrders);
        if (db.staffMembers) setStaffMembers(db.staffMembers);
        if (db.staffSalaries) setStaffSalaries(db.staffSalaries);
        if (db.expenses) setExpenses(db.expenses);
        if (db.otherRevenues) setOtherRevenues(db.otherRevenues);

        engine.saveToStorage({
          version: 1,
          lastUpdated: new Date().toISOString(),
          settings: db.settings || settings,
          rooms: db.rooms || rooms,
          guests: db.guests || guests,
          bookings: db.bookings || bookings,
          housekeeping: db.housekeeping || housekeeping,
          payments: db.payments || payments,
          logs: db.logs || logs,
          roomServiceMenu: db.roomServiceMenu || roomServiceMenu,
          roomServiceOrders: db.roomServiceOrders || roomServiceOrders,
        });

        const nowReadable = localDateTimeSec();
        const logItem: ActivityLog = {
          id: uid(),
          timestamp: nowReadable,
          action: 'استعادة نسخة احتياطية',
          details: `تمت استعادة قاعدة بيانات الفندق من النسخة [${snapshot.filename}] بنجاح`,
          category: 'database',
        };
        setLogs((prev) => [logItem, ...prev]);

        playAlertSound('success');
        confetti({ particleCount: 50, spread: 70, origin: { y: 0.6 } });
        return true;
      } catch (err) {
        console.error('Failed to restore snapshot', err);
        return false;
      }
    },
    [backupSnapshots, engine, settings, rooms, guests, bookings, housekeeping, payments, logs, roomServiceMenu, roomServiceOrders, playAlertSound]
  );

  const deleteBackupSnapshot = useCallback((snapshotId: string) => {
    setBackupSnapshots((prev) => prev.filter((s) => s.id !== snapshotId));
  }, []);

  const syncSnapshotToGoogleDrive = useCallback(
    async (snapshotId: string): Promise<{ success: boolean; message: string }> => {
      const snapshot = backupSnapshots.find((s) => s.id === snapshotId);
      if (!snapshot || !snapshot.rawJson) {
        return { success: false, message: 'لا توجد بيانات لهذه النسخة. أنشئ نسخة جديدة ثم أعد المحاولة.' };
      }
      await saveText(snapshot.filename, snapshot.rawJson, 'application/json;charset=utf-8');
      const msg = 'اختر Google Drive أو Gmail من قائمة المشاركة لإرسال النسخة إلى حسابك.';
      setLastSyncMessage(msg);
      return { success: true, message: msg };
    },
    [backupSnapshots]
  );

  const syncAllToGoogleDriveNow = useCallback(async () => {
    setIsSyncingToGoogleDrive(true);
    setLastSyncMessage('جاري تجهيز نسخة كاملة من البيانات...');
    try {
      const snap = await createBackupSnapshot('cloud_sync');
      await saveText(snap.filename, snap.rawJson, 'application/json;charset=utf-8');
      const msg = 'اختر Google Drive أو Gmail من قائمة المشاركة لإرسال النسخة إلى حسابك.';
      setLastSyncMessage(msg);
      return { success: true, count: 1, message: msg };
    } catch (err) {
      console.error('backup share failed', err);
      setLastSyncMessage('تعذّر تجهيز النسخة.');
      return { success: false, count: 0, message: 'تعذّر تجهيز النسخة.' };
    } finally {
      setIsSyncingToGoogleDrive(false);
    }
  }, [createBackupSnapshot]);

  // Background Auto Backup Timer
  useEffect(() => {
    if (!autoBackupConfig.enabled) return;

    const interval = setInterval(() => {
      const last = autoBackupConfig.lastBackupTime ? new Date(autoBackupConfig.lastBackupTime).getTime() : 0;
      const now = Date.now();
      const freqHours =
        autoBackupConfig.frequency === '1h'
          ? 1
          : autoBackupConfig.frequency === '3h'
          ? 3
          : autoBackupConfig.frequency === '6h'
          ? 6
          : autoBackupConfig.frequency === '12h'
          ? 12
          : autoBackupConfig.frequency === '24h'
          ? 24
          : autoBackupConfig.frequency === 'weekly'
          ? 168
          : 6;

      const intervalMs = freqHours * 60 * 60 * 1000;
      if (now - last >= intervalMs) {
        createBackupSnapshot('auto');
      }
    }, 60000);

    return () => clearInterval(interval);
  }, [autoBackupConfig, createBackupSnapshot]);

  return (
    <HotelContext.Provider
      value={{
        rooms,
        guests,
        bookings,
        housekeeping,
        payments,
        logs,
        settings,
        notifications,
        unreadNotificationCount,
        roomServiceMenu,
        roomServiceOrders,
        staffMembers,
        staffSalaries,
        expenses,
        otherRevenues,
        currentUser,
        systemProfiles,
        updateSystemProfile,
        activeTab,
        setActiveTab,
        goBack,
        canGoBack,
        isDrawerOpen,
        setIsDrawerOpen,
        selectedRoom,
        setSelectedRoom,
        isCheckInModalOpen,
        setIsCheckInModalOpen,
        isSqlConsoleOpen,
        setIsSqlConsoleOpen,
        isSettingsOpen,
        setIsSettingsOpen,
        isNotificationsOpen,
        setIsNotificationsOpen,
        isAndroidView,
        setIsAndroidView,
        searchQuery,
        setSearchQuery,
        statusFilter,
        setStatusFilter,
        floorFilter,
        setFloorFilter,
        isAccountModalOpen,
        setIsAccountModalOpen,
        isHelpModalOpen,
        setIsHelpModalOpen,
        isLanguageModalOpen,
        setIsLanguageModalOpen,
        isLogoutModalOpen,
        setIsLogoutModalOpen,
        isLocked,
        setIsLocked,
        selectedGuestForStatement,
        setSelectedGuestForStatement,
        isLinkGuestModalOpen,
        setIsLinkGuestModalOpen,
        preselectedGuestForLink,
        setPreselectedGuestForLink,
        preselectedRoomForLink,
        setPreselectedRoomForLink,
        isAddRoomModalOpen,
        setIsAddRoomModalOpen,
        isNewRoomServiceModalOpen,
        setIsNewRoomServiceModalOpen,
        isRoomServiceMenuModalOpen,
        setIsRoomServiceMenuModalOpen,
        preselectedRoomForRoomService,
        setPreselectedRoomForRoomService,
        selectedOrderForDetail,
        setSelectedOrderForDetail,
        isNewExpenseModalOpen,
        setIsNewExpenseModalOpen,
        isNewOtherRevenueModalOpen,
        setIsNewOtherRevenueModalOpen,
        isPaySalaryModalOpen,
        setIsPaySalaryModalOpen,
        createRoomServiceOrder,
        updateRoomServiceOrderStatus,
        addRoomServiceMenuItem,
        updateRoomServiceMenuItem,
        deleteRoomServiceMenuItem,
        toggleRoomServiceItemAvailability,
        printRoomServiceOrderTicket,
        checkIn,
        closings,
        closePeriod,
        reopenPeriod,
        findClosedPeriod,
        reservations,
        addReservation,
        cancelReservation,
        convertReservationToStay,
        checkOut,
        completeHousekeeping,
        updateHousekeepingStatus,
        toggleHousekeepingChecklist,
        assignHousekeeper,
        updateRoomStatus,
        addAdditionalCharge,
        extendBookingNights,
        cancelBooking,
        addRoom,
        deleteRoom,
        updateRoom,
        addOrUpdateGuest,
        addGuest,
        deleteGuest,
        updateGuest,
        getGuestByPhone,
        toggleVipGuest,
        linkGuestToRoom,
        recordGuestPayment,
        generateGuestStatementPdf,
        exportGuestsPdf,
        addExpense,
        deleteExpense,
        addOtherRevenue,
        deleteOtherRevenue,
        recordSalaryPayment,
        addStaffMember,
        updateStaffMember,
        deleteStaffMember,
        switchUser,
        executeSql,
        exportDatabaseSql,
        exportDatabaseJson,
        importDatabaseJson,
        resetToDemoData,
        updateSettings,
        generatePdfInvoice,
        generateSalarySlipPdf,
        exportRoomsCsv,
        exportGuestsCsv,
        playAlertSound,
        markNotificationRead,
        clearAllNotifications,

        // Google Drive & Cloud Backup
        googleAccounts,
        selectedGoogleAccount,
        selectedGoogleAccountId,
        setSelectedGoogleAccountId,
        linkGoogleAccountManually,
        unlinkGoogleAccount,
        selectActiveGoogleAccount,
        updateGoogleAccountSyncSettings,

        // Auto Backup
        autoBackupConfig,
        updateAutoBackupConfig,
        backupSnapshots,
        createBackupSnapshot,
        restoreBackupSnapshot,
        deleteBackupSnapshot,
        syncSnapshotToGoogleDrive,
        syncAllToGoogleDriveNow,
        isSyncingToGoogleDrive,
        lastSyncMessage,

        // Modal Toggles
        isGoogleDriveLinkModalOpen,
        setIsGoogleDriveLinkModalOpen,
        isAutoBackupModalOpen,
        setIsAutoBackupModalOpen,
      }}
    >
      {children}
    </HotelContext.Provider>
  );
};

export const useHotel = () => {
  const context = useContext(HotelContext);
  if (!context) {
    throw new Error('useHotel must be used within a HotelProvider');
  }
  return context;
};
